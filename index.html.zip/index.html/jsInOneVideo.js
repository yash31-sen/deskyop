console.log("hello yash")
    // var a = document.getElementsByTagName("h1")[0].style.background="red"
    // var a = document.getElementsByTagName("h1")[0].style.visibility ="hidden".
    // var a = document.getElementsByTagName("h1")[0].style.display ="none"
    // document.write("hello this mw ")//write on a page
    // console.warn("this i snot a function")//for showing the warning

    // console.error("this is an error")
        // console.assert(6==6)
var a={
a:5,
b:"string",
c:4.5,
d:4
}

    // var arr=[1,2,3,"bab",5,6,7] 
    // arr.forEach(function(e){
    //     console.log(e)
    // }) 
// function avg( a, b){
// return a+b;
// }
// console.log(avg(1,5))

//     console.log(arr)

//     var a=4;
//     if (a==4){
//         console.log("hello")
//     }
//     else if(a<4){
// console.log("hello not")
//     }
//     else{
//         console.log("no hello")
//     }


// var a=[1,5,7,8,9,49]//consider first value for sorting like for given array the output will be ->   [1, 49, 5, 7, 8, 9]
// console.log(a.sort())
// let s="string hello hello"
// console.log(s.length)
// console.log(s.indexOf("hello"))//takes first character always for finding in word also in present codition returns-> 7 not 1
// console.log(s.lastIndexOf("hello"))//takes first character always for finding in word also in present codition returns-> 7 not 1
// console.log(s.slice(0,4))//takes first character always for finding in word also in present codition returns-> 7 not 1
// console.log(s.replace("string","sri"))//replace only first occurence

//dates in js

// let myDate=new Date()
// console.log(myDate)
// console.log(myDate.getTime())//returns time in seconds
// console.log(myDate.getFullYear())
// console.log(myDate.getDay())   //return monday as 0 and so on   
// console.log(myDate.getMinutes())   //returns min
// console.log(myDate.getHours())   //returns hours
// console.log(myDate.getSeconds())   //returns seconds
// console.log(myDate.getUTCDate())   //returns seconds



//Dom in js

//     let ab=document .getElementById('container1')
//     let ac=document .getElementsByClassName('hello')
//     let qu=document.querySelector('.container')
//     let qua=document.querySelectorAll('.container')
//     // let ad= getElementsTagName("h    1")
//     // ab.style.background="yellow"

//     //to create element from js
//     let ae=document.createElement('p')
//     ae.innerText="Hello tjis i snewly created element"
//     ae.replaceChild()
// removeChild()
//     //to add a class to any element
//     ab.classList.add("and_Added")
//     //to remove a class from any element
//     ab.classList.remove("and_Added")
//     //to acces the inner html or text of any element
//     ab.innerHTML
//     ab.innerText


// function clicked(){
//     console.log("clicked")
// }

// window.onload = function() {
//     console.log("hello page reloded")
//   };
// // let c=document.querySelector('#container1')
// //   c.addEventListener("click",function(e){
// //     console.log("click hua")
// // })
// // c.addEventListener("mouseover",function(e){
// //     console.log("hover hua")
// // })

// // c.addEventListener("mouseout",function(e){
// //     console.log("out hua")
// // })





//setTime out and setInterval



//Arrow function

// with non arrow function

// function summ(a,b){
//     return a+b;
// }

//same as

// summ=(a,b)=>{
//     return a+b;
// }




//setTimeOut
// does the given command after the givn time
// setTimeout(() => {
//     console.log("Hello this is setTimeOut")
// }, 2000);


// interval=()=>{
//     console.log("this is time interval")
// }


// // setTimeInterval
// //excute the given command after the given interval times again and again
// el=setInterval(interval,2000)
// clearInterval(el)//to clear interval
// clearTimeout()//to cancel timeout



// localStorage.setItem("name","yash");
// localStorage.getItem("name");

// let b={
//     a:"name",
//     b:"name1"
// }

// jso=JSON.stringify(b);//convert obj to string
// console.log(jso);
// parese=JSON.parse(jso);//converts string to obj
// console.log(parese)
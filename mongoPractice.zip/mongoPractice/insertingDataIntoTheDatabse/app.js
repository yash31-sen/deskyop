const express=require("express");
const mongoose=require("mongoose");
const app =express();
const port =3001;
const bodyParser=require("body-parser");


app.use(bodyParser.urlencoded({extended:true}));
// connection to mongodb =========================================================

mongoose.connect("mongodb://127.0.0.1:27017/testDB" ,(err) =>{
    if(err){
     console.log(err);
  console.log("aagya error")
    }
    else{
  
         console.log("connection successfull");
    }
})
// ========================================================


// // =======================================schema ==================
const notesSchema ={
    title:String,
    content:String,
    date:Date
}

const Note =mongoose.model("Note",notesSchema)

app.get("/",(req,res)=>{
res.sendFile(__dirname+"/index.html");
})

app.post("/",(req,res)=>{
let newNote= new Note({
    title:req.body.title,
    content:req.body.content,
    date:req.body.date
});

newNote.save();
res.redirect("/");
})

app.listen(port, () => {
    console.log(`the port is listening at ${port}`);
});
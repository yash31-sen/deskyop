const express = require("express");
const app = express();
const path = require("path");
const hbs = require("hbs");

const port = process.env.PORT || 3000;
require("./db/conn")
const Register = require("./models/registers");

const static_path = path.join(__dirname, "../public");
const templates_path = path.join(__dirname, "../templates/views");
const partiasl_path = path.join(__dirname, "../templates/partials");

app.use(express.json());
app.use(express.urlencoded({ extende: false }))
app.use(express.static(static_path));
app.set("view engine", "hbs");
app.set("views", templates_path);
hbs.registerPartials(partiasl_path)

app.get("/login", (req, res) => {
    return res.render("login");
})
app.get("/register", (req, res) => {
    return res.render("register");
})

app.get("/", (req, res) => {
    return res.render("index");
})



app.post("/register", async (req, res) => {
    try {
        const passsword = req.body.passsword;
        const cpasssword = req.body.cpasssword;
        if (passsword === cpasssword) {
            const registerStudent = new Register({
                FullName: req.body.FullName,
                ENO: req.body.ENO,
                email: req.body.email,
                phone: req.body.phone,
                password: req.body.password,
                cpassword: req.body.cpassword,
            })
            const register = await registerStudent.save();
            return res.status(201).render("home");
        } else {
            return res.status(400).send("pswd not matching");
        }

    } catch (error) {

        return res.status(400).send(error);
    }
})

app.post("/login", async (req, res) => {
    try {
        const check = await Register.findOne({ ENO: req.body.ENO });
        if (check.password === req.body.password) {

            res.render("home");
        }
        else {
            res.send("wrong password or email");
        }
    } catch {
        res.send("wrong details");
    }
})




app.listen(port, () => {
    console.log(`port is listening at ${port}`);
})
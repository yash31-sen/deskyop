const mongoose=require("mongoose");


const StudentSchema= new mongoose.Schema({
    FullName:{
        type:String,
        required:true
    },
    ENO:{
        type:String,
        required:true,
        unique:true
    },
    
    email:{
        type:String,
        required:true,
        unique:true
    },
    phone:{
        type:String,
        required:true,
        unique:true
    },
    password:{
        type:String,
        required:true
    },
    cpassword:{
        type:String,
        required:true
    }
    
})



//now creating the collection

const Register =new mongoose.model("Registers",StudentSchema)
module.exports=Register;
const express = require("express");
const mongoose = require("mongoose");
const app = express();
const port = 3000;
const ejs = require("ejs");
app.set("view engine", 'ejs');


const notesschema = {
    title: String,
    content: String,
    date:Date
}

const notes = mongoose.model('Notes', notesschema);



app.get("/", (req, res) => {
    notes.find({}, function (err, _notes) {
        res.render('index', {
            titlelist: _notes
        })
    })
})

// connection to mongodb =========================================================

mongoose.connect("mongodb://127.0.0.1:27017/testDB", (err) => {
    if (err) {
        console.log(err);
        console.log("aagya error")
    }
    else {

        console.log("connection successfull");
    }
})






app.listen(port, () => {
    console.log(`port is running at ${port}`);
})
const express = require("express");
const { get } = require("http");
const app = express();
const path = require("path");
// const hbs = require("hbs");
const jwt =require("jsonwebtoken");
const jwt_seceret="some super secerete.....";
const port = process.env.PORT || 3008;
require("./db/conn")
const Register = require("./models/registers");

const static_path = path.join(__dirname, "../public");
const templates_path = path.join(__dirname, "../templates/views");
const partiasl_path = path.join(__dirname, "../templates/partials");


app.use(express.json());
app.use(express.urlencoded({ extende: false }))
app.use(express.static(static_path));
app.set("view engine", "ejs");
app.set("views", templates_path);
// hbs.registerPartials(partiasl_path)

app.get("/login", (req, res) => {
    return res.render("login");
})
app.get("/register", (req, res) => {
    return res.render("register");
})
app.get("/forget",(req,res,next)=>{
    return res.render("forget");
})
app.get("/reset",(req,res,next)=>{
    return res.render("forget");
})


let user={
    id:"naemofid",
    email:"y@gmail.com",
    password:"passwordnipata"
}


app.post("/forget",(req,res,next)=>{
    const email=req.body.email;
 if(email!=user.email){
    res.status(400).send("email doesnot exist");
    return;
 }
 else{
const secerete=jwt_seceret+user.password;
const paylaod={
    email:user.email,
    id:user.id
}
const token=jwt.sign(paylaod,secerete,{expiresIn:"10m"})
const link =`http://http://localhost:3000/reset-password/${user.id}/${token}`
console.log(link);
res.status(201).send("Passwrod reset link has been sended to the email...")
}
const secerete=jwt_seceret+user.password;
try{
 const paylaod=jwt.verify(token);
 return res.status(201).render("reset-password",{email:user.email});
}catch{
    console.log("error aa gya1");
   return res.status(400).send("error a gya1");
}
})
// app.get("/reset-password/:id/:token",(req,res,next)=>{
// const {id,token}=req.body;
// //  check id exist in db
// if(id!==user.id){
//    return res.status(400).send("not valid id");
// }
// })
// app.post("/reset-password/:id/:token",(req,res)=>{
//     const {id,token}=req.body;
//    return res.status(201).send(user);
// })


app.get("/", (req, res) => {
    return res.render("index");
})



app.post("/register", async (req, res) => {
    try {
        const passsword = req.body.passsword;
        const cpasssword = req.body.cpasssword;
        if (passsword === cpasssword) {
            const registerStudent = new Register({
                FullName: req.body.FullName,
                ENO: req.body.ENO,
                email: req.body.email,
                phone: req.body.phone,
                password: req.body.password,
                cpassword: req.body.cpassword,
            })
            const register = await registerStudent.save();
            return res.status(201).render("index");
        } else {
            return res.status(400).send("pswd not matching");
        }

    } catch (error) {

        return res.status(400).send(error);
    }
})

app.post("/login", async (req, res) => {
    try {
        const check = await Register.findOne({ ENO: req.body.ENO });
        if (check.password === req.body.password) {

            res.render("home");
        }
        else {
            res.send("wrong password or email");
        }
    } catch {
        res.send("wrong details");
    }
})




app.listen(port, () => {
    console.log(`port is listening at ${port}`);
})
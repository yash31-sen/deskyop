const express = require("express")
const mongoose = require("mongoose")
const port = 3000;
const app = express();
const User = require("./models/user")
const con = require("./connection")
app.use(express.urlencoded({ extended: false }));
app.use(express.static('public'))
app.set("view engine", "ejs");
app.get("/", (req, res) => {
    res.render("index");
})
app.get("/showData", async (req, res) => {
    try {
      const users = await User.find({});
      res.render("showData", {
        titlelist: users,
      });
    } catch (err) {
      console.error(err);
      res.status(500).send("Internal Server Error");
    }
  });
  

app.post("/sendData", async (req, res) => {
    const data = new User(req.body);
    await data.save();
    res.send("Data Saved");
})
app.listen(port, () => {
    console.log(`Connection  done at port ${port}`);
})
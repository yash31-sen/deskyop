const mongoose=require("mongoose")

const uri="mongodb+srv://developer3171:dev3171@cluster0.h87dbba.mongodb.net/InsertDataDB?retryWrites=true&w=majority"

const con=mongoose.connect(uri).then(() => {
    console.log("Database Connection Done");
}).catch(() => {
    console.log("Not Connectd");
})



module.exports=con
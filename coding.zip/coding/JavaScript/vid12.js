//Dom(Document Object model)(type of it is object) in javascript
console.log('This si vid12');
// let a = document;
// let a=document.forms[0];// to search forms in a website ,ot os type of html collection
// let a=document.all;
// let a=document.links[0].href;
// let a=document.images[0];
let a=document.scripts;
console.log(a);


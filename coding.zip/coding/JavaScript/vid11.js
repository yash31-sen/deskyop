// //javascript winodows and more
// let a= window;//window is global object in js
// window.alert('I am yash');//we can use only alert('I am yash' ) it also works as similar as window.alert()
// let a= prompt('This will destroy your computer');//it shows the warning message or take user's input about that message
// let a =confirm('Are you suer you want to exit');//on clicking ok gives true and in clicking cancel give false
// these all are not use now they are used in older websites now we use css or andjs to do it 
// let a=innerWidth;
// let b=innerHeight;//gives the inner width and height of the page
// let a=outerWidth;
// let b=outerHeight;//gives the outer width and height of the page
// let a=scrollX;
// let a=scrollY;//gives info about how much scroll user has done in the page in x and y directions both
// let a= location.relode();//not working
// let a = location.toString();//gives the location of page i.e the server address
let a=history;//arrow keys on the top right of page is make by it
console.log(a);
// console.log(b);

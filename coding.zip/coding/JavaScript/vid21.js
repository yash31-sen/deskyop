// Exercise to solve

console.log('Exersice to solve');
// //use of event listners
// /*You have to create a div and inject it into a page which contains a heading

//  */

// let edit = document.getElementById('edit');
// console.log(edit);

// edit.addEventListener('click', func1);
// //when user double clicks on the text
// function func1() {
//   let i = document.createElement('input');
//   i.id = "inputid";
//   i.type = "text";

//   i.innerText = "";
//   edit.appendChild(i);

//   let u = document.getElementById("inputid");
//   u.addEventListener('click', func2);
//   // when user clicks on The  entered value
//   function func2() {
//     let getval = u.value;
//     localStorage.setItem('Data Entered',getval);
//   }





// //// ***********on clicking button try it it will convert the text fron heafing1 into the given text
// // function myFunction() {
// //   let str = document.getElementById("heading").innerHTML; 
// //   document.getElementById("heading").innerHTML = str.replace("This is my laptop", "This is Yash's laptop");;
// }

// ////******************************************* */







// // }









// // solving with harry's method

// let div= document.createElement('div');
// // let text= document.createTextNode('this is my taxtnode');

// let val =localStorage.getItem("text");
// let text;
// if(val==null){
//   text=document.createTextNode('This is my element. Click to edit the text');
// }
// else{
//   text=document.createTextNode(val);
// }


// div.appendChild(text);

// div.setAttribute('class','elm');
// div.setAttribute('id','elm');
// div.setAttribute('style','border: 2px solid red; width:154px;padding:13px;color:blue');

// let container = document.querySelector('.container');
// let first= document.getElementById('myfirst');

// //////Inserting Element before id first or myul

// container.insertBefore(div,first);


// console.log(div, container,first);


// ////add eventlistner to div
// div.addEventListener('click',function() {
//   let noTextArea = document.getElementsByClassName('form-control').length;
// if(noTextArea==0){
//   let html= elm.innerHTML;

// div.innerHTML=`<textarea class="form-control id="textarea" aria-label="With textarea"></textarea>`;///if do it like that then textarea is not editable for making it editable do it like that

// }
// let textarea = document.getElementById('textarea');
// textarea.addEventListener('blur', function() {
//     elm.innerHTML = textarea.value;
//     localStorage.setItem('text', textarea.value);
// })
// });





console.log('This is tutorial 25')
/*
You have to create a div and inject it into the page which contains a heading.
whenever someone clicks on the div, it should be converted into an editable item. whenever user clicks away (blur). save the note into the local storage.

*/

// Create a new element
let divElem = document.createElement('div');

// Add text to that created element
let val = localStorage.getItem('text');
let text;
if (val==null){
 text = document.createTextNode('This is my element. click to edit it');
}
else{
    text = document.createTextNode(val);
}
divElem.appendChild(text);

// Give element id, style and class
divElem.setAttribute('id', 'elem');
divElem.setAttribute('class', 'elem');
divElem.setAttribute('style', 'border:2px solid black; width: 154px; margin: 34px; padding:23px;');

// Grab the main container
let container = document.querySelector('.container');
let first = document.getElementById('myfirst');


// Insert the element before element with id first
container.insertBefore(divElem, first);

console.log(divElem, container, first)

// add event listener to the divElem
divElem.addEventListener('click', function () {
    let noTextAreas = document.getElementsByClassName('textarea').length;
    if(noTextAreas ==0){
    let html = elem.innerHTML;
    divElem.innerHTML = ` <textarea class="textarea form-control" id="textarea" rows="3"> ${html}</textarea>`;
    }
    //listen for the blur event on textarea
    let textarea = document.getElementById('textarea');
    textarea.addEventListener('blur', function() {
        elem.innerHTML = textarea.value;
        localStorage.setItem('text', textarea.value);
    })
});

 
// you have to create a vaiable which is a string containing the text which is a link you are interested in

//You have to fetch all the links from a given page which contains this text
let string=document.links;
// let a="facebook";
Array.from(string).forEach(function(element){
    if(element.href.includes("facebook")){
        console.log(element.href);
    }

    if(element.href.includes("google")){
        console.log(element.href);
    }
}
)


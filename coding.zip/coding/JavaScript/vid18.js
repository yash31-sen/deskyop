console.log("This is vid18");
//// Events in more details 
// let btn= document.getElementById('btn');
// btn.addEventListener('click',func1);
// btn.addEventListener('dblclick',func2);
// btn.addEventListener('mousedown',func3);

// function func1(e) {
//     // console.log("Thanks",e);


//     //if we make type = submit then it will submit the page but to resolve or bymass any defaoult event we use 
//     // preventDefault
//     e.preventDefault();//after this it will not submit the page or bypss the default argumrnt
// }
// function func2(e) {
//     console.log("Thanks Its double click",e);


//     //if we make type = submit then it will submit the page but to resolve or bymass any defaoult event we use 
//     // preventDefault
//     e.preventDefault();//after this it will not submit the page or bypss the default argumrnt
// }
// function func3(e) {
//     console.log("Thanks Its mouse down",e);


//     //if we make type = submit then it will submit the page but to resolve or bymass any defaoult event we use 
//     // preventDefault
//     e.preventDefault();//after this it will not submit the page or bypss the default argumrnt
// }


// document.querySelector('.this').addEventListener('mouseenter',function(){
//     console.log('you entered no.')
// })
// document.querySelector('.this').addEventListener('mouseleave',function(){
//     console.log('you leave the mouse.')
// })
document.querySelector('.container').addEventListener
('mousemove',function(e){
    console.log(e.offsetX , e.offsetY);
    document.body.style.backgroundColor=`rgb(${e.offsetX}
        ,${e.offsetY},${e.offsetX},120)`;///it chianegs color of background on moving the mouse
    console.log('You triggered mouse move event.')/////it shows the no. of times you move the mouse inside the given  class or id
})







console.log("Hello I am vid8");

// if else statement in java script
const age=19;

if (age!=="18"){ // if we use triple === then it does not print age is 18
    console.log('Age is 18');// not equal to means if value is not eqaul it give right but there is another thinng !==(not double equal to) it will check for value and and type of variable also and if both are not equal then give rigrt
}
else if(age==20){// on using if here it will check it but on using else if it will not check the condition
    console.log('Age is 20'); 
}
else{
    console.log('Age is other than 18 and 20');
}
// == only check the value if it is correct or not it does not check the variable type as id=t is string or float or what
// for checking the tyoe of variable we should use ===(triple equal to)
// for checking if the variable is present or not /
// const avr=2;
if (typeof avr != 'undefined'){
    console.log("avr is present");
}
else {
    console.log("avr is not present");
}
// if we deal with booleans we can put it directly in a conditional statement
const drive = false; // on putting true hereit will print he can drive else other one
if (drive || age==19){
    console.log("He can drive");
}
else {
    console.log("No he can not drive");
}

// Teranry operator 
console.log(age==45? 'Age is 45': 'Age is not 45');//compleately work as if else conditonals 

switch (age) {
    case 18://it requires both values an dvarivle type to be equal
        console.log('you are 18')
        break;
    case 19:
        console.log('you are 19')
        break;
    case 20:
        console.log('you are 20')
        break;
    case 28:
        console.log('you are 28')
        break;

    default:
        console.log('you are not in any of these age')
        break;
    
}
console.log('This is vid 17');
/////events   (cut  copy paste click )
document.getElementById("heading").addEventListener("click",function(e){//there is anther event mouseover
console.log("You have clicked heading");
// variable =e.target;
// location.href='//google.com'//redirect us to google.com on clicking
variable= e.target.className;
variable =e.target.classList;
console.log(variable)
variable= Array.from(e.target.classList);
// console.log(e);
// variable= e.ofysetX;
// variable= e.offsetY;
// variable=e.clientX;
variable=e.clientY;
console.log(variable)
 });
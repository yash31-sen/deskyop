// const name = "Joker";
// const greeting="Good morning";
// console.log(name+" "+greeting);\

//// ways to concatinate strings
// 1.
// let html;
//  html = "I am very good language"+
//         "and I am very easy";
// console.log(html)

// 2.
let hm="Hello I am hm ";
hm = hm.concat("I am in class 12th ","and my school is public school");
console.log(hm);

// to print length of string
// console.log("It has "+hm.length+" characters")
//to convert string to loewer case nad upper case

// console.log(hm.toLowerCase());//it returns only does not change the original string
// console.log(hm.toUpperCase());//it returns only does not change the original string
// console.log(hm);
// console.log(hm[2]);//prints the character of that index
// console.log(hm.indexOf('I'));
// console.log(hm.lastIndexOf('I'));
// console.log(hm.charAt(30));//Gives the character ata 30 th index of string
// console.log(hm.endsWith('school')); // to check if the string is ends with the given character or not if yes return true and if no then gives false
// console.log(hm.includes(" ")); // to check if the word is present i  a string or not if yes then return true and if no then return false
// console.log(hm.substring(1,5));// print characters from 1 to 5 ,1 is inclluding and 5 is excluding
// console.log(hm.slice(0,20));// slice the string from first value to last value
// console.log(hm.split('I'))// splits I to ", "
// console.log(hm.replace('I', 'Iol'));


// //Template literals
let fruit1=`Orange`;
let fruit2 =`Apple`;
let myhtml =`Hello ${fruit1}
I am yash sen and I am osm man 
I lke fruit ${fruit2}`;
//here $ is just like f string in python
document.body.innerHTML=myhtml;


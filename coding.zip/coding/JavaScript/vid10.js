// console.log('hello I am vid10');
//Functions and Scopes in javascript
// function greet(name,thank='Thank you'){//if we do not give any other argument to the function inthe place of thanks then it will take the default value which we provide to it 
//     console.log(`Hello I am ${name} and I want to ${thank} you`);
//     return 'msh';
// }
// another way to make a function by giving a variable name to it is 
// const mygreet=function(name,thank='Thank you'){//if we do not give any other argument to the function inthe place of thanks then it will take the default value which we provide to it 
//     console.log(`Hello I am ${name} and I want to ${thank} you`);
//     return 'msh';
// }
// let val =greet("xyz");// if we do not give return value to the function then it will give udrefined in place of val
// console.log(val)

// let val =mygreet("xyz");// if we do not give return value to the function then it will give udrefined in place of val
// console.log(val)

// we can make function inside a variable also

// const myobj={
//     name:"xcf",
//     game: function () {
//         return "gta";
//     }
// }
// console.log(myobj.game());
let i=4;
if(1){//outside the brackets let will act as a global varible but not inside where as var act as global inside or outside the brackets alos
    console.log(i)
}
{
    let i=87;
    console.log(i)
}
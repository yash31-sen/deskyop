console.time('Your code took')
console.log('Hello Console This is Me ');
console.log(45 + 1);
console.log(true);// boolean in js
console.log([36, 5, 8, 9, 7, 6]);//array in js
console.log({ no: 568, yash: 'this', marks: 52, card: 569 });
console.table({ no: 568, yash: 'this', marks: 52, card: 569 });//Prints data in tabulaer form
console.warn('This is warning');//gievs warning in consloe
// console.clear();//clear the consloe
console.timeEnd('Your code took');
console.assert(566<189,'Age >189 is not possible'); //if user give wrong info then it show error

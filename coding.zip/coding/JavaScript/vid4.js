//cases
// 1. CamelCase
// 2.Kabab-case
// 3.snake_case
// 4. PascalCase


// data types in javascript
// 1. Primitive data type (Memory allocate in it in stack)base -> data type
// -->(strings,numbers,Boolean ,null[intensional empty value (do when we want ot check it if irt is null or not after some time)], undefined,symbol[introduce in latest version of javascript])
// 2 Refrence data type (Memory allocatio in heap (dynamiclly)) -> object
// (Arrays, object , function ,data type)

let name ="Yash";
console.log("My name is "+name)
console.log("Data type is "+(typeof name)) // ot check the type of data type

//boolean
let driver=true;
console.log("Data type is "+(typeof driver));

//null
let hing =null; // it has vagues(undefined) value
console.log("Data type is "+(typeof hing));


//undefined
let hinge =undefined; // it has vagues(undefined) value
console.log("Data type is "+(typeof hinge));


//Reference dara types

// Array
let arrays =[1,5,4,7,8,false,"string"];
console.log("Data type is "+(typeof arrays));

// object literalas

let stMarks={
    h: 4,
    j:46,
    k:56,
   "rohan das": 400 // if want to give space then use it under quotes
}
console.log(typeof stMarks)

// date
let date= new Date();
console.log(typeof date)

//function
function findName() {

}
console.log(typeof findName)
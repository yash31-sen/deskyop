console.log('vid3');
// vaiable in js
// we can create vriable by ->> var,let,const
// we can also use `backtick as long with double and single quotes to declare variable
var name=`Yash`;
var channel= 'Colors';
var marks=34;
console.log(name,channel, marks+2);
// Rules for  creating javacsript variable
// 1. Can not start wtith no.
// 2. Can start with letter ,underscore and dollar
// 3. variables are case sensitve
var city="Delhi"; // All are true 
var _city="Delhi";//All are true but do not use these
var $city="Delhi";//All are true but do not use these

// use of const
// we can use const if we don't want to change the variable in our whole programe
// with var we can change variable
// like --> var name =xyz;
// name =ytg;
// but we can't do it with const --> const name=xyz; it willremain xz always
// we must give a = to aconst variale




// Use of let

// we use let as a local variable 

// The main difference between the two though is that let deals with block scope whereas var deals with global scope or function scope depending on where it's declared. As long as your variable isn't declared within any function, var can be used again anywhere else in your code.
var country ="India";
{
    let country ="America";
    country="Australia";
    console.log(country)
}


const arr1 = [1,5,5,6]
// we can do this
arr1.push(56);//it wll add one more element in an array
// but we can't do it 
// arr1=[5,8,8,6]
console.log(arr1)



// type conversion and type coercion
 let myVar;
myVar=String(34);
console.log(myVar,(typeof myVar));

let boolVar= String(true);
// boolVar = String(true);
console.log(boolVar, (typeof boolVar))

let date=String(new Date());
console.log(date)


let arr=[1,5,6,5];
console.log(arr.toString());//can use toString also to convert it in string


let array=String([15,5,4,5,5,5,5]);
console.log(array.length)

let stri = Number("6434553");
stri=Number([4,4,5,7]);//give NaN Not defined no.
stri=Number("6556356a8");//give NaN Not defined no.
console.log(stri);


// parseInt and parseFLoat

let nm=parseInt("65656.454")
 nm=parseFloat("65656.4")
console.log(nm.toFixed(5))


// typecoercion

let mystr=Number("459");
let mynum=232;
console.log(mystr+mynum);
// let mystr=("459");
// let mynum=232;
// console.log(mystr+mynum);
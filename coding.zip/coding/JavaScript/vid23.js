console.log("this is vid 23");
  let x = 6;
  let y=4;
  let z;

  z=x+y;//and all mathematical functions work here



  /////some math functions of javascript

//   z= Math.PI;//return the value of pi
//   z= Math.E;//returns the value of E
//   z= Math.round(5.5);///returns value in round figure
//   z=Math.ceil(5.9);///returns the round value but always max as 6.2 -> 7 and -5.3 to -5
//   z=Math.floor(-5.2);////gives the round figure but always less as 6.5 -> 6 and -6.5 -> -7
//   z=Math.abs(-5.3);///convert -ve values to +ve and let +ve to +ve
//   z=Math.sqrt(65);////returns square root
//   z=Math.pow(2,3);////return x^y
//   z=Math.min(5,45,6,2,);//returns min value
//   z=Math.max(2,54,6,55,5);//return max value
//*******to geneate a random no. in javascript */

z=Math.random();
////****to generate a raondom no. between 0 to 100 */
z=100*Math.random();
/////**********to generate a no. between 10 to 100 */
z= 10+(100-10)*Math.random()
// ///***above formula give a random no. in float form to get it in integer form use the floor or ceil property as per need */
z=Math.ceil(10+(100-10)*Math.random())





  console.log(z);
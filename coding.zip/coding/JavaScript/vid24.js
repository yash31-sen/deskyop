console.log(" This is video 24");
/////Date and time  in javascript
let today = new Date();/////prints the dateof present date with time and IST or others


let otherdate =new Date('2-4-2003 04:54:08');  ///////prints the sate written in the  brackets  formate of date is mm,dd,yyyy firstly the day at that date tehn date and then time 
console.log(otherdate);

let a;
// a=otherdate.getDay();/////prints the day as the no. take sunday as 0 and them contineu
// a=otherdate.getDate();/////prints the day as the no. take sunday as 0 and them contineu
// a=otherdate.getMinutes();/////prints the day as the no. take sunday as 0 and them contineu
// a=otherdate.getTime();/////prints the no.of seconds uptill that date
// a=otherdate.getMilliseconds();/////prints the day as the no. take sunday as 0 and them contineu
// a=otherdate.getMonth();/////take 1st month as 0
// a=otherdate.getMonth();/////prints the day as the no. take sunday as 0 and them contineu
// console.log(a);


//////set properties in javascript

otherdate.setDate(23)
otherdate.setMonth(3)
otherdate.setFullYear(2050)
otherdate.setMinutes(0)
otherdate.setSeconds(0)
console.log(otherdate)
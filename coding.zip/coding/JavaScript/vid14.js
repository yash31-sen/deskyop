console.log("This is vid14");


/////Dom Selectors
// elment selctors
// 1.single elemnt.
// 2.Multi elemnet selctor


// 1.single elemnt.
// let element =document.getElementById('mycls');
// element=element.className;
// element=element.childNodes;
// element=element.parentNode;//not working
// using css by javascript
// element.style.color='red';//to change color
// element.innerText='I am good boy';//changes the text of element
// element.innerHTML='<b> I am good boy';//we can use html tags by this property
// console.log(element.innerHTML);//it will print inner html in a console
// console.log(element);//and only element will print full div

// let sel = document.querySelector('#mycls');
// sel = document.querySelector('.class');// it will give the first most class not others
// sel = document.querySelector('div');// it will give the first most div not others
// sel.style.color ='red';//it will change the color of only first div not all or div inside first div
// sel= document.querySelector('.hading')
// sel= document.querySelector('hading')
// let sel=document.querySelector('b');

// console.log(sel);




// 2.Multi elemnet selctor
//***Helpful to select multiple elements in dom */    
// let e= document.getElementsByClassName('class');
// console.log(e);//will gice all the divs with class class o giving e[0] it will give 1st div with class class

//************************************ */

// let el= document.getElementsByClassName("container");
// console.log(el[0].getElementsByClassName('class'));


//*************************************** */
//will print info of all classes inside a class container


//***************************************** */
let el=document.getElementsByTagName('div');
console.log(el);
//********************************************** */
//will give all the divs in a html


// we can iterate oyr html collections
// Array.from(el).forEach(element =>{
//     console.log(element);
//     element.style.color='blue';
// });
//will change tthe color of all the elemnts inside div



//we may use traditional for loop also to do this
for (let index = 0; index < el.length; index++) {
    const element = el[index];
    console.log(element)
    element.style.color='blue';
}
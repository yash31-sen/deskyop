console.log('i am yash sen');
const marks=[1,2,3,4,5,6,7,8,9];
// const fruit=['Orange','Apple'];
// const mixed =['str',50,85,95,78];
// const arr= new Array(25,5,4,10,56,'name');
// console.log(Array);
// console.log(marks)
// marks[5]='string'; //it will change the value of index 5 i whole program
// console.log(marks)

let value =marks.indexOf(5);// it will print in which index does the element is stored i an array
console.log(value)
console.log(marks);
//mutatiang or modifying array
// marks.push(56964); //print the another element in the end of an array
// marks.unshift(7444747); //prints the another value in the start of an array
// console.log(marks);
// marks.pop();//removes the last elemnt from an array
// console.log(marks);
// marks.shift();//removes the first element of an array
// console.log(marks);
marks.splice(0,5);//removes the elment from index 1st to index 2nd
console.log(marks);
marks.reverse();//simply reverse the array
console.log(marks);

let myobj={
    'first name' : 'skjzs',
    class:'logo',
    no: 56

}
console.log(myobj['class'])
console.log(myobj.class)
console.log(myobj['first name'])//to access the variable with space this is other method
console.log('This is vid 20');
////local and session storage in javascript]
// //session storage is only valid for a particular session as you closes the session it will ends

//we can not add array in storage
// let impArray = ['adrak','pyaz','bhindi'];
///if we it it lke above then it will return string in the application panel
//// if we want to add array in storage then do it like that
// localStorage.setItem('sabzi',JSON.stringify(impArray));
// it will give us array in the application menu 
// but if we type localStorage.getItem in the console it will print it as string for gettting it as array we need to print it like that
// ma= JSON.parse(localStorage.getItem('sabzi'));
// console.log(ma);//will return an array in the console


// // add a key value inside a local storage
// localStorage.setItem('Name','yash');
// localStorage.setItem('Name2','sachin');///to show it in console type wimdow.localStorage
// localStorage.setItem('sabzi',impArray);///to show it in console type wimdow.localStorage


//retrain the item from local storage
// let mame= localStorage.getItem('Name2');
// console.log(mame);

// localStorage.clear();///to clear local storage 
////if want to claer a particular element use this
// localStorage.removeItem('Name');




// Session storage have same properties as local storage 
// sessionStorage.setItem('sessionName','sYash');
// sessionStorage.setItem('sessionName2','sRohan');
// sessionStorage.setItem('sessionsabzi',JSON.stringify(impArray));
// it will removed after the wabpage or borwser is closed
//to clear sessoin storage sessoinStorage.clear();

console.log("I am in vid 15");
let cont = document.querySelector('.container');
// console.log(cont);
// to get all trhe child nodes inside the contsiner class
// console.log(cont.childNodes);//it will return all the elements like blank line ,comment out lines text etc 
// console.log(cont.children);//use to avoid upper things like avoid showing coomentout lines texts etc as a no. in a console it will show only the main content like attribute tags etc

// let nodeType = cont.children[0].nodeType;//can us child nodes also inplace of children or vic-versa
// let nodeName = cont.children[0].nodeName;//can us child nodes also inplace of children or vic-versa
// console.log(nodeName); 
// console.log(nodeType);//return 0,1,2,3 etc as output


// NodeType table
// 1.Element
// 2.  attribute
// 3. Text node
// 8.comment
// 9. document
// 10.docType


let container= document.querySelector('#mycls');
// console.log(container.children[1].children[0].children);//we can do it for .container[0].containerp[0].container[0].contaner..............
// console.log(container.firstChild)//pirnts the first cihld of contsiner
// console.log(container.firstElementChild)//prits first element of the class
// console.log(container.childNodes)//print all the childs of that class


// similrly we  have last element property also for the element inside the class or id

// console.log(container.lastChild)//pirnts the last cihld of contsiner
// console.log(container.lastElementChild)//prits last element of the class
// console.log(container.childElementCount);//we can count child elements by this

// console.log(container.firstElementChild.parentNode);//print the parent of that class
// console.log(container.firstElementChild.nextElementSibling);



// console.log(container.lastElementChild.parentNode);//print the parent of that class
// console.log(container.childElementCount)



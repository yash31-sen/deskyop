//  Creating Remomoving an dmaking elements
console.log("This is vid 16");

let element = document.createElement('li'); //-----------------------1
let text = document.createTextNode('I am a Text node ');
element.appendChild(text);

element.className='childul';
element.id='createdli';
element.setAttribute('text','mytitle');
//we can use any thing in place of text in above line
// element.innerText="yash sen"
//if we wantto use html tags in above line then use innerHTML in place of innerTEXT
let ul = document.querySelector('ul.this');
ul.appendChild(element);
// console.log(ul);
// console.log(element);


////if we want to replace any element in a javascript then use this


let elem2= document.createElement('h3');
elem2.id ='elem2';
elem2.className='elem2';
let tnode =document.createTextNode('This is node of text');
elem2.appendChild(tnode)
element.replaceWith(elem2)//it replaces element from elem2


///if we want to replace any child with other the use this 
let myul=document.getElementById('myul');
myul.replaceChild(element,document.getElementById('myui'));
//myui must be the child of myul if not then it give error

// we can remove elements also
myul.removeChild(document.getElementById('muuj'));//removes the child with muuj

// to get the attribute of element
// let pr = elem2.getAttribute('class');
let pr = elem2.hasAttribute('class');//return true if the element is present and if not returns false
console.log(elem2);

elem2.removeAttribute('id');//removes attribute from the child
console.log(elem2);
console.log(elem2,pr);




///creating  a heading element with  text as go to website 
// and create an a  tag outside it with href= "google.com";

let elem1=document.createElement('h1');
let text1= document.createTextNode('Go to website');
elem1.appendChild(text1);
console.log(elem1);
elem1.setAttribute('href','google.com');

let l= document.querySelector('ul.this');
l.appendChild(elem1);



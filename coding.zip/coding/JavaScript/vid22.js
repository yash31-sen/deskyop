////1st project on javascript

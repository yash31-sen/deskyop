console.log('hello I am vid9');
//lops in java script
// for (let i=0; i<=10;i++)
// {
//     console.log('Hello '+i)
// }
// let j=0;
// while(j<=15){
//     console.log('Hello '+j);
//     j++;
// }'

// let k=0;

// do {
//     console.log(k);

//     k++;
// }while(k<=12);

// break and contineu statement in loops in java script
// let k=0;

// do {
    // if(k===8){
        //     break;
        // }
//         if(k===8){
//             k++;
//             continue;
//         }
//         console.log(k);
//     k++;
// }while(k<=12);

// let arr=[5,6,8,9,10];
// arr.forEach(function(element,index, arr){
//     console.log(element,index,arr);
// });
// another way to print the whole arry is
// for(let i=0; i<arr.length;i++){
//     const element=arr[i];
//     console.log(element)

// }

// for calling object in an array
let obj={
    name: "Rohan Das",
    age:78,
    type:"dangeorus coder",
    os:"ubuntu"
}
for(let key in obj)
{
    console.log(`The ${key} of object is ${obj[key]}`)
}


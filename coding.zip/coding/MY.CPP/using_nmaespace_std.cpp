#include <iostream>
// using namespace std;/////.may be not recomended
///////////// if we use this then there ar ealot of variables to dedclare in a namespace::var_name
using std ::cout;
using std ::endl;//it is recomended
using std ::string;
//////// if we wantto declare two variable with the same name it will gives an error so to resolve this error we use this;

namespace namespace1
{
    int a = 2;

}
namespace namespace2
{
    int a = 34;
    string b = "I an Yash";
}
int main()
{
    cout << namespace1::a << endl;
    cout << namespace2::b << endl;
    cout << namespace2::a << endl;
    cout << "I ma Yash" << endl;
    return 0;
}

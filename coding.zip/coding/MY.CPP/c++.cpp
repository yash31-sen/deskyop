// # include<iostream>
// using namespace std;
// int i=5;
// int display(){
//         int i=555;
//         cout<<i<<endl;
//         cout<<::i;
// return 0;
//     }

// int main()
// {display();
// return 0;
// }

// #include <iostream>
// using namespace std;
// int main()

// {
//     for (int i = 1; i <= 10; i++)
//     {


//         /////condition for brak  -->  on writnig cout after the if it will not print 4 also because it break it beofre printing
//         /////condition for contoinue --> use cout after  if
//         if (i == 4)
//         {
//             continue;
//         }
//         cout << i << endl; 
//         // i++;

//         // it will print
//         // 0
//         // 2
//         // 4
//         // 6
//         // 8
//         // 10

//         // and if do i++ again it will increase the diffrence between the no.
//     }
//     return 0;
// }
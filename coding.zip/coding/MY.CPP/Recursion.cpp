///Recursions

# include<iostream>
using namespace std;

//////*******function to calculate the factorial of no.
// int factorial(int n){
//     //base condition
//     if(n<=1){
// return 1;
//     }
//     return n*factorial(n-1);
// }



//////// function for fibonaccis series
int fibo(int n){
if (n<2){
    return 1;
}
return fibo(n-2)+fibo(n-1);
}
int main()
{int a;
    cout<<"Enter the number you want factorial or fibonacci no of"<<endl;
    cin>>a;
// cout<<"The factorial of "<<a<<" is "<<factorial(a)<<endl;
cout<<"The fibonacci no at that place is "<<fibo(a);
    return 0;
}
/*n! =n*(n-1)! , 3! = 3*2*1=6, 3*(2)!=3*2*1 =6

*/
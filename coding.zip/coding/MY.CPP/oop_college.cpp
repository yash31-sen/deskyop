//*************************************** Program 1*********************

// # include<iostream>
// using namespace std;
// class Bike{
//     public:
//     string company;
//     string color;
//     int number;
//     string type;
// };
// int main(){
//     Bike b1 , b2;
//     b1.color="Red";
//     b1.company="Honda";
//     b1.type="Sports";
//     b1.number=12565;
//     b2.color="Black";
//     b2.company="Hero";
//     b2.type="Sports";
//     b2.number=5643;
//     cout<<b1.color<<endl;
//     cout<<b1.company<<endl;
//     cout<<b1.number<<endl;
//     cout<<b1.type<<endl;
//     cout<<b2.color<<endl;
//     cout<<b2.company<<endl;
//     cout<<b2.number<<endl;
//     cout<<b2.type<<endl;
//     return 0;
// }

// *******************************************Program 2********************

// # include<iostream>
// using namespace std;
// class Student{
//     public:
//     int id;
//     string name;
//     void insert(int i,string n){
//         id =i;
//         name =n;
//     }
//     void display(){
//          cout<<id<<" "<<name<<endl;
//     }
// };
// int main()
// {
//     Student s1;
//     Student s2;
//     s1.insert(201,"Yash");
//     s2.insert(202,"Shardul");
//     s1.display();
//     s2.display();
//     return 0;
// }

// ************************

// # include<iostream>
// using namespace std;
// class Student{
//     public:
//     int no;
//     float num;
// };
// int main()
// {
//    Student c1,c2;
//     c1.no=10;
//     c1.num=1.5;
//     c2.no=13;
//     c2.num=1.5;
//     cout<<"The no is"<<" " <<c1.no<<endl;
//     cout<<"The num is"<<" " <<c1.num<<endl;
//     cout<<"The no is"<<" " <<c2.no<<endl;
//     cout<<"The num is"<<" " <<c2.num<<endl;
//     return 0;
// }

// **************************3

// #include <iostream>
// using namespace std;
// class Test
// {
//     static int x;

// public:
//     static int y;

//     void func(int x)
//     {
//         cout << "Value of static x is " << Test::x;
//         cout << "\n Value of local x is" << x;
//     }
// };
// int Test::x = 1;
// int Test::y = 2;
// int main()
// {
//     Test obj;
//     int x = 3;
//     obj.func(x);
//     cout << "\n Test::y = " << Test::y;
//     return 0;
// }



# include<iostream>
using namespace std;
class A{
protected:
float x;
A(){
    x=10.25;
}

};
class B{
protected:
float x;
B(){
    x=100.25;}
};
class C : public A, public B{
public:
void fun(){

    cout<<"A's x is "<<A::x;
    cout<<" \n B's x is "<<B::x;
}

};

int main()
{ C c;
c.fun();
    return 0;
}

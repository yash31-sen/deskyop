# include<iostream>
using namespace std;
void greet();
int main()
{

    void greet(){
    cout<<"Good Morninig"
};
greet();

    return 0;
}


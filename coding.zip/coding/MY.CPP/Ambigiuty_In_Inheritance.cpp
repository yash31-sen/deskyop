//////REsolving Ambiguiry in c++ classes
///if we have same name of function in all the classes suppose greet then it is the question that which class function is call in the derived class,,, for resolving this we use this ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓


# include<iostream>
using namespace std;
class Base1{
    public:
        void greet(){
            cout<<"How are you?"<<endl;
        }
};

class Base2{
    public:
        void greet()
        {
            cout << "Kaise ho?" << endl;
        }
};


class Derived : public Base1, public Base2{
   int a;
   public:
    void greet(){
        Base2 :: greet();
        ///////thisis how we done a ambiguioty resolution in c++

    }
};


class A{
    public:
     void as(){
         cout<<"HI A"<<endl;

     }
};
class B{
    public:
     void as(){
         cout<<"HI B"<<endl;

     }
};
class C : public A ,public B{
    public:
    void as(){
         cout<<"HI C"<<endl;
///////////////Here we also use same funcion name for all classes but here  i this case it print the as fuinction of the last class i.e. derived class
     }
};

int main(){
  // Ambibuity 1
    //  Base1 base1obj;
    //  Base2 base2obj;
    //  base1obj.greet();
    //  base2obj.greet();
    //  Derived d;
    //  d.greet();
C a;
a.as();

    return 0;
}



/*best example of ambiguity resolution is  class Base inheritance*/
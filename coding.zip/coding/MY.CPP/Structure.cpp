// # include<iostream>
// using namespace std;
//  struct employee
// {
//  int eid;
//  float salary;
//  string name;
// int arr[10];
// }r;



// int main()
// {
 
//     // ep r;
//     // r.eid=4545;
//     // r.salary=12000000000;
//     // r.name="RRrr";
// // cout<<"Enter 5nos.";
//     // for(int i=0;i<5;i++){
//     //     cin>>r.arr[i];
//     // }
//     r.arr[0]={45};
//     r.arr[1]={5};
//     r.arr[2]={55};
//     r.arr[3]={555};
//     r.arr[4]={100};

   

//     for(int i=0;i<5;i++){
//         cout<<r.arr[i];
//         if(i<4){///////very imp concept to remove last comma from loop 
//             cout<<",";
//         }
//     }
//     // r.arr[10]={45,56,89,52,25 };
//     // cout<<r.eid<<endl;
//     // cout<<r.salary<<endl;
//     // cout<<r.name<<endl;

//     // return 0;
// }





///////*********************union in c++
# include<iostream>
using namespace std;
union money {
    int rice;
    char car;
    float pounds;

};
int main()
{
    // union money m1;
    // m1.rice=5;
    // m1.car='c';///gives garbage value with m1.rice without it it runs
    // // cout<<m1.rice;////if print only one the also gives the right output
    // cout<<m1.car;
    



    enum meal{lunch,brekfast,dinner};
    meal m1=brekfast;
    // cout<<m1;
    cout<<(m1==2);////if true retrun 1 if false return 0

    return 0;
}
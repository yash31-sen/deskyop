// ////// Define a function that returns the product of two numbers entered by user.
// # include<iostream>
// using namespace std;
// inline int sum(){
//     int a;
//      int b;
//     cout<<"Enter the value of a and b"<<endl;
// cin>>a>>b;
//     return a+b;
// }
// int main()
// {
//     cout<<sum();
//     return 0;
// }


// /////Define two functions to print the maximum and the minimum number respectively among three numbers entered by user.
// # include<iostream>
// using namespace std;
//     int a,b,c;
// void getValue(void){
//     cout<<"Enter the value of a , b and c"<<endl;
//     cin>>a>>b>>c;
// }
// void fGreater(void){
//     if(a>b && a>c){
//         cout<<"a is greater"<<endl;
//     }
//     else if (b>a && b>c){
//          cout<<"b is greater"<<endl;
//     }
//     else if (c>a && c>b){
//          cout<<"c is greater"<<endl;
//     }
// }
// void fLesser(void){
//     if(a<b && a<c){
//         cout<<"a is lesser"<<endl;
//     }
//     else if (b<a && b>c){
//          cout<<"b is lesser"<<endl;
//     }
//     else if (c<a && c<b){
//          cout<<"c is lesser"<<endl;
//     }
// }
// int main()
// {
//     getValue();
//     fGreater();
//     fLesser();
//     return 0;
// }


/////// Define a program to find out whether a given number is even or odd.
// # include<iostream>
// using namespace std;
// int a;
// void getValue(void){
//     cout<<"Enter the value of a "<<endl;
//     cin>>a;
// }
// void checkEvenOdd(void){
//     if(a==0){
//         cout<<"Not even not odd"<<endl;
//     }
//     else if(a%2==0){
//         cout<<"It is even no."<<endl;
//     }
//     else{
//         cout<<"It is odd no."<<endl;
//     }
// }
// int main()
// {
//     while(1){
//     getValue();
//     checkEvenOdd();}
//     return 0;
// }


////// Define a function to find out if number is prime or not.
// # include<iostream>
// using namespace std;
// void getValue(void){
//     cout<<"Enter the value of a "<<endl;
//     cin>>a;
// }
// int main()
// {
//     return 0;
// }




// # include<iostream>
// using namespace std;

// int main()
// { int n;
// cin>>n;
// int arr[n];
// for(int i=1;i<=n;i++){
//     cout<<"Enter the value at "<<i
// <<"th index"<<endl;
// cin>>arr[i];
// }
// for(int j=1;j<=n;j++){

// // cout<<"the value at "<<j<<"index is "<<arr[j]<<endl;

// int sum=0;
// if(arr[j]==j){
//     cout<<arr[j];
// }

// }
//     return 0;
// }



// # include<iostream>
// #include<string>

// using namespace std;
// int main()
// {
//     string i="45656";
//     cout<<int( );
//     return 0;
// }


# include<iostream>
# include<string.h>
using namespace std;

class A;
class Boy{
    public:
    string name;
    int Class;
    char section;
public:
void setId(){
    cout<<"Enter Name"<<endl;
    cin>>name;
    cout<<"Enter Class"<<endl;
    cin>>Class;
}
// friend void show(Boy &b);
friend void A:: show(Boy &b);
};

class A{
    public:
void show(Boy &b){
cout<<"the name is :"<<b.name<<endl<<"the class is :"<<b.Class;
}};
int main()
{
Boy b1;
b1.setId();
A a;
a.show(b1);
    return 0;
}
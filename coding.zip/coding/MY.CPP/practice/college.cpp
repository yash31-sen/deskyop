// #include <bits/stdc++.h>
// using namespace std;
// int main()
// {
//     int arr[] = {6, 10, 5, 4, 9, 120, 4, 6, 10};
//     // int i,j;
//     int n = sizeof(arr) / sizeof(arr[0]);
//     // cout<<"enter the element of an array"<<endl;
//     for (int i = 0; i < n; i++)
//     {
//         // Check if the picked element is already printed
//         int j;
//         for (j = 0; j < i; j++)
//             if (arr[i] == arr[j])
//                 break;
//         // If not printed earlier, then print it
//         if (i == j)
//             cout << arr[i] << "\U0001F600";
//     }
//     // printDistinct(arr, n);
//     return 0;
// }

#include <iostream>
using namespace std;
int main()
{
    string a = "yash";
    // cout<<a.reserve();
    printf("%s", &a);
    return 0;
}
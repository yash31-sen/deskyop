# include<iostream>
using namespace std;
int main()
{
    int i;
    cin>>i;
    cout<<i;
    return 0;
}

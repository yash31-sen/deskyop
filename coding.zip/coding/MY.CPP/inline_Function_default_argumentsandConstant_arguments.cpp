////inline function default arguments and constant arguments


////→→ do not use inline functions for large function,with static variables,with lopps and etc 
/////→→ use it only for small like for sum ,product and other


// # include<iostream>
// using namespace std;
// inline int sum(int a,int b){
//     return a+b;
// }
// int main()
// {
//     cout<<"The sum is "<<sum(7,45);
//     return 0;
// }





/////////////**static keyword
// # include<iostream>
// using namespace std;

// int product(int a, int b){
// static int c = 0;////******static keyword return only ones the given the given value and then increases it as per given↓↓↓↓↓↓******************************
// c  = c + 2;////←←←←///need to type it without it this function does not work
// return a*b+c;
// }
// int main()
// {int a,b;
// a=1;
// b=2;
// cout<<product(a,b)<<endl;
// cout<<product(a,b)<<endl;
// cout<<product(a,b)<<endl;
// cout<<product(a,b)<<endl;
// cout<<product(a,b)<<endl;
// // for(int i =0;i<=5;i++){
// //     int a=2;
// //     int b=2;
// //     static int c = 0;
// // c  = c + 1;
// // cout<<a*b+c<<endl;
// // }

//     return 0;
// }






//////////////default argument
// # include<iostream>
// using namespace std;
// float moneyrecieved(int currentMoney, float factor=1.04){////factor=1.04 is default argument to the function
//     return currentMoney*factor;
// }
// int main()

// {
//     int money=100000;
//     float  fac=1.1;/////here we overwrite the default argument
//     cout<<"the interest is "<<moneyrecieved(money,fac);
//     return 0;
// }





/////////***************const keyword
# include<iostream>
using namespace std;
void strlen(){
   string s1 = "Welcome to javatpoint";  
const int len = s1.length();  


cout<< "length of the string is : " << len;  
    
}
int main()
{
    
    strlen();
    return 0;
}


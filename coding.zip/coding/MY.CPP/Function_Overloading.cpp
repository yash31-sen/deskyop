# include<iostream>
using namespace std;

int sum (int a,int b){
    cout<<"I am using 2 arg";
    return a+b;

}
int sum (int a,int b,int c){
    cout<<"I am using 3 arg";
    return a+b+c; 

}
//cylinder
int vol(double r,int h){
    return (3.14*r*r*h);
}


//cube
int vol(int a){
    return (a*a*a);
}
// //ractangular box
int vol(int l,int b,int h){
    return (l*b*h);
}
int main()
{
    cout<<"The sum is"<<sum(5,6,8)<<endl;
cout<<"The sum is "<<sum(5,8);
cout<<"The volume of ractangle box is "<<vol(5,6,4)<<endl;
cout<<"The volume of cube is"<<vol(2)<<endl;
cout<<"The volume of cylinder is "<<vol(5,5);

    return 0;
}

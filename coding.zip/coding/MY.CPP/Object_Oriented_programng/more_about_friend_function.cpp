# include<iostream>
using namespace std;
class X{
    int data;
    public:
    void setValue(int value){
        data=value;
    }
};
class Y {
    int data;
    public:
    void setValue(int value){
        data=value;
    }
}
int main()
{
    return 0;
}
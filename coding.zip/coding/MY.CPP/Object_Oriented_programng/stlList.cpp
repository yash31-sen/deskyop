#include <iostream>
#include <list> //list is birectional linear list ,ifficient operation of insertionor deletion.
using namespace std;
void display(list<int> &lst)
{
    list<int>::iterator it;
    for (it = lst.begin(); it != lst.end(); it++)
    {
        cout << *it << " ";
    }
    cout << endl;
}
int main()
{
    list<int> list1;
    list<int> list2(3); // empty list of 7 elements
    list1.push_back(7);
    list1.push_back(6);
    list1.push_back(6);
    // // list1.pop_back();
    // list1.pop_front();
    // list1.remove(6);//remove al the occurence of the given no.
    // cout<<list1;
    // display(list1);
    // cout << list1.size();
    // cout<< *iter<<" ";
    list<int>::iterator iter;
    iter = list2.begin();
    *iter = 45;
    iter++;
    *iter = 8;
    iter++;
    *iter = 5;
    // list1.merge(list2);
    // list1.sort();
    // list1.reverse();
    list1.swap(list2);
    display(list1);
    return 0;
}
rTemp=ptr;
int p,i;
////Nesting of memeber functions(amzing concept)
#include <iostream>
using namespace std;

class Binary
{
    string s;

public:
    void read(void);
    void chk_bin(void);
    void ones_comp(void);
    void display(void);
};
void Binary ::read()
{
    cout << "Enter a binary no." << endl;
    cin >> s;
}
void Binary ::chk_bin(void)
{
    for (int i = 0; i < s.length(); i++)
    {
        if (s.at(i) != '0' && s.at(i) != '1')
        {
            cout << "Incorrect binary format" << endl;
            exit(0);
        }
    }
}
void Binary ::ones_comp(void)
{
        chk_bin();
    for (int i = 0; i < s.length(); i++)
    {
        if (s.at(i) == '0')
        {
            s.at(i) = '1';
        }
        else
        {
            s.at(i) = '0';
        }
    }
}
void Binary ::display(void)
{

    for (int i = 0; i < s.length(); i++)
    {
        cout << s.at(i);
    }
}
int main()
{
    Binary B;
    B.read();
    // B.chk_bin();///////we can call this functon inside any function of that class this s called nesting of member function and it i shide from the user ,,,,it is called in function display
    B.ones_comp();
    B.display();
    return 0;
}

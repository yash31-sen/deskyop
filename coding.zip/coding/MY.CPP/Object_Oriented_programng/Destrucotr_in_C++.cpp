////////////Destructro in c++
////1Destructro never takes an arguments  nor returns any value , compiler automatically call it to clear the storage


//////When we make an object construcotr called and when compiler feels that we don't need tha tobject ehn it automatically call the constructor

# include<iostream>
using namespace std;
int count=0;
class Num{
    public:
    Num(){
count++;

cout<<"This is the time when constructor is called for object number"<<count<<endl;


    }

    ~Num(){
        cout<<"This is the time when destrucot called for object no."<<count<<endl;
        count--;
    }
};

int main()
{
    cout<<"We are inside our main funccion"<<endl;
    cout<<"Creating first object n1"<<endl;
    Num n1;
    {
        cout<<"Enetering the block"<<endl;
        cout<<"Creating two more objects"<<endl;
        Num n2,n3;
        cout<<"Exiting this block"<<endl;
    }
    cout<<"Back to main"<<endl;
    return 0;
}

# include<iostream>
using namespace std;

class Complex{
    int real , imaginary;
    public:
    void getData(){
        cout<<"The real part is "<<real<<endl;
        cout<<"The imaginary part is "<<imaginary<<endl;
    }
    void setData(int a ,int b){
         real=a;
        imaginary=b;
    }
};
int main()
{


    // ////making object of calss from pointer 
// Complex n1;
//     Complex *ptr = &n1;
//     n1.setData(5,4);
//     n1.getData();
// Complex n1;
//     Complex *ptr = &n1;
//    ( *ptr).setData(5,4);
//     (*ptr).getData();///here braces are important because . hacve more precidence than * so it will call or executed first  but if we use () then it will execute first



Complex *ptr = new Complex;
(*ptr).setData(45,89);
(*ptr).getData();

Complex *ptr1=new Complex[4];
ptr1-> setData(1,4);
ptr1-> getData();
(ptr1+1)-> setData(1,4);
(ptr1+1)-> getData();
// (ptr1+40)-> setData(10,40);
// (ptr1+40)-> getData();///i dont know why this thing run here


    return 0;
}

///////////////Copy constructor in c++


# include<iostream>
using namespace std;
//////////////WE muct eed to make an default condtructor to runa  constructor with arguments



class Number{
int a;
public:
Number(){
    a=0;
}
Number(int num){
a=num;
}
//////Copy constructor
Number(Number &obj){
    cout<<"Copy constructor called!!!"<<endl;
    a=obj.a;

}

void display(){
    cout<<"The number for this object is "<<a<<endl;
}
};
int main()
{
    Number x,y(56),z,z2;
    x.display();
    y.display();
   
    z.display();

    Number z1(y); // Copy constructor invoked
    z1.display();

    z2 = y; // Copy constructor not called,we cant invoke copy constructro without giving class as a retrun type
    z2.display();

    Number z3 = y; // Copy constructor invoked
    z3.display();

    return 0;
}

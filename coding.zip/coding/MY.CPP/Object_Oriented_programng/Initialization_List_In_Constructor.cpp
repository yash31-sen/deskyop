# include<iostream>
using namespace std;

class Test{
    int a ;
    int b;
    public:
    // Test(int i, int j):a(i),b(j){
    // Test(int i, int j):a(i),b(j+i){
    // Test(int i, int j):a(i),b(a+b){////returns garbage value as b value is not defined at that time
    // Test(int i, int j):a(i),b(a+j){
    Test(int i, int j):   b(i) , a(a+i){////returns garbage value as b value is not defined at that time
        cout<<"Constructor executed"<<endl;
        cout<<"Valule of a is "<<a<<endl;
        cout<<"Valule of b is "<<b<<endl;

        

    }
};
//////// syntax for inintializztion section
int main()
{

    Test t(4,6);

    return 0;
}

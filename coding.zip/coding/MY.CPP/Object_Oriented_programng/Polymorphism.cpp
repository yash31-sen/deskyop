# include<iostream>
using namespace std;
int main()
{
    ////polymorpism means 
    /////// - one name and multiple forms
    //////-   like operattor loading ,function overloading
//types of polymorphism 
///run time and compile time poly,orphism  



////// 1. compile time(early binding )   --> achieved by teo ways -> by ***fnction overloading and ***function overloading 

/////////run time  --> achieved with the help  virtual functions 

    return 0;
}

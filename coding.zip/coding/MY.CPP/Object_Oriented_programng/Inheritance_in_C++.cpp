//////Inheritance in c++

//////overview of inheritance

/* 
1.Reusability is a very important feature of OOPs
2.In c++ we can we reusea class and additional features to it
3. Reusing classes saves time and money
4.  Reusing already tested and debugged class will save a lot of efforts of developing debugging the same thimg again.


===> The existing class is called base class
====> new class is called derived class




There are diffrent types of inheriteance in c++
1. Single inheritance 
2. Multiple innheritance(Derived calss with more than one base class)
3.Hierarchicahl (Several derived classe from songle derived class)
4. Multilevel; Inheritance (
    deriving a class from already derived class
)
5. Hybrid inheritance(
    combination of two inheritances other than single+multilevel
    Multiple inheritance + multilevel inheritance= hybrid inheritance
)





*/








/////Inheritance Syntax & Visibility Mode in c++




////////*****Vsibility mode in c++ 
////////if mode is private than public members of bases class will become privaet members of derived class
///////// if mode is public than public members of base class will become public members of derived class
/////////Privavte members can not acces any how directly from base class 

# include<iostream>
using namespace std;
////Base class
class Employee{
    public:
    int name;
    int id;
    long salary;
    
    Employee(){};
    Employee(int inpId){
id=inpId;
salary=100000000;
    }


};


class Programmer : public Employee{
public:
int languageCode =9;
Programmer(int inpId){
  id = inpId;
  salary=100000000;
}

};
int main()
{Employee h1(12);
cout<<"The id of Employee is "<<h1.id<<" and the salary of this employee is "<<h1.salary<<endl;
Programmer skillF(10);
cout<<"The id of Employee is "<<skillF.id<<" and the salary of this employee is "<<skillF.salary<<endl;
cout<<skillF.id;
cout<<skillF.languageCode;
    return 0;
}

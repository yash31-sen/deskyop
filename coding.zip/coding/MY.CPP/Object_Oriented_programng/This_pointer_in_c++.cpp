# include<iostream>
using namespace std;
class  A{
int a;
public:
// void setData(int a){
 /////↓↓with the help of this and return this we can use object->setdata()as a object to other function a sit returns the object the same class
A & setData(int a){
    this->a=a;
    return *this;
}
void getData(){
    cout<<"The value of a is "<<a<<endl;
}
};
int main()
{
    A a;
    a.setData(100).getData();
    // a.getData();
    return 0;
}

# include<iostream>
using namespace std;

class App;
class User{
    friend  class App;
void allow(App o1)
{
  
    if(o1.getans=="yes")
    
}
void camera(){
    cout<<"opening camera"<<endl;

}
void storage(){
    cout<<"Opening fole manager"<<endl;
}

void location(){
    cout<<"Giving your location to this app"<<endl;
}
void contact(){
    cout<<"Opening Contacts"<<endl;
}
 
};

class App{
    string getans;
void getLocPermission(){
    cout<<"Access to location"<<endl;
    cin>>getans;
}
void getcontactPermission(){
    cout<<"Access to contacts"<<endl;
}
};
int main()
{
    return 0;
}

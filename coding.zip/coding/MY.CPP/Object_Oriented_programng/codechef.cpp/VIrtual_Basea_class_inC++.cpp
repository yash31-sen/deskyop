# include<iostream>
using namespace std;

class Student{

    protected:
    int rollno;
    public:
    void setno(int a ){
        rollno=a;

    }void printno(void){
        cout<<"Your roll no is "<<rollno<<endl;
    }
};
class Test : virtual public Student{
    protected:
    float maths,physics;
    public:
    void setMArks(float m1,float m2){
        maths=m1;
        physics=m2;
    }
void printmarks(void){
    cout<<"Your reult is here "<<endl
    <<"Maths"<< maths<<endl<<"Physics "<<physics<<endl;
}
};
///////virtual public anfd punblic virtual both are hte same things we can use any of them
class Sports: virtual public Student{
    protected:
    float score;

public:
void stScore(float sc){
    score =sc;
}
void printScore(void){
    cout<<"Your Pt score is "<<score<<endl;
}
};

class Result: public Test,public Sports{
private:
float total;
public:

void display(void){
    total=maths+physics+score;
    printno();
    printmarks();
    printScore();
    cout<<"Your total score is : "<<total<<endl;
}

};
int main()
{
    Result res;
    res.setno(45000);
    res.setMArks(90,90);
    res.stScore(90);
    res.display();
    return 0;
}

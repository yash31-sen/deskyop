// // // # include<iostream>
// // // using namespace std;
// // // int main()
// // // {
// // //     //////The first line of the input contains a single integer T denoting the number of test cases. The description of T test cases follows.
// // // int t;
// // // cin>>t;
// // // cout<<"Now t is "<<t<<endl;
// // // int A,B,C,D;
// // //     cin>>A>>B>>C>>D;
// // // while(t--){
// // //     if((A+B+C+D)==360){
// // //         cout<<"Yes";
// // //     }
// // //     else{
// // //         cout<<"No";
// // //     }}
// // //     return 0;
// // // }

// // ////Chess Match
// // // # include<iostream>
// // // using namespace std;
// // // int main()
// // // {
// // //     int t;
// // //     cin>>t;
// // //     int n,a,b;

// // //     while(t--){
// // //         cin>>n>>a>>b;
// // //         cout<<360+2*n-(a+b);
// // //     }
// // //     return 0;
// // // }

// // // ///////cut the board

// // // # include<iostream>
// // // using namespace std;

// // // int main()
// // // {int t;
// // // cin>>t;
// // // while(t--){
// // // int n,m;
// // // cin>>n>>m;
// // // cout<<(n-1)*(m-1);
// // // }
// // //     return 0;
// // // }

// // /*
// // n rows , m columns

// // edge with comman edge 16

// // */

// // ///////Minion

// // // # include<iostream>
// // // using namespace std;
// // // int main()
// // // {
// // // int t;
// // // cin>>t;
// // // cout<<"Now t is "<<t;
// // // while(t--){
// // //     int n,k;
// // //     cin>>n>>k;

// // // }

// // //     return 0;
// // // }

// // // A program to demonstrate the use of stringstream

// // /* 
// // pooja ko chaie x $ 
// // // if x$*5 hten get money else not
// // bank charge is 0.50$/withdraw

// // let pooja ab = bal
// // bal . after wihdraw =bal-x*0.50

// // 10,5,15,100,120


// // */

// // // # include<iostream>
// // // using namespace std;

// // // int main()
// // // {
// // // 	int x;
// // // 	int bal;
// // // 	cout<<"Enter the amount in th ebank balance"<<endl;

// // // 	cin>>bal;

// // // 	cin>>x;
// // // /////20,000
// // // if (x%5==0){
// // // 	cout<<bal-x-0.50<<endl;
// // // }
// // // else {
// // // 	cout<<bal;
// // // }

// // // 	return 0;
// // // }

// // // # include<iostream>
// // // using namespace std;
// // // int main()
// // // {int t;
// // // cin>>t;
// // // while(t--){
// // // 	int x;
// // // 	cin>>x;

// // // 	if(x>=1 && x<100){
// // // 		cout<<"Easy"<<endl;
// // // 	}
// // // 	else if (x>=100 && x<200){
// // // 		cout<<"Medium"<<endl;

// // // 	}
// // // 	else if (x>=200 && x<=300){
// // // 		cout<<"Hard"<<endl;
// // // 	}
// // // }
// // // 	return 0;
// // // }

// // /*


// // alice ={  1,3,5}
// // bob={2,4,6 }



// // */

// // #include <iostream>
// // using namespace std;
// // void print(int arr[],int n){
// // 	for (int i=0;i<n;i++){
// // 		cout<<arr[i];
	
// // }
// // cout<<endl;}
// // int main()
// // {
	
// // 		const int n=10;
// // 		// cin >> n;
// // 		int arr[n];
// // 		for (int i=0; i <n; i++)
// // 		{
// // 			cin>>arr[i];
			
			
// // 		}
// // // print(arr,n);

// // 	// }


// // 	return 0;
// // }




// // # include<iostream>
// // # include<string>
// // using namespace std;
// // int main()
// // {
// // 	/* string is in binary formate
// // 	ie string M='10101'*/
// // 	int t;
// // 	cin >>t;
	
    


// // 	while(t--){
// // 		int N,M;
// // 	cin>>M>>N;
// // 	string S;
// // 	S=M;
// // 	S=N;
// // cout<<M<< endl<<N;
// // 	}
// // 	return 0;
// // }



// # include<iostream>
// using namespace std;
// int main()
// {
// 	int  t;
// 	cin>>t;
// 	while(t--){
// 		int n;///no.of players
// 		string s;
// 		cin>>s;
	
// 	}

// 	return 0;
// }




//////8/12/21

///// 1.)
/*Utk-> A ,B,C

oreder of prefrence -> A,B,C

recieved offer from com[pany -> x,y

if(X>y){
	cout<<x;

}
else(cout<<y;
)
]


*/


# include<iostream>
using namespace std;

int main()
{
	int t;
	cin>>t;
	char FIRST,SECOND,THIRD;
	char x,y;
	while(t--){
		
		cin>>FIRST>>SECOND>>THIRD;
	
		cin>>x>>y;

		if(x==FIRST && y==SECOND){
			cout<<x<<endl;

		}
		else if (x==FIRST && y==THIRD){
			cout<<x<<endl;
		}
		else if(x==SECOND &&y==FIRST){
			cout<<y<<endl;
		}
		else if(x==SECOND && y==THIRD){
			cout<<x<<endl;
		}
		else if(x==THIRD && y==FIRST){
			cout<<y<<endl;
		}

else if (x==THIRD && y==SECOND){
	cout<<y<<endl;

}}

	return 0;
}

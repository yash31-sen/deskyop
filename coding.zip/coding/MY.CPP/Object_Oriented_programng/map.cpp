# include<iostream>
# include<map>
# include<iterator>
using namespace std;
int main()
{
    // ios_base::sync_with_stdio(false);
map<string,int>marks;
marks["atul"]=52;
marks["rohit"]=42;
marks["kish"]=85;
marks.insert({"koll",40});
marks.erase("koll");
marks.erase("kish");
map<string,int>::iterator iter;

for(iter=marks.begin();iter!=marks.end();iter++){
    cout<<(*iter).first<<" "<<(*iter).second<<"\n";
}
cout<<marks.max_size();

    return 0;
}



# include<iostream>
using namespace std;
class Employee{
    private:
    int a,b,c;///we can not use them outside the class only function of that class can use them
    public:
    int d,e;//////we can use them   everywhere outside or inside the class
    void setData(int , int ,int );
    void getData(){
        cout<<"The value of a is "<<a<<endl;
        cout<<"The value of b is "<<b<<endl;
        cout<<"The value of c is "<<c<<endl;
        cout<<"The value of d is "<<d<<endl;
        cout<<"The value of e is "<<e<<endl;
    };
};
////we can define the function outside the class in this way↓↓↓↓↓
void Employee :: setData(int a1,int b1,int c1){
a=a1;
b=b1;
c=c1;
}
int main()
{
    Employee ge;

    // ge.a=56;////we can not do like thar=t it will dive an error

    ge.d=144;
    ge.e=455;
    ge.setData(1,5,6);
    ge.getData();
    return 0;
}
/*******we can create the object of class like this also 
class Employee{
    class definition
}name1,name2,name3;
*/


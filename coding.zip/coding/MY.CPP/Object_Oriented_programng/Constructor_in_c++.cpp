// // # include<iostream>
// // using namespace std;
// // ///classes are costum data type not an special entity
// // class Complex
// // {
// // int a,b;

// // /////Creating a constructor -->
// // ///constructor is a special member fumction with the samw=e name as of the class
// // /////it is used to initialize the objects of its class
// // /////it is automatically invoked whenever an objectis created
// // /////constructior have no return type if return type is there then it is not a constructor


// // public:

// // Complex(void);
// // void printNumber(){
// //     cout<<"Your number is "<<a<<" + "<<b<<"i"<<endl;

// // }
// // };

// // Complex :: Complex(void){///this is default costructor
// //     a=10;
// //     b=56;
// // }
// // int main()
// // {
// //     Complex c;
// //     c.printNumber();
// //     return 0;
// // }
// /////////Characteristics of constructor
// /*
// 1. It must be declared in the public section of the class
// 2. They are automatically invoked whenever the functoin calss
// 3. They cannot return values and do not have return types 
// 4.It can have default arguments
// 5.We cannot refer ti their address
// .*/





// ///////Parameterized construnctor and Destructor


// // # include<iostream>
// // using namespace std;

// // class Complex
// // {int a,b;
// // public:
// // Complex(int, int);/////this is parameterized constructor taking two arguments

// // void print(){
// //     cout<<"The value of a md b is "<<a<<"+"<<b<<"i"<<endl;

// // }
// // };


// // Complex :: Complex(int x, int y){///this is default costructor
// // //   cout<<"Enter the value of a and b"<<endl;
// // //   cin>>a>>b;
// // a=x;
// // b=y;


// // }
// // int main()
// // {

// //     ///////ways to call parameterized Constructor
// //     //////Implicit call
// //     Complex a(4,6);
// //     a.print();

// //     ///Explicit call
// //     Complex b= Complex(5,7);

// //     b.print();



// //     return 0;
// // }





// // # include<iostream>
// // #include<cmath>
// // using namespace std;


// // class Point{
// //     int x,y;
// //     public:
// // friend int pDistance(Point ,Point);
// //     Point(int a, int b){
// //         x=a;
// //         y=b;

// //     }

// //     void displayPoint(){
// //         cout<<"The point is ("<<x<<", "<<y<<")"<<endl;
// //     }
// // };





// // //////////create a function which takes 2points objecrs and compute the distance between those two points
// // ////Formula for calculating the distance between two points is d=√((x_2-x_1)²+(y_2-y_1)²)




// // int pDistance(Point a,Point b){
// //  int z= sqrt(((a.x-b.x)*(a.x-b.x))+((a.y-b.y)*(a.y-b.y)));
// //  return z;
// // }




// // int main()
// // {Point a(1,1);
// // a.displayPoint();


// // Point b(1,1);
// // b.displayPoint();
// // int result= pDistance(a,b);
// // cout<<result;
// // return 0;
// // }








// ///////Constructor overloading in c++


// // # include<iostream>
// // using namespace std;
// // class Complex{


// //     int a ,b;
// //     public:
// //     Complex()
// //     {
// //         a=0;
// //         b=0;
// //     }
// //     Complex(int x,int y){
// //         a=x;
// //         b=y;
// //     }

// //     Complex(int x){
// //         a=x;
// //         b=0;
// //     }////////we can make a no. of construnctor

// //     void printNumber(){
// //         cout<<"Your number is "<<a<<" + "<<b<<"i"<<endl;
// //     }
// // };
// // int main()
// // {
// //     Complex a(1,5);
// //     a.printNumber();
// //     Complex b(5);
// //     b.printNumber();
// //     Complex c;
// //     c.printNumber();
// //     return 0;
// // }






// //////Constructor with default arguments in c++


// // # include<iostream>
// // using namespace std;

// // class Simple{

// //     int data1;
// //     int data2;
// //     int data3;
// //     public:
// //     Simple(int a, int b=8,int c=11){
// //         data1=a;
// //         data2=b;
// //         data3=c;
// //     }
// //     void printData();

// // };

// // void Simple :: printData(){
// //     cout<<"The value of data is "
// // <<data1<<" , "<<data2<<" and "<<data3<<endl;
// // }
// // int main()
// // {
// //     Simple s1(1);
// //     s1.printData();
// //     return 0;
// // }





// ///////Dyanic Initialiozation of using constructor
// ///this code for ----> when we use int constructor wuth unt arggument runs and if we use float in run time then constructor eith float tpe arggument runs

// /*as we overload consrtuctor we can dynamically allocate the memory to the constructor as when int argument then in runtime int type constructor run or vic-versa*/
// # include<iostream>
// using namespace std;

// class BankDeposit{
//     int principle;
//     int year;
//     int intrestrate;
//     int returnValue;
// public:
// BankDeposit(){}//////Here we use blank constructor because if we we cant give the value of p,r,y, then anything need to run if it is not there then programe will not run and produce an error .
// BankDeposit(int p,int y,float r);/////r can be a va;ue likke 0.04
// BankDeposit(int p,int y,int R);/////r can be a va;ue likke 14
// void show();
// };


// BankDeposit ::BankDeposit(int p,int y ,float r){
//     principle =p;
//     year=y;
//     intrestrate=r;
//     returnValue=principle;
//     for (int i=0;i<y;i++){
//         returnValue=returnValue*(1+r);
//     }
// }



// BankDeposit :: BankDeposit(int p,int y ,int r){
//     principle =p;
//     year=y;
//     intrestrate=float(r)/100;
//     returnValue=principle;
//     for (int i=0;i<y;i++){
//         returnValue=returnValue*(1+intrestrate);
//     }
// }


// void BankDeposit :: show(){
//     cout<<"Principle amount was "<<principle<<endl<<" Retrun value after "<<year<< " is "<<returnValue<<endl;
// }

// int main()
// {
// BankDeposit bd1,bd2,bd3;
// int p,y;
// float r;
// int R;


// cout<<"Enter the value of p y and r"<<endl;
//     cin>>p>>y>>r;
//     bd1 = BankDeposit(p, y, r);
//     bd1.show();

// cout<<"Enter the value of p y and R"<<endl;
//     cin>>p>>y>>R;
//     bd2 = BankDeposit(p, y, R);
//     bd2.show();
//     return 0;
// }

























#include<iostream>
using namespace std;


class BankDeposit{
    int principal;
    int years;
    float interestRate;
    float returnValue;

    public:
        BankDeposit(){}
        BankDeposit(int p, int y, float r); // r can be a value like 0.04
        BankDeposit(int p, int y, int r); // r can be a value like 14
        void show();
};

BankDeposit :: BankDeposit(int p, int y, float r)
{
    principal = p;
    years = y;
    interestRate = r;
    returnValue = principal;
    for (int i = 0; i < y; i++)
    {
        returnValue = returnValue * (1+interestRate);
    }
}

BankDeposit :: BankDeposit(int p, int y, int r)
{
    principal = p;
    years = y;
    interestRate = float(r)/100;
    returnValue = principal;
    for (int i = 0; i < y; i++)
    {
        returnValue = returnValue * (1+interestRate);
    }
}

void BankDeposit :: show(){
    cout<<endl<<"Principal amount was "<<principal
        << ". Return value after "<<years
        << " years is "<<returnValue<<endl;
}
int main(){
    BankDeposit bd1, bd2, bd3;
    int p, y;
    float r;
    int R;
    
    // bd3.show();

    cout<<"Enter the value of p y and r"<<endl;
    cin>>p>>y>>r;
    bd1 = BankDeposit(p, y, r);
    bd1.show();

    cout<<"Enter the value of p y and R"<<endl;
    cin>>p>>y>>R;
    bd2 = BankDeposit(p, y, R);
    bd2.show();
    return 0;
}
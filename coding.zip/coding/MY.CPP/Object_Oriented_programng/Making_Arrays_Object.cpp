// // /////Making Array of Objects
// #include <iostream>
// using namespace std;



// class Employee
// {
//     int id;
//     int salary;
// static int count;
// static int count1;
// public:
//     void setData(void)
//     {
//         salary = 100000;
//         cout << "Enter the id of Employee no."<<count+1 << " : ";
//         cin >> id;
//         count++;
//     }
//     void getData()
//     {
//         cout << "The id of employee no. "<<count1 +1<<" is "<< id << endl;
//            count1++;
//     }
// };
// int Employee ::count;
// int Employee ::count1;
// int main()
// {
//     Employee fb[5];
//     for (int i = 0; i < 5; i++)
//     {
//         fb[i].setData();
//     }
//     for (int i = 0; i < 5; i++)
//     {
//         fb[i].getData();
//     }
//     return 0;
// }





/////////Passing on=bject as a argument of function

// # include<iostream>
// using namespace std;
// class Complex
// {
// int a;
// int b;

// public:
// void setData(int v1,int v2){
//     a=v1;
//     b=v2;
//     // cout<<a<<endl;
//     // cout<<b<<endl;

// }
// void setDataBySum(Complex o1,Complex o2){
// // a=a+a;
// // b=b+b;
// a=o1.a+o2.a;
// b=o1.b+o2.b;
// // cout<<"***********"<<o1.a<<endl;
// // cout<<"***********"<<o2.a<<endl;
// // cout<<"***********"<<o1.b<<endl;
// // cout<<"***********"<<o2.b<<endl;
// // cout<<"***********"<<a<<endl;
// // cout<<"***********"<<b<<endl;
// }
// void printNumber(){
//     cout<<"Your complex no. is "<<a<<" + "<<b<<"i"<<endl;
// }
// };
// int main()
// {
//     Complex c1,c2,c3;
//     c1.setData(1,2);
//     c1.printNumber();
//     // c2.setData(1,2);
//     // c2.printNumber();
//     c1.setDataBySum(c1,c1);
//     c1.printNumber();

//     return 0;
// }




# include<iostream>
using namespace std;
class Yash{
int id;
public:
void getData(int var)
{
id=var;
cout<<id;
}
void showData(Yash o1){
id=o1.id+o1.id;
cout<<id;
}
void printData(){
    cout<<"The id of this is "<<id;
}
};
int main()
{
    Yash c1,c2;
    c1.getData(4);
    c1.showData(c1);
    c1.printData();


    return 0;
}

// #include <iostream>
// #include <vector>
// using namespace std;
// void display(vector<int> &v)
// {

//     for (int i = 0; i < v.size(); i++)
//     {
//         cout << v[i] << " ";
//         // cout << v.at(i) << " ";//works same as the eabove one
//     }
// }
// int main()
// {

//     vector<int> vec1;//zero length integer vector
//     vector<int>vec2(4);//4 element character vector
//     vector<int>vec4(6,15);//prints 15 6 times
//     vec2.push_back(5);
//     cout<<"displaying vector";
//     // display(vec2);
//     vector<int>vec3(vec2);
//     display(vec4);
//     // int element;
//     // int size;
//     // cin >> size;
//     // cout << "Enete the element";
//     // for (int i = 0; i < size; i++)
//     // {
//     //     cin >> element;
//     //     vec1.push_back(element);
//     // }
//     // vector<int>::iterator iter = vec1.begin();
//     // // vec1.insert(iter+1 , 56,66);
//     // // vec1.pop_back();//din't work
//     // vec1.erase(element);
//     // display(vec1);
//     return 0;
// }

// #include <iostream>
// #include <vector>
// using namespace std;
// int main()
// {
// int elem;
//     // vector<int> vec1;
//     vector<int> vec1;
//     for (int i = 0; i <= 4; i++)
//     {
//         cin>>elem;
//         vec1.push_back(elem);

//     }
//     for (int i = 0; i <= 4; i++)
//     {
       
//        cout<<vec1[i];
//     }
//     return 0;
// }

// // lists
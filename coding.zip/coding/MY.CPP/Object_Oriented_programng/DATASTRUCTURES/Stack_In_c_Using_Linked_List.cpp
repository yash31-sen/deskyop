#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int data;
    struct Node *next;
};
struct Node *top = 0;
void push(int x)
{
    struct Node *newNode;
    newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->data = x;
    newNode->next = top;
    top = newNode;
}

void peek()
{
    if (top == 0)
    {
        printf("stack is empty \n");
    }
    else
    {
        printf("The elemnt at the top of stack is %d \n", top->data);
    }
}
void display()
{
    struct Node *ptr;
    ptr = top;
    if (top == 0)
    {
        printf("Stack is empty \n");
    }
    else
    {
        while (ptr != 0)
        {
            printf("The element of stack is %d \n", ptr->data);
            ptr = ptr->next;
        }
    }
}

void pop()
{
    struct Node *ptr;
    ptr = top;
    if (top == 0)
    {
        printf("Nothing to show \n");
    }
    else
    {
        printf("The deletd element is %d \n", top->data);
        top = top->next;
        free(ptr);
    }
}
int main()
{
    push(1);
    push(2);
    push(3);
    push(4);
    push(5);
    push(6);
    pop();
    pop();
    pop();
    pop();
    display();
    peek();
    // printf("Running peek");
    // peek();

    // peek();
    // display();
    return 0;
}

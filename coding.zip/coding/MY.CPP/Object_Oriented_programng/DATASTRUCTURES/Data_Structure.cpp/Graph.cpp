#include <stdio.h>

/*how to represent a graph in computer :- there are two ways to represent a graph in computer 
1.) By adjecancy matrix(n*n)
2.) By Adjecancy list     
*/
int main()
{
    
    return 0;
}
#include <stdio.h>
const int N = 5;
int s1[N];
int s2[N];
int top1 = -1, top2 = -1;
void push1(int data)
{
    if (top1 == N - 1)
    {
        printf("Queue oveflow");
    }
    else
    {
        top1++;
        s1[top1] = data;
    }
}
int count;
void enqueue(int x)
{
    push1(x);
    count++;
}
////↑↑↑↑↑↑↑ here we first create a stack 1 push all the elements we want to push in the queue and then pop these all elements and then push them into he stack 2 then again pop them from stack 2 and again push into the stack 1

int pop1()
{
    return s1[top1--];
}
void push2(int data)
{
    if (top2 == N - 1)
    {
        printf("Queue oveflow");
    }
    else
    {
        top2++;
        s2[top2] = data;
    }
}
int pop2()
{
    return s2[top2--];
}
void dequeue()
{
    int a, b;
    if (top1 == -1 && top2 == -1)
    {
        printf("The Queue is empty\n");
    }
    else
    {
        for (int i = 0; i < count; i++)
        {
            push2(pop1());
        }
        b = pop2();
        printf("The dequed elemetn is %d \n ", b);
        count--;
        for (int i = 0; i < count; i++)
        {
            a = pop2();
            push1(a);
        }
    }
}

void display()
{
    for (int i = 0; i <= top1; i++)
    {
        printf("The value is %d \n", s1[i]);
    }
}
int main()
{
    enqueue(5);
    enqueue(2);
    enqueue(3);
    enqueue(1);
    dequeue();
    display();

    return 0;
}

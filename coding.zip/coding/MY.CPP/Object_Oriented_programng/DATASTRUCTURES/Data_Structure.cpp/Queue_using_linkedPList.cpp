# include<stdio.h>
# include<stdlib.h>
struct Node{
int data;
struct Node *next;
};
struct Node *front=0;
struct Node *rear=0;

void enqueue(int x){
    struct Node* newnode;
    newnode=(struct Node*)malloc(sizeof(struct Node));
    newnode->data=x;
    newnode->next=0;
    if(front==0 && rear==0){
        front=rear=newnode;
    }
    else{
        rear->next=newnode;
        rear=newnode;
    }
}

void dispplay(){
    struct Node* temp;
    
    if(front==0 && rear==0){
        printf("Queue is empty\n");
    }
    else{
        temp=front;
        while(temp!=0){
        printf("The data of queue is  %d \n",temp->data);
        temp=temp->next;
    }}
}
void dqueue(){
    struct Node* temp;
    temp=front;
    if(front==0 && rear==0){
        printf("te queue is empty\n");

    }
    else{
         printf("The deleted element is %d ",front->data);
       front=front->next;
       free(temp);

    }
}

void peek(){
    if(front==0 &&rear==0)
{
    printf("the queue is empty\n");

}
else{
    printf("the top element is %d",front->data);
}
}
int main()
{
    enqueue(5);
    enqueue(56);
    enqueue(62);
    enqueue(100);
    dqueue();
    dispplay();
    peek();
    return 0;
}

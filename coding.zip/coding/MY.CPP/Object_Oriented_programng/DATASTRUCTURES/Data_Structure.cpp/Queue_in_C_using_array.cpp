#include <stdio.h>
const int N = 5;
int queue[N];
int front = -1;
int rear = -1;

void enqueue(int x)
{
    if (rear == N - 1)
    {
        printf("Overflow \n");
    }
    else if (front == -1 && rear == -1)
    {
        rear = front = 0;
        queue[rear] = x;
    }
    else
    {
        rear++;
        queue[rear] = x;
    }
}
void dequeue()
{
    if (front == -1 && rear == -1)
    {
        printf("Queue is empty\n");
    }
    else if (front == rear)
    {
        front = rear = -1;
    }
    else
    {
        printf("The deleted element is %d", queue[front]);
        front++;
    }
}

void display()
{
    if (front == -1 && rear == -1)
    {
        printf("\nQueue Underflow");
    }
    else
    {
        for (int i = front; i < rear + 1; i++)
        {
            printf("\nThe element in queue is %d", queue[i]);
        }
    }
}
void peek()
{
    if (rear == -1 && front == -1)
    {
        printf("Queue is Underflow\n");
    }
    else
    {
        printf("\nThe top element in the queue is %d", queue[front]);
    }
}

int main()
{
    enqueue(0);
    enqueue(1);
    enqueue(2);
    enqueue(3);
    dequeue();
    display();
    peek();
    return 0;
}

// #include <stdio.h>
// const int N = 5;
// int queue[N];
// int front = -1;
// int rear = -1;

// void enqueue(int x)
// {
//     if (front == -1 && rear == -1)
//     {
//         front = rear = 0;
//         queue[rear] = x;
//     }
//     else if ((rear + 1 % N) == front)
//     {
//         printf("Queue is full\n ");
//     }
//     else
//     {
//         rear = (rear + 1) % N;
//         queue[rear] = x;
//     }
// }
// void dequeue(){
//     if(front==-1 &&rear==-1){
//         printf("Queue is empty\n");

//     }
// else if (front==rear){
//     front=rear=-1;
// }
// else{
//     printf("the dequeued element is %d \n",queue[front]);
//     front=(front+1)%N;
// }
// }
// void display(){
//     int i=front;
//     if(front==-1 &&rear==-1){
//         printf("The queue is empty\n");

//     }
//     else{
//         while(i!=rear){
//             printf("The element in the queue is %d \n",queue[i]);
//             i=(i+1)%N;
//             printf("\n \n \n\n%d \n\n \n\n",i);
//         }
//         printf("the element in the queue is %d \n",queue[rear]);
//     }
// }
// void peek(){
//     if(front==-1&&rear==-1){
//         printf("the queue is empty\n"
//        );}
//         else{
//             printf("The top element of queue is %d\n",queue[front]);

//         }
//     }

// int main()
// {
//     enqueue(4);
//     enqueue(3);
//     enqueue(2);
//     enqueue(1);
//     enqueue(0);
//     dequeue();
//    display();
//    peek();

//     return 0;
// }

// Circular Queue implementation in C

// #include <stdio.h>

// #define SIZE 5

// int items[SIZE];
// int front = -1, rear = -1;

// // Check if the queue is full
// int isFull() {
//   if ((front == rear + 1) || (front == 0 && rear == SIZE - 1)) return 1;
//   return 0;
// }

// // Check if the queue is empty
// int isEmpty() {
//   if (front == -1) return 1;
//   return 0;
// }

// // Adding an element
// void enQueue(int element) {
//   if (isFull())
//     printf("\n Queue is full!! \n");
//   else {
//     if (front == -1) front = 0;
//     rear = (rear + 1) % SIZE;
//     items[rear] = element;
//     printf("\n Inserted -> %d", element);
//   }
// }

// // Removing an element
// int deQueue() {
//   int element;
//   if (isEmpty()) {
//     printf("\n Queue is empty !! \n");
//     return (-1);
//   } else {
//     element = items[front];
//     if (front == rear) {
//       front = -1;
//       rear = -1;
//     }
//     // Q has only one element, so we reset the
//     // queue after dequeing it. ?
//     else {
//       front = (front + 1) % SIZE;
//     }
//     printf("\n Deleted element -> %d \n", element);
//     return (element);
//   }
// }

// // Display the queue
// void display() {
//   int i;
//   if (isEmpty())
//     printf(" \n Empty Queue\n");
//   else {
//     printf("\n Front -> %d ", front);
//     printf("\n Items -> ");
//     for (i = front; i != rear; i = (i + 1) % SIZE) {
//       printf("%d ", items[i]);
//     }
//     printf("%d ", items[i]);
//     printf("\n Rear -> %d \n", rear);
//   }
// }

// int main() {

//   enQueue(1);
//   enQueue(2);

//   display();
//   deQueue();

//   display();

//   return 0;
// }

// C program for insertion sort
#include <math.h>
#include <stdio.h>

/* Function to sort an array using insertion sort*/
void insertionSort(int arr[], int n)
{
	int i, key, j;
	for (i = 1; i < n; i++)
	{
		key = arr[i];
		j = i - 1;

		/* Move elements of arr[0..i-1], that are
		greater than key, to one position ahead
		of their current position */
		while (j >= 0 && arr[j] > key)
		{
			arr[j + 1] = arr[j];
			j = j - 1;
		}
		arr[j + 1] = key;
	}
}

// A utility function to print an array of size n
void printArray(int arr[], int n)
{
	int i;
	for (i = 0; i < n; i++)
		printf("%d ", arr[i]);
	printf("\n");
}

/* Driver program to test insertion sort */
int main()
{
	int arr[] = {12, 11, 13, 5, 6};
	int n = sizeof(arr) / sizeof(arr[0]);

	insertionSort(arr, n);
	printArray(arr, n);

	return 0;
}

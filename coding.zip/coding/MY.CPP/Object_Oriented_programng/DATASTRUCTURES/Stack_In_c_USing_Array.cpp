// # include<stdio.h>
// int stack[5];
// int top =-1;
// void push(){
// int x;
// while(top!=4){
// printf("Enter the data to enter in stack : ");
// scanf("%d",&x);
// // while(top!=4){
// if(top==4){
//     printf("Stack Overflow");
// }
// else{
//     top++;
//     stack[top]=x;}
// }
// }

// void pop(){
//     int item;
// while(top!=-1){
//     // top--;
//     if(top==-1){
//         printf("Stack Underflow");}
//         else{
//             item=stack[top];
// top--;
// printf("The deleted element from stack is %d \n ",stack[top]);
//         }

// }}
// void printData(){
//    for(int i =top;i>=0;i--){
// if(top!=-1){
//     printf("The element in stack is %d \n" ,stack[i]);
// }
// }
// }
// int main()
// {
// push();
// pop();
// printData();
// // printData();
//     return 0;
// }

#include <stdio.h>
// # define N 5;
// int N=5;
int stack[5];
int top = -1;
void push()
{
    int x;
    printf("enter the data : ");
    scanf("%d", &x);
    if (top == 4)
    {
        printf("Overflow");
    }
    else
    {
        top++;
        stack[top] = x;
    }
}

void pop()
{
    int item;
    if (top == -1)
    {
        printf("Stack Underflow \n");
    }
    else
    {
        item = stack[top];
        top--;
        printf("%d", item);
    }
}

void peek()
{
    if (top == -1)
    {
        printf("stack overflow \n");
    }
    else
    {
        printf("%d", stack[top]);
    }
}

void display()
{
    int i;
    for (i = top; i >= 0; i--)
    {
        printf("The element is %d \n", stack[i]);
    }
}

int main()
{
    int ch;
    while (ch != 0)
    {
        printf("enter choise 1 for push ,2 for pop , 3 for  peek ,4 for  dsplay \n");
        scanf("%d", &ch);
        switch (ch)
        {
        case 1:
            push();
            break;
        case 2:
            pop();
            break;
        case 3:
            peek();
            break;

        case 4:
            display();
            break;
        default:
            printf("invalid choise");
        }
    }

    return 0;
}

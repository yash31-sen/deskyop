#include<stdio.h>
#include<stdlib.h>


struct Node{
int data;
struct Node *next; 
struct Node *prev;
};


void doublyLinkTrasversal(struct Node *ptr){
    while(ptr!=NULL){
        printf("Element Of DoublyLinkedList is : %d  \n",ptr->data);
        ptr=ptr->next;
    }
}


int main(){

struct Node* n1;
struct Node* n2;
struct Node* n3;
struct Node* n4;


n1=(struct Node*)malloc(sizeof(struct Node));
n2=(struct Node*)malloc(sizeof(struct Node));
n3=(struct Node*)malloc(sizeof(struct Node));
n4=(struct Node*)malloc(sizeof(struct Node));


// ////linking Nodes
n1->next=n2;
n1->data=4;
n1->prev=NULL;

n2->next=n3;
n2->data=55;
n2->prev=n1;



n3->next=n4;
n3->data=50;
n3->prev=n2;


n4->next=NULL;
n4->data=10;
n4->prev=n3;

doublyLinkTrasversal(n1);

}
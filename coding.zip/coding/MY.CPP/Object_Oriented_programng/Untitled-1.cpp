# include<iostream>
using namespace std;

int main()
{
	int t;
	cin>>t;
	char FIRST,SECOND,THIRD;
	char x>>y;
	while(t--){
		
		cin>>A>>B>>THIRD;
	
		cin>>x>>y;

		if(x==A && y==C){
			cout<<x<<endl;

		}
		else if (x==B && y==A){
			cout<<y<<endl;
		}
		else if(x==B &&y==C){
			cout<<x<<endl;
		}
		else if(x==C && y==A){
			cout<<y<<endl;
		}
		else if(x==C && y==B){
			cout<<y<<endl;
		}

else if (x==C && y==B){
	cout<<y<<endl;

}}

	return 0;
}

/////////Exercise of Iheritance

# include<iostream>
using namespace std;

class Scalculator{
    int a;
    int b;

    char selectop;
    public:
    Scalculator(){
        cout<<"If want to Sum press 'p' if want to subtract press 's' if want to multiply press 'm 'and if want to devide press 'd'"<<endl;
        cin>>selectop;

    }
    void setnNo(int s , int t){
        s=a;
        t=b;

cout<<"Enter the nos"<<endl;
cin>>a>>b;
    }
void operation(){

    if (selectop=='p'){
        cout<<a+b<<endl;

    }
   else if(selectop=='d'){
        cout<<a/b<<endl;

    }
   else if(selectop=='m'){
        cout<<a*b<<endl;

    }
   else if(selectop=='s'){
        cout<<a-b<<endl;

    }
}

};

class ScientificCalc{
int x,y,z;
public:

ScientificCalc(){
   cout<<"If want to calculate square root then pressz 'sq' , if want to calculate no in power of 2 then press 'p2' if want to calculate";
}
 
void setVal(int k, int l, int m){
    cout<<"Enter the value of  x, y,z"<<endl;
    cin>>x,y,z;
}


};
int main()
{
    return 0;
}

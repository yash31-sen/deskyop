# include<iostream>
using namespace std;

///////as private vRIbles can never be inherited , protected is the specifier which will remain like private but can be inherited


/* 	Public Derivation       	Private Derivation     	Protected Derivation
Private members            	Not Inherited               	Not Inherited               	Not Inherited              
Protected members            	Protected                     	Private                          	Protected                    
Public members            	Public 	Private                          	Protected     */
class Base{

int a;

int b;
};
class Derived :Base{

};
int main()
{
    return 0;
}














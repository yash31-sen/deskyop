# include<iostream>
using namespace std;

class Shop{
    int id;
    float price;
    public:
   void setData(int a,float b){
id=a;
price=b;
   }

   void getData(){
       cout<<"Code of this item is"<<id<<endl; 
       cout<<"price of this item is"<<price<<endl; 
   }
};
int main()
{
    int size=3;
// int l;
// int p=new int(l);//////we cannot use new with non pointer varaible
Shop *ptr= new Shop[size];
Shop *ptrTemp=ptr;
int p,i;
float q;
for (i=0;i<size;i++){
    cout<<"enter the id and price of item "<<i+1<<endl;
    cin>>p>>q;
    ptr->setData(p,q);
ptr++;
}

for(i=0;i<size;i++){
    cout<<"Item number :"<<i+1<<endl;
    ptrTemp->getData();
    ptrTemp++;
}

    return 0;
}

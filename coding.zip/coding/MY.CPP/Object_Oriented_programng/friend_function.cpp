# include<iostream>
using namespace std;
class Complex{
int a,b;
public:
void getNO(int n1,int n2){
a=n1;
b=n2;
}

void printNO(){
    cout<<"Your number is "<<a<<" + "<<b<<"i"<<endl;
}

///////Friend Function,,,it means that non member - sumcomplesfunction is allowed to do anything with its private data members
friend Complex sumComplex(Complex o1,Complex o2);
};

Complex sumComplex(Complex o1,Complex o2){
Complex o3;
o3.getNO((o1.a+o2.a),(o1.b+o2.b));
return o3;
}
int main()
{
    Complex c1 ,c2 ,sum;
    c1.getNO(1,5);
    c1.printNO();

    c2.getNO(5,6);
    c2.printNO();
    
    sum=sumComplex(c1,c2);
sum.printNO();
    return 0;
}


//////// Properties of freind function
/*
1.it i snot in the scpoe of class
2. Since it is not in the scope of class ,it cannot be called from teh objet of that class  c1.sumComlex() ==> is invalid
3. can be innvoked without he help of any object
4. Ususally contains teh object as arguments
5.can be declared inside public or private section of the class
6.IT cannot acces the member directly by their names and need their names and need object_name.member_name to access any member
we can not do cout<<a;
need to do cout<<o1.a;where o1 is the object of calss Complex or any other class whose friend thos function is.
*/
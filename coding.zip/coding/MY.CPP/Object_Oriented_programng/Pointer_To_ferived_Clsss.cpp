# include<iostream>
using namespace std;

///////// our base class object can  call the derived class objects also 

class BaseClass{
    int var_Base;
void Base(){
cout<<"The value of var is "<<var_Base<<endl;
}
};

class DervedClass : public BaseClass{
     int der_Base;
void Derived(){
cout<<"The value of var is "<<der_Base<<endl;
}
};
int main()
{
    BaseClass * base_class_pointer;
    BaseClass obj_base;
    
    DervedClass obj_derived;
    base_class_pointer = &obj_derived;
    return 0;
}

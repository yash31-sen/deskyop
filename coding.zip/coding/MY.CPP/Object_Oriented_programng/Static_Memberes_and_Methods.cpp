#include <iostream>
using namespace std;
class Employee
{
    int id;
    static int count;
    //////static variable is started by default from 0, if want to initialize it from other no. then declare it outiside the class as dclared in the progrme.
    /////static variable is  a property of class but variable without static is property of object so it first print 1  all the object and then on again running it prints 2 but with static it print 1 for first and hten 2 for second object
public:
    void setData(void)
    {
        cout << "Enter the id of your product" << endl;
        cin >> id;
        count++;
    }
    void getData(void)
    {
        cout << "The id of this employee is " << id << " and this is Employee no " << count << endl;
    }

    /////static function in c++
    static void showCount(){/////static functons have only access to static variables they can't access the normal int float variables
    /////// cout<<id; shows an error because id is not  a static variable
        cout<<"The count is "<<count<<endl;
    }};
int Employee ::count;
int main()
{
    Employee name1, name2, name3;

    name1.setData();
    Employee :: showCount();///////we can access the static function direstly withoujt creating any object
    name2.setData();
     Employee :: showCount();///////we can access the static function direstly withoujt creating any object
    name3.setData();
     Employee :: showCount();///////we can access the static function direstly withoujt creating any object
    name1.getData();
    name2.getData();
    name3.getData();
    return 0;
}

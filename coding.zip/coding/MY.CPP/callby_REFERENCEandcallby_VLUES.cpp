# include<iostream>
using namespace std;
// void swap(int a, int b){////////this will not work
//   int temp=a;
//   a=b;
//   b=temp;
// }



/////  ↓↓ This is call by reference by pointer↓↓ 

void swapPointer(int* a,int* b){
int temp =*a;
*a=*b;
*b=temp;
}


////// ↓↓ call by reference only in**************c++*****************
// void swapbyReferencevar(int &a, int &b){
//   int temp=a;
//   a=b;
//   b=temp;

// }




//////if we do it like that
int & swapbyReferencevar(int &a, int &b){
  int temp=a;
  a=b;
  b=temp;
return b;
}




int main()
{
  int a=2;
  int b=5;
  cout<<"a and b before swap is a "<<a<<" "<<b<<endl;
   
  // swapPointer(&a,&b);
 swapbyReferencevar(a,b);
 swapbyReferencevar(a,b)=766;///by this a is converted into 766 an d with the help of above code(line 32-37)
  cout<<"a and b after swap is a "<<a<<" "<<b;
  return 0;
}























/////swaping eith diff methods(with 3 variabels)

// #include <iostream>
// using namespace std;
// int main()
// {
//     int a = 5;
//     int b = 8;
//   int temp=a;
//     a = b;
//     b = temp;

//    cout<<"The values of a and b is "<<a<<b;

//     return 0;
// }


/////swaping with difff method(with 2 variable)
// #include <iostream>  
// using namespace std;  
// int main()  
// {  
// int a=7, b=5;      
// cout<<"Before swap a= "<<a<<" b= "<<b<<endl;      
// a=a*b; //a=50 (5*10)    
// b=a/b; //b=5 (50/10)    
// a=a/b; //a=10 (50/5) 

// cout<<"After swap a= "<<a<<" b= "<<b<<endl;      
// return 0;  
// }  

///////swaping with diffrent method(with 2 variable)
// # include<iostream>
// using namespace std;
// int main()
// {
// int a=51,b=89;

// cout<<"a and b before swap a= "<<a<<" "<<" b = "<<b;
// a=a+b;//=14
// b=a-b;//=5
// a=a-b;
// cout<<"a and b after swap a= "<<a<<" "<<"b = "<<b;
// return 0;
// }

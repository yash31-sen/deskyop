// # include<iostream>

// using namespace std;
// int main()
// {
// int a=5;
// int* b=&a;////declaring pointer for getting an address of variable a
// ////////& is address of operator and * is value of operator
// // cout<<b<<endl;
// // cout<<*b<<endl;
   

//     ////concept of pointer to pointer in c++

//     int** c=&b;
//     // cout<<c<<endl;
//     int*** d=&c;
//     cout<<d<<endl;
//     cout<<&d<<endl;
//     // cout<<&a<<endl;
//     int val=5;
//     // cout<<&val;
//  return 0;
// }




# include<iostream>
using namespace std;
int main()
{
    // in arrays we get adress of 1st place by typing arr only we will not need to type &arr it is wrong
    int arr[5]={45,56,89,52,25};
    int* p =arr;
//   cout<<*p<<endl;
//   cout<<*(p+1)<<endl;
//   cout<<*(p+2)<<endl;
//   cout<<*(p+3)<<endl;
//   cout<<*(p+4)<<endl;

// for( int i=0;i<=4;i++){
//     cout<<arr[i]<<endl;
// }
for(int j=0;j<=4;j++){
    cout<<*(p+j)<<endl;
}
    return 0;
}
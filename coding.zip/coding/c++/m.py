# Importing the required libraries
import pyautogui, time
# Delay to switch windows
time.sleep(10)
# Load the file contents in read mode
file = "Thank you............"
# loop to spam
count=0
while(count<=500):
        pyautogui.typewrite("Thankyou number: "+str(count))

        pyautogui.press("enter")
        count=count+1
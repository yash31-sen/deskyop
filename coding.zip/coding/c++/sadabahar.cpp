#include <bits/stdc++.h>
using namespace std;
int main(){
string str1="aab";
string str2="xxy";
vector<int>v;
     vector<int>v1;
     int n1=str1.size();
     int n2=str2.size();
     int i=0;
     int c=1;
     while(n1!=0){
         if(str1[i]==str1[i+1]){
             c++;
         }
         else{
             v.push_back(c);
             c=1;
     }
     n1--;
         i++;
     }
     i=0;c=1;
     while(n2!=0){
         
             if(str2[i]==str2[i+1]){
                 c++;
             }
             else{
                 v1.push_back(c);
                 c=1;
             }
             n2--;
             i++;
         
     }
     int ans=0;
     for(int i=0;i<n1;i++){
         if(v[i]==v1[i]){
             ans++;
         }
     }
cout<<ans;
return 0;
}
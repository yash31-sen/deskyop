// /////******variables in js 
// ///var ,let , const
// // var-> global variable scope
// var nare= 'hary';//string
// ////if want to use html in a variable the use backticks `````
// var channel;
// var marks=34//int

// channel='code with harry'///if comment out that line then it will show undefined in the console
// console.log(nare, channel, marks)



// ////rules for creating js variable
// /*cannot start with no.
// can strt with letters or $ or _
// are case sensitive
// */ 


// // cosnt->
// const name='hari ram'
// //if we make a const variable then we must have to initialize it 
// // const no;///xxx
// // const no=4;////right
// const  city='delhi'
// console.log(name)

// // let->block level scope
// {
//     let city ="RAMPUR"

// console.log(city)//let have scope only inside this block hence print rampur only 
// }
// console.log(city)///print here delhi 



// const arr1=[1,2,4,5]
// // arr1=[142,45,5,6]//cant do like that  same with objects
// // but we can add elemetn to it 
// arr1.push(45)
// console.log(arr1)

// //most commom programming case types
// /*cammelCase
// kebab-case
// snake_case
// PascalCase*/


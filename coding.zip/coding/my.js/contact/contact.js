// to create and add element to the webpage

// let createdNode=document.createElement('li');
// createdNode.id='createdNode';
// console.log(createdNode.id);
// let txtNode=document.createTextNode('fourth');
// createdNode.appendChild(txtNode)
// let presentNode=document.getElementById('myli3');
// console.log(presentNode.id)
// presentNode.appendChild(createdNode)
//******************************************************

//to set value to the local storage on click













// // let presentNode=document.getElementById('myli3');
// presentNode.addEventListener('click',function(e){
//     console.log('you clicked on presentnode');
//    let localValue= localStorage.setItem('myli3','1');
//     console.log(localStorage.getItem('myli3'));
// })

// let createdNode=document.createElement('input');
// createdNode.id='createdNode';
// console.log(createdNode.id);
// let txtNode=document.createTextNode('fourth');
// createdNode.appendChild(txtNode)
// presentNode=document.getElementById('myli3');

// presentNode.appendChild(createdNode)

// console.log(localStorage.getItem('Value'))
// let btn=document.getElementById('btn');
// btn.addEventListener('click',function(e){
    
// let localValue=localStorage.setItem('myli3',createdNode.value);
// })
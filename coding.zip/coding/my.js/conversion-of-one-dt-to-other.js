///type conversion and type corcion

let myvar=34; ///integer
console.log(myvar,(typeof myvar)) 
myvar=String(34);
console.log(myvar,(typeof myvar)) 

let boolvar=true
console.log(boolvar,(typeof boolvar)) 
boolvar=String(boolvar)
console.log(boolvar,(typeof boolvar)) 


let  arr=[4,5,6,79]
console.log(arr,(typeof arr))
arr=String(arr)
console.log(arr,(typeof arr))


// to string method
let i=true;
console.log(i.toString())///convert any thing to string 



///no. function
// let str=Number(true);
let str=Number("54454g");////retrun NaN because of g
 str=Number([1,5,4,5,4,8]);////retrun NaN because
console.log(str,typeof str)



//passs int , pass float

let no1=parseInt("34.2")
console.log(no1,(typeof no1))
let no=parseFloat("34.2")
console.log(no,(typeof no))

// /.tofixed  -> after how much point we want to see the deciamls

console.log(no.toFixed(7),typeof no)



////type corcion
let mystr="4545";
let mynum=35;
console.log(mystr + mynum)////  o/p ->454535

console.log("Problem 1")
let a=document.links;

let dtr='org'
Array.from(a).forEach(function(element){
    let g=element.href;
    if(g.includes(dtr)){
        console.log(g);

    }
})
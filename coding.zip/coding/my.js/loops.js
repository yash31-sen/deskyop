///for ,while, dowhile



// for(let i=1;i<=100;i++){
//     console.log(i)
// }

// let j=0;
// while( j<100){
//     console.log(j);
//     j++;
//     // j+=1;both are same
// }



// let k=0;
// do{
//     console.log(k);
//     if(k===5){
//         break;
//     }
//     k++;
// }while(k<=100);



// let k=0;
// do{
    
//     if(k===5){
//         k++;
//         continue;
//     }
//     console.log(k);
//     k++;
// }while(k<10);



/////// more loops

let arr=[1,4,5,2,3,6,7,8,9];
// for(let i=0;i<arr.length;i++
// ){
//     console.log(arr[i])
// }

//////another way

arr.forEach(function(element , index, array){//can place anything in place of no
    console.log(element,index,array);
   
});
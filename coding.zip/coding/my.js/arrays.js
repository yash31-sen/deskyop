// const marks=[4,5,6,7,8,9];
// const fruits=['óranges','apple','pineapple'];
// const mixed=['str',89,[3,5]];

// ///we can crerate an array with help of an array constructor
// let  arr=new Array(22,54,56,89,'orange');
// console.log(arr);
// console.log(mixed);
// console.log(marks);
// console.log(fruits);

// console.log(arr.length);
// console.log(Array.isArray(arr));//check if the enter variable is array or not if yes the  return true else false
// arr[0]='me';
// console.log(arr);


// let val=arr.indexOf(56);//retruns the index of 54
// console.log(val);


// ///mutating or modifying the array


// arr.push(3466);//pushes element in the arr
// arr.unshift(10099);////put the element in the startin index of array
// arr.pop()////pop the element from the last index of array
// arr.shift();//remove the first element from array
// // arr.splice(1,4);////remove th eelements from index 1 to index 4
// arr.reverse();////reverse the array
// console.log(arr);


// ////************ all of th eabove methods changes the original array ***************


// //concating the array
// let arr2=[1,2,3,7]
// arr=arr.concat(arr2)
// console.log(arr);///concatinate or add the arr with arr1

// let myobj = {
//  ' first name':'harry',
//  channel:'cn',
//  marks:[1,2,3,4,5,6]
// }
// console.log(myobj)
// console.log(myobj.channel)
// console.log(myobj['channel'])///both print the same the same thing
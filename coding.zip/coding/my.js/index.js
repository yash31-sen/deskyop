console.time('your code took')//---1
// js array
console.log([34,45,78,89])
//js object
console.log({harry:'this',marks:34})

///the imp thing about js object if we do 
console.table({harry:'this',marks:34})//it will prnt the o ject in tabular formate

//js int float and string
console.log(45)
console.log(45.2)
console.log("hello.js")

//js warning
console.warn('no you are on wrong page')
//clear
// console.clear()//clears the console

///time in js 
console.timeEnd('your code took')//---2
// 1 and 2 will give the timw taken by the code to run

//assertion in js if some enter the age 189 or more which i snot posiibel then we can use this to show an error
console.assert(555<189 , 'this age is not possible')
///to shoe error 
console.error('this not allowed')

////----------------------------------------------------------------------------------------





// Manuplation in js 
//Document object model
///window is global object in js 
/////document is a object of window 



// alert('Hello I am yash sen')///aler and window.alert are dame thing 
// let a=prompt('this website is risky you want to contineu or not ')
// console.log(a)

// a=confirm('are you sure you want to leave the page')//it is a boolean function and retrun true if press ok amd false for cancel

let a;
 a= window.innerWidth;
 a= window.innerHeight;
 a= window.outerHeight;


 /////scrollx and scrolly gives the value of scrollinng of page to to bottom or left to right or vice versa

 a=scrollX;
 a=scrollY;
a=location;
// a=location.href='//github.com'
a=location.toString();///gives the location of hte site in the server or the link of the site
a=window.history;
a=history.length;
a=history.go(-1)////used in back buttons
 console.log(a)

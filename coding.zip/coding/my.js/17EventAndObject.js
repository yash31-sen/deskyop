console.log('hello this is 17');
// document.getElementById('heading').addEventListener('click',function(e){
document.getElementById('heading').addEventListener('mouseover',function(e){
  console.log('you have clicked the heading');
  ////to redirect to any web page
  // location.href='////c/odewithharry.com';
  // let variable=e.target;
  let variable;
  variable=e.target;
  // variable=e.target.className;
  // variabe=Array.from(e.target.classList);
  // variable=e.target.id;
  variable=e.offsetX;////this tell us the integer value wrt x direction in webpage
  variable=e.offsetY;////this tell us the integer value wrt y direction in webpage
  variable=e.clientX;
  variable=e.clientY;
  console.log(variable)

  
});






// document.getElementsByClassName('heading').addEventListener('click',function(e){
//     console.log('You have clicked a heading')
// });


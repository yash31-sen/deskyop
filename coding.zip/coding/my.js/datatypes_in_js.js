/*

primitive dt(memeory allocation in stack) ->
string ,no. , boolean , NULL , undefined ,symbol(recently added in js )=es6





refrence dt(memory allocation in heep) ->  arrays , object literals , functions dates*/

//to print type of data type

let name="yash";
console.log('My name is '+name)
console.log("type of name data type is "+(typeof name))

let nullv=null;///has bogous retrun value 

console.log("type of data type is "+(typeof nullv))


///reference data type
//array
myarr=[1,5,4,'yash',true]
console.log("type of data type is "+(typeof myarr)
)


//object literals 
let stmarks={
    haryy:89,
    rs:85,
    rohan:859

}
console.log(typeof stmarks)


function findName() {

    
}

console.log(typeof findName)

let date = new Date();
console.log(typeof date)
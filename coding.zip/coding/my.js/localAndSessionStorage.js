// let a =localStorage.setItem('Name','Yash');
//  let impArray=['bhindi'/sabzi',JSON.stringify(impArray))////it will convert it into an string representing an array
//  let imp1=localStorage.getItem('sabzi')//////we know it is an array but it prints it in application console as a string 
 /////to overcome this we use json.stringify and 
//  console.log(imp1)////it will show a strin in the console to convert it into an array use this 
//  console.log(JSON.parse(imp1));////now it will shows as an array

// a=localStorage.setItem('Name2','Sen');
// a=localStorage.setItem('Name3','Dev');
// a=localStorage.setItem('Name4','Dev1');
// let name=localStorage.getItem('Name4');
// console.log(name)

// to clear the local storage 
// localStorage.clear();

////to ramove the pariticular element form th elocal storage 
// let name1= localStorage.removeItem('Name');
// let name2= localStorage.removeItem('Name2');
// let name3= localStorage.removeItem('Name3');
// let name4= localStorage.removeItem('Name4');
// let name4= localStorage.removeItem('sabzi');


/////sessionStorage

// let sesArray=['bhindi','adarak','pyaz'];
//  localStorage.setItem('sabzi',JSON.stringify(sesArray))
// sessionStorage.setItem('SessionName2','sessionSen');
// sessionStorage.setItem('SessionName3','sessionDev');
// sessionStorage.setItem('SessionName4','sessionDev1');
// let name=sessionStorage.getItem('Name4');
// console.log(name)
///to clear session storage
// sessionStorage.clear();

////editable div using js
 ////Creating a div editable
//  let heading=document.querySelector('.heading');
//  let eye = document.querySelector('.class')
//  heading.addEventListener('click',func1);
//  function func1(e){
//    console.log('you are on right way');
//    let editt=document.createElement('input');
//    let a=heading.appendChild(editt);
//    let r=a.prompt('Enter the text here')
  
  
//   // localStorage.removeItem('Note');
 
 
//   eye.addEventListener('click',func2);
//  function func2(e){
//    console.log('clicked')
//    a.value='I am an editable div';
 
//    localStorage.setItem('Note',JSON.stringify(r)
//    );
//  }
  
//  }
 
// // console.log('Í am ')

// let cont =document.querySelector('.no')
//  cont =document.querySelector('.conatainer')
// // //  console.log(cont.childNodes);///retrun all the child of given class including text black lines and commented lines 
// //  console.log(cont.childNodes[0].nodeName)
// //  /////retruns the type of name of element 

// // //  console.log(cont.childNodes[0].nodeType)/////retrun  the name of elements by numbers

// //  /*
// //  Node type    NO. to show
// //  element        1
// //  attributr      2
// //  Text node      3
// //  comment        8
// //  document       9
// //  doctype        10
 
// //  */
// // ///if don't want such things use this↓

// // // console.log(cont.children);
// // ////by this we can get children's children's children's ans so on
// // console.log(cont.firstChild);/////retrun the first child of container
// // console.log(cont.lastChild);/////retrun the first child of container
// // console.log(cont.firstElementChild);/////retrun the last child elementdisincluding text blank lines and commented lines of container
// // console.log(cont.lastElementChild);/////retrun the last child elementdisincluding text blank lines and commented lines of container

// // ///retrun all the child of given class not including text black lines and commented lines 


// console.log(cont.childElementCount);///returns the no of element in the given nodes as a child 

// console.log(cont.firstElementChild.nextElementSibling.nextElementSibling)////retrun th e noext element of the child i.i the sibling of the child
let html ;
html="<h1> this is my string heading</h1>"+"<p> i am yash </p";

// if we want to print a lot of strings contineusky then we have to do it by applying + after evrys tring



// we can do it also by the below method of string ↓
html=html.concat('this ','str2 ','to the ');
console.log(html)
console.log(html.length)
console.log(html.toLowerCase());
console.log(html.toUpperCase());////they both are ont changing the original string 

console.log(html[0])///give 1st character
console.log(html[1])///give 2nd character....

console.log(html.indexOf('h1'))//if not a part of string tehn return -1
///of multiple occurence then give 1st occ
// for last index write lastIndexOf()

console.log(html.charAt(10))


console.log(html.endsWith('the'))///if yes return true or not then return false
console.log(html.includes(''))///if in string then return true or not then retrun false 
console.log(html.substring(1,20))
console.log(html.substring(-4 ))///retruns all the character except the last 4
console.log(html.slice(0,4))///return charcter from 0to 4
console.log(html.slice(-4))///return last 4 charcter 


console.log(html.split('a'))////splits the string into an array if we write any thing in place of space in the then it split it from there 


console.log(html.replace('this','it'))////replaces the first occurence of this from it




////template literals in js

let fruit ='orranges'
let fruit1='apples'
let myhtml=`
helllo 
<h1>this is my heading </h1>
<p> you like ${fruit1} and i like ${fruit}
`;

document.body.innerHTML=myhtml;////creating problem

let age =74;

// if (age=='74'){////gives ture
// if (age=='74'){////gives false
if (age!=='74'){////gives true
    console.log('age is 74')
}
else if (age==52){
    console.log('age is 52')
}
else{
    console.log('age is 78')
}



///// == check for value only whereas === check for value and type also if type is diffrent then it gives false 

/////**** as != check for only value !== check for value and type both if any one of them is not true then return false 


let drive=true;

if(drive){
    console.log('you can drive')

}
else {
    console.log('you can not drive')
}


////if else statement with the help of ternarry operator 
console.log(age==45? 'Age is 45': 'Age is not 45');



/////switch case statement in js 
switch (age) {
    case 18:
        console.log('age is 18');
        break;////if we remove break then all the elements after 18 will get printed in the console
    case 74:
        console.log('age is 74');
        break;
    case 89:
        console.log('age is 89');
        break;

    default:
        console.log('you are at unknown age ')
        break;
}
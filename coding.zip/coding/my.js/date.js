console.log('yash sen');

// date time object in js
let today=new Date();///prints date time day etc

console.log(today)////it is type of object 
//for getting other dates 
let otherdate=new Date('8-4-2003 04:54:08');
// otherdate=new Date('June 16 1976');
///formate mm dd yyyy
console.log(otherdate);
console.log(otherdate.getDay());

/*
returns day as numbers
0 for sunday
1 for monday
2 for tuesday
3 for wednesday
4 for ......
*/
console.log(otherdate.getDate());
console.log(otherdate.getMinutes());
console.log(otherdate.getSeconds());
console.log(otherdate.getTime());///return no. of seconds till the given date
console.log(otherdate.getMilliseconds());///return mili seconds
console.log(otherdate.getMonth());///. returns 0 for january ,1 for february

//to set a date
let a=otherdate.setDate(25);
a=otherdate.setMonth(2);
a=otherdate.setFullYear(2000);
a=otherdate.setMinutes(1);
a=otherdate.setSeconds(59);
a=otherdate.setHours(5);
// a=otherdate.setHours(5);
console.log(otherdate)
console.log('ok');


setTimeout(()=>{
    for(let index=1;index<=400;index++){
        const element=index;
        console.log('this is index no.'+index);
    }
},100);

//this will print the nest command fisrt then will continue with self


console.log('done printing');
////object in jd 

// let car={
//     name:'maruti 800',
//     topSpeed:89,
//     run:  function(){
//         console.log('car is running');

//     }
// }


// here new keyword is used to create object of a constructor

// new Date();/////wehave seen already

// console.log(car);
// console.log(car.name);
// console.log(car.topSpeed);
// console.log(car.run);



function GeneralCar(givenName,givenSpeed){
    this.name=givenName;
    this.topSpeed=givenSpeed;
    this.run=function(){
        console.log(`${this.name} is running`);
    };
    this.analyze=function(){
        console.log( `This car is slower by ${200 - this.topSpeed} Km/H than Mercedes`);
    };
}

car1=new GeneralCar('Nissan',180);
car2=new GeneralCar('Maruti',10);
car3=new GeneralCar('Mercedes',900)
// console.log(car3);
console.log(car2.analyze());
// console.log(car1.name);
// console.log(car1.topSpeed);
console.log(car2);
// console.log(car2.name);
// console.log(car2.topSpeed);
// console.log('I am ES6');

// class Employee{

//     ////creating a constructor to call these objects
//     constructor(givenName,givenExperiance,givenDivision){
//         this.name=givenName;
//         this.experiance=givenExperiance;
//         this.divisoin=givenDivision;

//     }
//     ////creatig the function
//     slogan(){
//         return `I am ${this.name} and this is the best comapny`;
//     }
//     joiningYear(){
//         return 2021-this.experiance;
//     }

//     ///static method we don't need to make object of a class to call it 
//     static add(a,b){///can not use this.var in static method
//         return a+b;
//     }
// }
// yash=new Employee('Yash',56,'Division');
// console.log(yash.slogan());

// console.log(Employee.add(34,5));


// class Programmer extends Employee{////inheriting class Employee
//     constructor(givenName,givenExperiance,givenDivision,language,github){
//         super(givenName,givenExperiance,givenDivision,language,github);
//         this.language=language;
//         this.github=github;
//     }
// faviorateLanguage(){
//     if(this.language=='python'){
//         return 'Python';
//     }
//     else{
//         return 'JavaScript';
//     }
// }
// static multiply(a,b){
//     return a*b;
// }
// }


// rohan=new Programmer('Rohan',5000000000,'Lays','Go','Rohan420');
// console.log(rohan.language)
// console.log(Programmer.multiply(5,5));





console.log('hi');

class Employee {
    constructor(givenName, givenSalary, givenExperiance) {
        this.name = givenName;
        this.salary = givenSalary;
        this.expeirance = givenExperiance;
    }
    slogan() {
        return (`hello i am ${this.name} and this company is the best`);

    }


    ///static method we don't need to make object of a class to call it 
    static add(a, b) {///can not use this.var in static method
        return a + b;
    }
}
console.log(Employee.add(1, 6));//no need to make a object here

let emp = new Employee('Emp1', 100000, 2);
console.log(emp);
console.log(`I am ${emp.name}`);

let a = localStorage.setItem('emp', `${emp.name}`);
let omp = new Employee('Omp1', 100000, 2);


emp.slogan();
omp.slogan();




//inheritance
class Programmer extends Employee {
    constructor(givenName, givenSalary, givenExperiance, language, github) {
        super(givenName, givenSalary, givenExperiance)
        this.language = language;
        this.github = github;
    }
    favLang(){
        if(this.language=='python'){
            return 'Python';
        }
        else{
            return 'Javascript';
        }
    }
}



rohan=new Programmer('Rohan',100000,2,'python','rohan420');
console.log(rohan);
console.log(rohan.favLang());
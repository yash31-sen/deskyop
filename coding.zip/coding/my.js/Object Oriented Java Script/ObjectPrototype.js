console.log('this is yash sen ');

////we cannot change the prototye of object directly we can chage it by making its constructor
// let obj={
//     name:'harry',
//     channel:'çodeWithHarry',
//     address:'Marse'
// }

function Obj(givenName)
{
    this.name=givenName;
}

// changin prototype
Obj.prototype.getName= function(){
    return this.name;
}
Obj.prototype.setName= function(newName){
    this.name=newName;
}

let obj2=new Obj('Yash');
obj2.setName('shubh');
////sets the name to shubh
console.log(obj2)
// Object.prototype();////never do it like that only chaneg te prototype of own created object by making a constructor
//if we change the prototype of object then it will overwrite the object prototype in for all objects


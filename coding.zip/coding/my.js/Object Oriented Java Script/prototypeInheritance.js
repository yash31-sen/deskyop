console.log('I am yash');

const proto = {
    slogan: function () {
        return `this company is the best`;
    },
    changeName: function (newName) {
        this.name = newName
    },

    role: function (newRole) {
        this.Role = newRole
    }
}

//     let yash=Object.create(proto);///creating prototype
//     yash.name='yash';
//     yash.role='programmer';
// yash.changeName('yash22');/////thisway we can cahnge the values inide protottype with the help of functions made inside prototype

// let a=yash.slogan();


// console.log(a)




// creating prototype with diffrent methos
// ///***************************** */
// const yash = Object.create(proto);
// yash.slogan()
// 'this company is the best'
// yash.changeName('Yash2')
// // yash.name
// yash.role('programmer')
// console.log(yash)//************************** */

///another syntax
const yash=Object.create(proto,{
    name:{value:'Yash1',writable:true},///to allow upgrading of a variable in this method we have to declare the wriatble : true here for particular variable
    role:{value:'programmer4',writable:true}
})
// yash.role('programmer3');
yash.changeName('Yash32')
console.log(yash)





// /////Prototype Inheritance

// /////Employee constructor
function Employee(name,salary,experiance){
    this.name=name;
    this.slary=salary;
    this.experiance=experiance;
}

///slogan
Employee.prototype.slogan=function(){
    return`This company is the best . Regards,${this.name}`;
}

let yashObj=new Employee('yash',34506460,87);
console.log(yashObj.slogan());

// //Programmer

function Programmer(name,salary,experiance,language){
    Employee.call(this,name,salary,experiance);////Inheriting the constructor
    this.language=language;///non inherites properties programmer own property
}


// ///Inheriting prototype
Programmer.prototype=Object.create(proto);
Programmer.prototype=Object.create(Employee.prototype);


// //Mannualy set the constructoe
Programmer.prototype.constructor=Programmer;


let rohan=new Programmer('rohan',2,0,'JavaScript')
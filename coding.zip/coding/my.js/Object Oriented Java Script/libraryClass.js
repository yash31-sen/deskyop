console.log('this is library calss');
/////excersice 
////creaete  a class liv=brary and implement the follwoing:
//  constructor must take the bokk list as an argument
// getBooklist()
// issueBook(BookName,user)
// returnBook(bookname);


class Library{
    constructor(bookName,bookName1,bookName2,bookName3,user)
    {
        this.bookname1=bookName;
        this.bookname2=bookName1;
        this.bookname3=bookName2;
        this.bookname4=bookName3;
        // this.bookname5=bookName;
        this.user=user;

    }
issueBook(bookName,user){
    console.log(`${this.bookname1} is taken by ${this.user}`);
}
    returnBook(bookName){
        console.log(`${this.user} rwturns the book`);
    }
}

book=new Library('Book1','Book2','Book3','Book4','rahul');
console.log(book.bookname1)
book.issueBook('Physics')
console.log(book.returnBook())
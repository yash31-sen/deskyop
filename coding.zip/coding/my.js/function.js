function greet(name='n',thank='thank you'){
    console.log(`Happy Birthday ${name} 
    ${thank}`)
    return 1
}
let val =greet()
console.log(val)


////// we can make function a variable
const mygreet= function(name,thank){
    console.log(`Happy birthday ${name} 
    you are ${thank}`)
}
mygreet('rahul','thanks a lot')

/////*we can create a function inside an object like 

let myobj={
    name:'skillf',
    game:function(){
        return "GTA";
    }
}
console.log(myobj.game())//if we do myobj.game then it will return the whole function 
//////for getting return value only write myobj.game()




arr=['fruit','vegetables','furniture'];
arr.forEach(function(element ,index,array){
    console.log(element,index)
});



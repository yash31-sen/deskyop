// console.log('18');
// let btn=document.querySelector('body')
// // let btn=document.getElementById('  heading');
// // btn.addEventListener('click',func1);
// // btn.addEventListener('dblclick',func2);
// // btn.addEventListener('mousedown',func3);
// // btn.addEventListener('mouseenter',func4);
// // btn.addEventListener('mouseleave',func5);
// btn.addEventListener('mousemove',func6);
// function func1(e){
//   console.log('thank ypu for clicking here');
//   e.preventDefault();
// }
// function func2(e){
//   console.log('thank you for dbl clicking here');
//   e.preventDefault();
// }
// function func3(e){
//   console.log('thank you for mouse down here');
//   e.preventDefault();
// }
// function func4(e){
//   console.log('its mouse enter event ');
//   e.preventDefault();
// }
// function func5(e){
//   console.log('its mouse leave event ');
//   e.preventDefault();
// }
// function func6(e){
//   console.log('its mouse move event ');
// document.body.style.backgroundColor=`rgb(${e.offsetX},${e.offsetY},154)`;
//   e.preventDefault();
// }
console.log('Yash Sen');
////Maths object in js 
let x=3;
let y=4;
let z;
z=x+y;
z=x-y;
z=x*y;
z=x/y;

////exploring the Math object

z=Math;
z=Math.PI;
z=Math.max(1,5,4,8,6);
z=Math.min(4,5,7,8);
z=Math.pow(2.3);//returns 3 to the power 3 i.e 8
z=Math.sqrt(5);////return the root of the no. i.e 49 to  7
z=Math.floor(5.9);//always returns the value to the lower round of figure
z=Math.ceil(5.2);///always return the value to the hogher round of figure

z=Math.round(5.9);//return value in rounf of figure
z=Math.abs(-5.7);///return absolute value of the given no. like -5 to 5 -5.7 to 5.7


console.log(z);///gives all the functions of math object

//creating the node or element

let elem=document.createElement('li')
let text=document.createTextNode('I am a text Node')
elem.className='child1'
elem.id='child1i'
elem.appendChild(text)

let ul =document.querySelector('.ul')
ul.appendChild(elem);
// console.log(elem)


let elem2=document.createElement('h3')
elem2.id='elem2'
elem2.class='elem2i'
let tnode=document.createTextNode('this node is created for elem2')
elem2.appendChild(tnode)
// elem.appendChild(elem2)
elem.replaceWith(elem2)


// we can replace a already created element from html with other element
////*******with the condtion that both the element which is to be replacing or which is to be replaced ar belong to the same class or id or are insidethe same class same class or id


let myu=document.getElementById('myul')
myu.replaceChild(elem2,document.getElementById('fui'))




////removing child
myu.removeChild(document.getElementById('ui'));




let pr=elem2.getAttribute('class');
pr=elem2.getAttribute('id');//////retrun attributes of element
pr=elem2.hasAttribute('class');
pre=removeAttribute('id');////removes the attribute

//if yes return true else false 





// console.log('hello this is yash')
// let elem=document.createElement('li')
// let text=document.createTextNode('I am a text Node');
// elem.appendChild(text);
// // let ab=elem.innerHTML='5'
// elem.style.color='black'
// elem.className='child1';
// elem.id='child2';

// elem.setAttribute('title','mytitle');
// elem.setAttribute('placeholder','i am here')
// // let elem1=elem.parent;

// console.log(elem)
// let ul=document.querySelector('.child');
// // ul1.innerHTML='this is not runnig '

// // to whow the created element elem in webpage
// ul.appendChild(elem)
// console.log(elem)

////above all to create a text node and to display it in a webpage 
////**************************************************************************
////////Now to replace a element form webpage  to other element

///replacing li 

// let elem2=document.createElement('h3');
// elem2.id='elem2';
// elem2.className='elem2';
// let tnode=document.createTextNode('this node is created for elem2');
// elem2.appendChild(tnode);
// elem.replaceWith(elem2)

// ////we can erplace already created element in html with other element in this way


// let myul=document.getElementById('muyul');
// // let fui=document.getElementById('fui');
// myul.replaceChild(elem,document.getElementById('fui'))





///////*******quick quiz

// let create=document.createElement('h1');
let create=document.createElement('a');
create.innerHTML=' Go to code wih harrry';
create.className='heading';
create.id='headingi';
create.setAttribute('href','https:www.codewithharry.com');
let elem=document.querySelector('.non');
elem.appendChild(create)

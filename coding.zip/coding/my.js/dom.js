// console.log('dfjsdfhn')
// //*******we can't add for each loop to html collections */
// /*
// element selctors in js 
// 1. single element selector
// 2.multi element selector

// */
let element= document.getElementById('.myfirst')
// // let element=document.querySelector("#myfirst");
// // // element=document.getElementById('myfirst');

// // // element=element.parentNode;
// // element.style.color=red;
// // console.log(element)
element.innerText='I am yash sen';///changes input text inside the selected div
// // element.innerHTML=`<b>I am a good boy</b>`;///changes the inner html of the selcted div 
// // console.log(element)



let sel=document.querySelector('#myfirst');
// sel.style.color='white';///als chanegs the color of div 


// // we can use this in place of Array.for each but Array.foreach is better way
// for (let index = 0; index < element.length; index++) {
//     const element = elem[index];
//     console, log(element)
//     element.style.color = 'blue';
// }



// ///////multielement selector
// // let elem=document.getElementsByClassName('child');
// // // console.log(elem)
// // console.log(elem[0])////give the first element


// // let elem=document.getElementsByClassName('conatainer');
// // // console.log(elem)
// // console.log(elem[0].getElementsByClassName('child'))////give all the classes with child name inisde container div



// // Array.from(elem).forEach(element=>{
// //     console.log(element);
// //     element.style.color='blue';
// // })
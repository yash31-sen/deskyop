let a =document;
// a=document.all;
// a=document.body;
// a=document.forms

// console.log(a);///it is only array type object but we cannot use array functions here
// a.forEach doesn't run here
// Array.from(a).forEach(function(element){
//     console.log(element);
// })

// Array.from() ////makes an array with html collection and then we can use document.all to print as an array
a=document.links;
console.log(a)
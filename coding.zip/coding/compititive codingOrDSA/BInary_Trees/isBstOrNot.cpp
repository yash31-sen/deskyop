//// 1.) pre order traversal

///////c code for pre order traversal

/*
4
/ \
1   6
/\
5  2
*/

#include <stdio.h>
#include <malloc.h>
struct node
{
    int data;
    struct node *left;
    struct node *right;
};

node *createNode(int data)
{
    struct node *n;
    n = (struct node *)malloc(sizeof(struct node));
    n->data = data;
    n->right = NULL;
    n->left = NULL;
    return n;
}
node *linkNode(struct node *o, struct node *o1, struct node *o2)
{
    o->left = o1;
    o->right = o2;
    return o;
}

void preOrder(struct node *root)
{
    if (root != NULL)
    {
        printf("%d ", root->data);
        preOrder(root->left);
        preOrder(root->right);
    }
}

////c  code for post-order traversal
void postOrder(struct node *root)
{if (root != NULL)
    {
    postOrder(root->left);
    postOrder(root->right);
    printf("%d ", root->data);}
}

/////c code for in-order traversal

void inOrder(struct node* root){
    if(root!= NULL){
        inOrder(root->left);
        printf("%d ",root->data);
        inOrder(root->right);
    }
}

/////to know is bst or not 

int isBst(struct node* root){
    static struct node *prev=NULL;
    if(root!= NULL){
       if(!isBst(root->left)){
           return 0;
       }
       if(prev!=NULL && root->data<= prev->data){
           return 0;
       }
       prev=root;
       return isBst(root->right);

    }
    else{
        return 1;
    }
}
int main()
{
    struct node *p;
    struct node *p1;
    struct node *p2;
    struct node *p3;
    struct node *p4;
    p = createNode(5);
    p1 = createNode(3);
    p2 = createNode(6);
    p3 = createNode(1);
    p4 = createNode(4);

    p->left = p1;
    p->right = p2;
    p1->left = p3;
    p1->right = p4;

    // linkNode(p,p1,p2);////linking the nodes with the hekp of function
    // p->left = p1;
    // p->right = p2;///linking node directly
    preOrder(p);
    printf("\n");
    postOrder(p);
    printf("\n");
    inOrder(p);
    printf("\n");
   if(isBst(p)){
       printf("This is a bst");
   }
   else{
       printf("This is not a bst");

   }
    return 0;
}
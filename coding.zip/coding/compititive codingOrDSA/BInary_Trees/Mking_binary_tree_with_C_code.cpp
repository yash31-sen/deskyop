#include <stdio.h>
#include <malloc.h>
struct node
{
    int data;
    struct node *left;
    struct node *right;
};

node *createNode(int data)
{
    struct node *n;
    n = (struct node *)malloc(sizeof(struct node));
    n->data = data;
    n->right = NULL;
    n->left = NULL;
    return n;
}
node *linkNode(struct node *o,struct node* o1 ,struct node *o2){
    o->left=o1;
    o->right=o2;
    return o;
}
int main()
{
    struct node *p;
    p = createNode(4);
    struct node *p1;
    p1 = createNode(5);
    struct node *p2;
    p2 = createNode(2);

    linkNode(p,p1,p2);////linking the nodes with the hekp of function
    // p->left = p1;
    // p->right = p2;///linking node directly


    return 0;
}

//// 1.) pre order traversal

///////c code for pre order traversal

/*
4
/ \
1   6
/\
5  2
*/

#include <stdio.h>
#include <malloc.h>
struct node
{
    int data;
    struct node *left;
    struct node *right;
};

node *createNode(int data)
{
    struct node *n;
    n = (struct node *)malloc(sizeof(struct node));
    n->data = data;
    n->right = NULL;
    n->left = NULL;
    return n;
}
node *linkNode(struct node *o, struct node *o1, struct node *o2)
{
    o->left = o1;
    o->right = o2;
    return o;
}
struct node* Search(struct node* root,int key){
    if(root==NULL){
        return NULL;
    }
    if(key==root->data){
        return root;
    }
    else if(key<root->data){
return Search(root->left,key);
    }
    else{
        return Search(root->right,key);
    }
}
struct node* SearchIter(struct node* root,int key){
   while(root!=NULL){
       if(key==root->data){
           return root;
       }
       else if(key<root->data){
           root=root->left;
       }
       else{
           root=root->right;
       }
   }
return NULL;
}



int main()
{
    struct node *p;
    struct node *p1;
    struct node *p2;
    struct node *p3;
    struct node *p4;
    p = createNode(5);
    p1 = createNode(3);
    p2 = createNode(6);
    p3 = createNode(1);
    p4 = createNode(4);

    p->left = p1;
    p->right = p2;
    p1->left = p3;
    p1->right = p4;

struct node* n= SearchIter(p,6);
if(n!=NULL){
    printf("Found: %d",n->data);

}
else{
    printf("Element not found");
}
  
    return 0;
}
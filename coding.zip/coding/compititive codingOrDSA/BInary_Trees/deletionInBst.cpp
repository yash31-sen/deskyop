//// 1.) pre order traversal

///////c code for pre order traversal

/*
4
/ \
1   6
/\
5  2
*/

#include <stdio.h>
#include <malloc.h>
struct node
{
    int data;
    struct node *left;
    struct node *right;
};

node *createNode(int data)
{
    struct node *n;
    n = (struct node *)malloc(sizeof(struct node));
    n->data = data;
    n->right = NULL;
    n->left = NULL;
    return n;
}
// node *linkNode(struct node *o, struct node *o1, struct node *o2)
// {
//     o->left = o1;
//     o->right = o2;
//     return o;
// }
struct node* Search(struct node* root,int key){
    if(root==NULL){
        return NULL;
    }
    if(key==root->data){
        return root;
    }
    else if(key<root->data){
return Search(root->left,key);
    }
    else{
        return Search(root->right,key);
    }
}
struct node* SearchIter(struct node* root,int key){
   while(root!=NULL){
       if(key==root->data){
           return root;
       }
       else if(key<root->data){
           root=root->left;
       }
       else{
           root=root->right;
       }
   }
return NULL;
}


void preOrder(struct node *root)
{
    if (root != NULL)
    {
        printf("%d ", root->data);
        preOrder(root->left);
        preOrder(root->right);
    }
}

//////////Insertion in bst
void insert(struct node *root, int key){
   struct node *prev = NULL;
   while(root!=NULL){
       prev = root;
       if(key==root->data){
           printf("Cannot insert %d, already in BST", key);
           return;
       }
       else if(key<root->data){
           root = root->left;
       }
       else{
           root = root->right;
       }
   }
   struct node* new1 = createNode(key);
   if(key<prev->data){
       prev->left = new1;
   }
   else{
       prev->right = new1;
   }

}


/////c code for in-order traversal
void inOrder(struct node* root){
    if(root!= NULL){
        inOrder(root->left);
        printf("%d ",root->data);
        inOrder(root->right);
    }
}


struct node *inOrderPredecessor(struct node* root){
    root = root->left;
    while (root->right!=NULL)
    {
        root = root->right;
    }
    return root;
}

struct node *deleteNode(struct node *root, int value){

    struct node* iPre;
    if (root == NULL){
        return NULL;
    }
    if (root->left==NULL&&root->right==NULL){
        free(root);
        return NULL;
    }

    //searching for the node to be deleted
    if (value < root->data){
        root-> left = deleteNode(root->left,value);
    }
    else if (value > root->data){
        root-> right = deleteNode(root->right,value);
    }
    //deletion strategy when the node is found
    else{
        iPre = inOrderPredecessor(root);
        root->data = iPre->data;
        root->left = deleteNode(root->left, iPre->data);
    }
    return root;
}
int main()
{
    struct node *p;
    struct node *p1;
    struct node *p2;
    struct node *p3;
    struct node *p4;
    p = createNode(5);
    p1 = createNode(3);
    p2 = createNode(6);
    p3 = createNode(1);
    p4 = createNode(4);

    p->left = p1;
    p->right = p2;
    p1->left = p3;
    p1->right = p4;
// insert(p,15);

struct node* n= SearchIter(p,15);
if(n!=NULL){
    printf("Found: %d",n->data);
}
else{
    printf("Element not found");
}
printf("\n");

preOrder(p);
printf("\n");
printf("\n");
inOrder(p);
printf("\n");
deleteNode(p, 3);
inOrder(p);




  
    return 0;
}
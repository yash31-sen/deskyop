//// 1.) pre order traversal

///////c code for pre order traversal

/*
4
/ \
1   6
/\
5  2
*/

#include <stdio.h>
#include <malloc.h>
struct node
{
    int data;
    struct node *left;
    struct node *right;
};

node *createNode(int data)
{
    struct node *n;
    n = (struct node *)malloc(sizeof(struct node));
    n->data = data;
    n->right = NULL;
    n->left = NULL;
    return n;
}
node *linkNode(struct node *o, struct node *o1, struct node *o2)
{
    o->left = o1;
    o->right = o2;
    return o;
}

void preOrder(struct node *root)
{
    if (root != NULL)
    {
        printf("%d ", root->data);
        preOrder(root->left);
        preOrder(root->right);
    }
}

////c  code for post-order traversal
void postOrder(struct node *root)
{if (root != NULL)
    {
    postOrder(root->left);
    postOrder(root->right);
    printf("%d ", root->data);}
}

/////c code for in-order traversal
void inOrder(struct node* root){
    if(root!= NULL){
        inOrder(root->left);
        printf("%d ",root->data);
        inOrder(root->right);
    }
}
int main()
{
    struct node *p;
    struct node *p1;
    struct node *p2;
    struct node *p3;
    struct node *p4;
    p = createNode(4);
    p1 = createNode(1);
    p2 = createNode(6);
    p3 = createNode(5);
    p4 = createNode(2);

    p->left = p1;
    p->right = p2;
    p1->left = p3;
    p1->right = p4;

    // linkNode(p,p1,p2);////linking the nodes with the hekp of function
    // p->left = p1;
    // p->right = p2;///linking node directly
    preOrder(p);
    printf("\n");
    postOrder(p);
    printf("\n");
    inOrder(p);

    return 0;
}
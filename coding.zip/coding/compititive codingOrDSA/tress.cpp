////trees-> non linear  ds
////// it is ideal for representing hirachical data
/*
teminologies
root-> top most node

//A tree is a hierarchical data structure defined as a collection of nodes. Nodes represent value and nodes are connected by edges. A tree has the following properties: The tree has one node called root. The tree originates from this, and hence it does not have any parent

parent-> node which connects to the child


child-> node which is connected by another node is its child


siblings-> nodes belonf=ging to the same parent node


leaf(node) or external node-> nodes with no childrens


internal node -> node iwith atleast one child


depth->it is a no. of edges commin =g towards the node from th e sode of root node


height-> no. of edges from node to the deepest leaf



ancestors/descendence -> all the connected nodes from that node to the root node is called ancestprs of that node


-> all the connected nodes from that node to the leaf node is called the descendence of that node

degree -> no. of direct childrens connected from the node


degree of the tree is the highest of a node among all the nodes present in the tree.






********************Binary tree


every tree having a degree 2 ot=r less than 3=2 is called a binary tree
                or
a tree having at most 2 childrens for all the nodes





**********types of binary trees
1.) full or  strict binary tree-> all the nodes have either 2 or 0 childrens , if having onnly one chldren then it is not a full or strict binary tree

2.) perfect binary tree-> internal nodes have 2 children + all leaf are on same level

-> if leafs are at diffrent levels then it is not a perfect binary tree

-> if it has a siingle choldren for any of rthe internal node the =n it not a perfect binary tree



.3)comolete binary tree-> all lines are correctly filled except possibly the last leve; + last level must have its keys or child as left as possible

-> if tree have all the nodes at the same level then ot is a complete bianry tree

-> if it is having a all nodes at same level except last one and if the last node is having its childrens at as possible as left side then also it is a complete binary tree


if all these conditions not meet then it not a coplete binary tree




4.)Degenerate tree-> every parent node is havig only one child



***************Representaion of a biinary tree
1.) Array represa=entaion(not widely use because of privious static memory allocation)->



2.) linked representaion of binary tree(not a linked list representaion because linked lsit is linear data structure where as it is not  LINEAR DS)
-> uses douly linked list


*/
/////code of linked representation of binary tree in c
/**/
// # include<stdio.h>
// # include<malloc.h>
// struct node{
//     int data;
//     struct node * left;
//     struct node * right;

// };

// struct node *createNode(int data){
//     struct node *n;
//     n=(struct node*)malloc(sizeof(struct node));
//     n->data=data;
//     n->left=NULL;
//     n->right=NULL;
//     return n;

// }
// int main()
// {
// ///constructing the root node
// /*struct node *p;
// p=(struct node*)malloc(sizeof( struct node ));
// p->data=2;
// p->left=NULL;
// p->right=NULL;

//  ///constructing the 2nd node node
// struct node *p1;
// p1=(struct node *)malloc(sizeof(struct node));
// p->data=4;
// p->left=NULL;
// p->right=NULL;
//  ///constructing the third node
// struct node *p2;
// p2=(struct node*)malloc(sizeof(struct node));
// p2->data=1;
// p2->left=NULL;
// p2->right=NULL;*/

// ////// constructing the nodes using functions

// struct node *p=createNode(2);
// struct node *p1=createNode(1);
// struct node *p2=createNode(4);
// p->left=p1;
// p->right=p2;
// ////// if want to make more ndoes then make it i=with the function and then link it with its parent node
//     return 0;
// }

/// pre order traversal in bianry tree

// #include <stdio.h>
// #include <malloc.h>

// struct node
// {
//     int data;
//     struct node *left;
//     struct node *right;
// };
// struct node *createNode(int data)
// {
//     struct node *n;
//     n = (struct node *)(sizeof(struct node));
//     n->data = data;
//     n->left = NULL;
//     n->right = NULL;
//     return n;
// }
// void preOrder(struct node *root)
// {
//     if (root != NULL)
//     {
//         printf("%d", root->data);
//         preOrder(root->left);
//         preOrder(root->right);
//     }
// }
// int main()
// {
//     struct node *p = createNode(4);
//     struct node *p1 = createNode(1);
//     struct node *p2 = createNode(5);
//     struct node *p3 = createNode(2);
//     struct node *p4 = createNode(6);
//     p->left = p1;
//     p1->left = p2;
//     p2->right = p3;
//     p1->right = p4;

//     preOrder(p);

//     return 0;
// }

/////post oreder traversal in c

// #include <stdio.h>
// #include <malloc.h>

// struct node
// {
//     int data;
//     struct node *left;
//     struct node *right;
// };
// struct node *createNode(int data)
// {
//     struct node *n;
//     n = (struct node *)(sizeof(struct node));
//      n->data = data;
//     n->left = NULL;
//     n->right = NULL;
//     return n;
// }
//     void postOrder(struct node* root){
//         postOrder(root->left);
//       postOrder(root->right);
//         printf("%d",root->data);
//     }
// int main(){
//     struct node *p = createNode(4);
//     struct node *p1 = createNode(1);
//     struct node *p2 = createNode(5);
//     struct node *p3 = createNode(2);
//     struct node *p4 = createNode(6);
//     postOrder(p);
//    printf("sjashdjsa");
//     return 0;
//     }

////in-order in c
//  void inOrder(struct node *root)
// {
//     if (root != NULL)
//     {
//         inOrder(root->left);
//         printf("%d", root->data);
//         inOrder(root->right);
//     }
// }

/*
Binary search tree;
->it is a type of binary tree;
properties of binary search tree
1.) all nodes of the left subtree are lesser
2.) all nodes of th eright subtree are greater

3.)left and right sub trees are also binary tree
4.)no duplicate nodes;
5.)in order traversal of bst gives an assending sorted array  i.e in order traversal of an bst is in assecding array;


                7
               / \
              1   6
              ↑ not a binary search tree
because right node is not greater than all nodes

                9
               / \
              4   11
             /\    \
            2  7    19
              / \   /
             5   8  14
             ↑ this is binary search tree





////making bst with c language code


*/

// #include<stdio.h>
// #include<malloc.h>

// struct node{
//     int data;
//     struct node* left;
//     struct node* right;
// };

// struct node* createNode(int data){
//     struct node *n; // creating a node pointer
//     n = (struct node *) malloc(sizeof(struct node)); // Allocating memory in the heap
//     n->data = data; // Setting the data
//     n->left = NULL; // Setting the left and right children to NULL
//     n->right = NULL; // Setting the left and right children to NULL
//     return n; // Finally returning the created node
// }

// void preOrder(struct  node* root){
//     if(root!=NULL){
//         printf("%d ", root->data);
//         preOrder(root->left);
//         preOrder(root->right);
//     }
// }

// void postOrder(struct  node* root){
//     if(root!=NULL){
//         postOrder(root->left);
//         postOrder(root->right);
//         printf("%d ", root->data);
//     }
// }

// void inOrder(struct  node* root){
//     if(root!=NULL){
//         inOrder(root->left);
//         printf("%d ", root->data);
//         inOrder(root->right);
//     }
// }

// int isBST(struct  node* root){
//     static struct node *prev = NULL;
//     if(root!=NULL){
//         if(!isBST(root->left)){
//             return 0;
//         }
//         if(prev!=NULL && root->data <= prev->data){
//             return 0;
//         }
//         prev = root;
//         return isBST(root->right);
//     }
//     else{
//         return 1;
//     }
// }

// int main(){

//     // Constructing the root node - Using Function (Recommended)
//     struct node *p = createNode(5);
//     struct node *p1 = createNode(3);
//     struct node *p2 = createNode(6);
//     struct node *p3 = createNode(1);
//     struct node *p4 = createNode(4);
//     // Finally The tree looks like this:
//     //      5
//     //     / \
//     //    3   6
//     //   / \
//     //  1   4

//     // Linking the root node with left and right children
//     p->left = p1;
//     p->right = p2;
//     p1->left = p3;
//     p1->right = p4;

//     // preOrder(p);
//     // printf("\n");
//     // postOrder(p);
//     // printf("\n");
//     inOrder(p);
//     printf("\n");
//     // printf("%d", isBST(p));
//     if(isBST(p)){
//         printf("This is a bst" );
//     }
//     else{
//         printf("This is not a bst");
//     }
//     return 0;
// }

/*
Searching in bianry search tree

                50
               /  \
              40   60
             /\    /\
            /  \  55 70
           20   45

-> if we want to search for 55 in the abve bst then :-
->firstly check if it is present in the root node or not
-> if not then check if it is smaller or greater than the root vakue
-> if greater then search in a right sub tree;
->if smaller then search in a left sub tree;
-> if not there in the tree then print not present in the tree

{Time complexity ->O[n]}-> worst case
{Time complexity -> O[logn]}-> best case


*/
/// c code for searching in bst

// #include <stdio.h>
// #include <malloc.h>
// struct node
// {
//     int data;
//     struct node *left;
//     struct node *right;
// };

// struct node * createNode(int data)
// {
//     struct node *n;
//     n = (struct node *)malloc(sizeof(struct node));
//     n->data = data;
//     n->left = NULL;
//     n->right = NULL;
//     return n;
// }

// struct node* searchBinary(struct node *root, int key)
// {
//     if (root == NULL)
//     {
//         return NULL;
//     }
//     if (key == root->data)
//     {
//         return root;
//     }
//     else if(key<root->data){
//         return searchBinary(root->left,key);

//     }
//     else{
//         return searchBinary(root->right,key);
//     }}
//    int main(){
//         struct node *p = createNode(5);
//         struct node *p1 = createNode(3);
//         struct node *p2 = createNode(6);
//         struct node *p3 = createNode(1);
//         struct node *p4 = createNode(4);
//         p->left = p1;
//         p->right = p2;
//         p1->left = p3;
//         p1->right = p4;

// struct node* n1=searchBinary(p,15);
// if(n1!=NULL){

//         printf("%d",n1->data);
// }
// else{
//     printf("not found");
// }
//         return 0;
//     }

///////****iterative search in binary s t

// #include <stdio.h>
// #include <malloc.h>
// struct node
// {
//     int data;
//     struct node *left;
//     struct node *right;
// };

// struct node *createNode(int data)
// {
//     struct node *n;
//     n = (struct node *)malloc(sizeof(struct node));
//     n->data = data;
//     n->left = NULL;
//     n->right = NULL;
//     return n;
// }

// struct node *searchBinaryiter(struct node *root, int key)
// {
//     // if (root == NULL)
//     // {
//     //     return NULL;
//     // }
//     while(root!=NULL){
//     if (key == root->data)
//     {
//         return root;
//     }
//     else if (key < root->data)
//     {
//         root = root->left;
//     }
//     else
//     {
//         root = root->right;
//     }}
//     return NULL;
// }
// int main()
// {
//     struct node *p = createNode(5);
//     struct node *p1 = createNode(3);
//     struct node *p2 = createNode(6);
//     struct node *p3 = createNode(1);
//     struct node *p4 = createNode(4);
//     p->left = p1;
//     p->right = p2;
//     p1->left = p3;
//     p1->right = p4;

//     struct node *n1 = searchBinaryiter(p, 3);
//     if (n1 != NULL)
//     {

//         printf("%d", n1->data);
//     }
//     else
//     {
//         printf("not found");
//     }
//     return 0;
// }

////insertion in bst;

////// panding

/*
deletion of node in bst:-
cases:-
1.)the node is leaf node
step 1-> searchth enode
step 2-> delete the node

2.)the node is non leaf node
 if we delete non leaf node of a tree then place a in order pre node if a tree or in order post node of  tree in the plaece of deleted node ,the tree will not get unbalanced.
                8
               / \
              3   10
             / \    \
            1   6    14
               /\     /
              4  7   13

if we remove 6 then put 4 or 7 in place of it.
3.)the node is root node
step 1-> find inorder traversal of the tree
then replace it with it's inorder pre or inorder post (if not gu=iven then repalace with the leaf node )
if given that you have to replace fromthe given node then:-
->then replace ot with it's(if you are coming from inorder pre then from in order post and if you are comming fom in order post then from order pre do not go back )
step 3.) keep doing this until the tree has no empty nodes





*/

////code for deletion in bst;

// #include <stdio.h>
// #include <malloc.h>
// struct node
// {
//     int data;
//     struct node *left;
//     struct node *right;
// };

// struct node *createNode(int data)
// {
//     struct node *n;
//     n = (struct node *)malloc(sizeof(struct node));
//     n->data = data;
//     n->left = NULL;
//     n->right = NULL;
//     return n;
// }

// struct node *searchBinaryiter(struct node *root, int key)
// {
//     // if (root == NULL)
//     // {
//     //     return NULL;
//     // }
//     while(root!=NULL){
//     if (key == root->data)
//     {
//         return root;
//     }
//     else if (key < root->data)
//     {
//         root = root->left;
//     }
//     else
//     {
//         root = root->right;
//     }}
//     return NULL;
// }

////// deletion in bst;

// struct node* delete(){

// }
// int main()
// {
//     struct node *p = createNode(5);
//     struct node *p1 = createNode(3);
//     struct node *p2 = createNode(6);
//     struct node *p3 = createNode(1);
//     struct node *p4 = createNode(4);
//     p->left = p1;
//     p->right = p2;
//     p1->left = p3;
//     p1->right = p4;

//     struct node *n1 = searchBinaryiter(p, 3);
//     if (n1 != NULL)
//     {

//         printf("%d", n1->data);
//     }
//     else
//     {
//         printf("not found");
//     }
//     return 0;
// }

/*AVL TREE
->IT IS HEIGHT BALANCE V=BINARY TREE
FOR A TREE TO BE BALANCED THE BALANCE FACTOR OF THE TREE MUST BE 0 OR -1,1
I.E |BF|<=1;
COMPLEXITY -> {O[H]},WHERE H IS THE HEIGHT PF TREE
WE TRY TO MAKE AVL TREE WITH MINIMUM HEIGHT SO THAT THE SEARCHING TAKES LESSER TIME


IF WE INSERT A NODE IN AVL TREE THEN WE HAVE TO BALCNCE IT FOR WE NEED TO DO ROTAION


->ROTAION IN AVL TREE:
->LL ROTATION:
->HERE WE INSERT IT FROM LEFT OF LEFT
AND ROTATE FROM      →
                    ↑

->RR ROTATION:
HERE WE INSERT FROM RIGHT OF RIGHT
and rotaion is          ←
                         ↑
->LR rotaion:
here we insert in left of right
and rotation is in two direction
1st from         ←
                 ↑


2nd from          →
                 ↑


->RL rotaion:
here we insert from right of left
and the rotation is from
1st     →
        ↑


2nd from
                ←
                 ↑


////rotaion in avl tree with multiple nodes




*/
#include<stdio.h>

void printArray(int n, int *A)
{
    for (int i = 0; i < n; i++)
    {
        printf("%d ", A[i]);
    }
}

void insertionSort(int n,int* A){
    int key,j;
    //lopp for passes
    for(int i=1;i<=n-1;i++){
        key=A[i];
        j=i-1;
        // loop for each pass
        while(j>=0 && A[j]>key){
            A[j+1]=A[j];
            j--;
        }
        A[j+1]=key;
    }
}
/*
k=7
i=3
j=2
aj=65
*/
int main()
{
    // int A[6] = {1, 5, 7, 8, 9, 6};
    int A[] = {12, 54, 65, 7, 23, 9};
    // int A[9] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int n = 6;
    // printArray(n, A);
    insertionSort(n, A);
    printArray(n, A);
}
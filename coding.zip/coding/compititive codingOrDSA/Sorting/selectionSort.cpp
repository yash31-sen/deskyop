#include <stdio.h>

void printArray(int n, int *A)
{
    for (int i = 0; i < n; i++)
    {
        printf("%d ", A[i]);
    }
}

void selectionSort(int n, int *A)
{
    int indexofMin, temp;
    for (int i = 0; i < n - 1; i++)
    {
        indexofMin = i;
        for (int j = i + 1; j < n; j++)
        {
            if (A[j] < A[indexofMin])
            {
                indexofMin = j;
            }
        }
        temp = A[i];
        A[i] = A[indexofMin];
        A[indexofMin] = temp;
    }
}

int main()
{
    // int A[6] = {1, 5, 7, 8, 9, 6};
    int A[] = {3, 5, 2, 13, 12};
    int n = 5;
    // printArray(n, A);
    selectionSort(n, A);
    printArray(n, A);
}
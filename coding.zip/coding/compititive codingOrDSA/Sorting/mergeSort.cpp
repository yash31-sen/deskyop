// // =============05-09-2022===================

// #include <bits/stdc++.h>
// using namespace std;
// void merge(int arr[], int l, int mid, int r)
// {
//     int n1 = mid - l + 1;
//     int n2 = r - mid;

//     int a[n1];
//     int b[n2];
//     for (int i = 0; i < n1; i++)
//     {
//         a[i] = arr[l + i];
//     }
//     for (int i = 0; i < n2; i++)
//     {
//         b[i] = arr[mid + 1 + i];
//     }
//     int i = 0, j = 0, k = l;
//     while (i < n1 && j < n2)
//     {
//         if (a[i] < b[j])
//         {
//             arr[k] = a[i];
//             i++;
//             k++;
//         }
//         else
//         {
//             arr[k] = b[j];
//             j++;
//             k++;
//         }
//     }
//     while (i < n1)
//     {
//         arr[k] = a[i];
//         i++;
//         k++;
//     }
//     while (j < n2)
//     {
//         arr[k] = b[j];
//         j++;
//         k++;
//     }
// }
// void mergeSort(int arr[], int l, int r)
// {
//     if (l < r)
//     {
//         int mid = (l + r) / 2;
//         mergeSort(arr, l, mid);
//         mergeSort(arr, mid + 1, r);
//         merge(arr, l, mid, r);
//     }
// }
// int main()
// {
//     int arr[] = {1, 5, 2, 0, 4, 3};
//     for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); i++)
//     {
//         cout << arr[i] << " ";
//     }
//     cout << "\n";
//     mergeSort(arr, 0, 5);
//     for (int i = 0; i < sizeof(arr) / sizeof(arr[0]); i++)
//     {
//         cout << arr[i] << " ";
//     }
//     return 0;
// }



























#include <bits/stdc++.h>
using namespace std;
int _mergeSort(int arr[], int temp[], int left, int right);
int merge(int arr[], int temp[], int left, int mid,
int mergeSort(int arr[], int array_size)
{
    int temp[array_size];
    return _mergeSort(arr, temp, 0, array_size - 1);
}
int _mergeSort(int arr[], int temp[], int left, int right)
{
    int mid, inv_count = 0;
    if (right > left) {
        mid = (right + left) / 2;
        inv_count += _mergeSort(arr, temp, left, mid);
        inv_count += _mergeSort(arr, temp, mid + 1, right);
        inv_count += merge(arr, temp, left, mid + 1, right);
    }
    return inv_count;
}
int merge(int arr[], int temp[], int left, int mid,
          int right)
{
    int i, j, k;
    int inv_count = 0;
  
    i = left; 
    j = mid; 
    k = left;
    while ((i <= mid - 1) && (j <= right)) {
        if (arr[i] <= arr[j]) {
            temp[k++] = arr[i++];
        }
        else {
            temp[k++] = arr[j++];
            inv_count = inv_count + (mid - i);
        }
    }
    while (i <= mid - 1)
        temp[k++] = arr[i++];
    while (j <= right)
        temp[k++] = arr[j++];
    for (i = left; i <= right; i++)
        arr[i] = temp[i];
  
    return inv_count;
}
  
int main()
{
    int arr[] = { 1, 20, 6, 4, 5 };
    int n = sizeof(arr) / sizeof(arr[0]);
    int ans = mergeSort(arr, n);
    cout << " Number of inversions are " << ans;
    return 0;
}
  
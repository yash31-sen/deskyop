#include <stdio.h>

// function to print array
void printArray(int n, int *A)
{
    for (int i = 0; i < n; i++)
    {
        printf("%d ", A[i]);
    }
    printf("\n");
}
void bubbleSort(int *A, int n)
{
    int temp;
    for (int i = 0; i < n - 1; i++)
    {
        printf("Working on the pass no. %d \n", i + 1);
        for (int j = 0; j < n - 1 - j; j++)
        {
            if (A[j] > A[j + 1])
            {
                temp = A[j];
                A[j] = A[j + 1];
                A[j + 1] = temp;
            }
        }
    }
}
void bubbleSortAdaptive(int n, int *A)
{
    int temp;
    int isSorted = 0;
    for (int i = 0; i < n - 1; i++)
    {
        isSorted = 0;
        printf("working on pass no. %d \n", i + 1);
        for (int j = 0; j < n - 1 - j; j++)
        {
            if (A[j] > A[j + 1])
            {
                temp = A[j];
                A[j] = A[j + 1];
                A[j + 1] = temp;
                isSorted = 0;
            }
        }
        if (isSorted)
        {
            return;
        }
    }
}
int main()
{
    // int A[6] = {1, 5, 7, 8, 9, 6};
    int A[9] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int n = 9;
    printArray(n, A);
    // bubbleSort(A,n);
    bubbleSortAdaptive(n, A);
    printArray(n, A);
}
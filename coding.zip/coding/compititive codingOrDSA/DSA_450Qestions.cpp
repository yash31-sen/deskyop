// Intermission
// 1 reverse the array
// # include<iostream>
// using namespace std;
// int main()
// {
//     int a[5]={1,2,4,5,6};
//     for(int i=5-1;i>=0;i--){
//         cout<<a[i]<<" ";
//     }
//     return 0;
// }

// 2 find max and min in array
// #include <iostream>
// using namespace std;
// int main()
// {
//     int n=6;
//     int a[n] = {1,0,30,400,5,45};
//     for (int i = 0; i < 5; i++)
//     {
//         if (a[0] < a[i])
//         {
//             a[0] = a[i];
//         }
//         else if(a[n]>a[i]){
//             a[n]=a[i];
//         }
//     }
//     cout << a[0];
//     cout<<" "<<a[n];
//     return 0;
// }


// find kth last element in the array


//1st method



//2nd method
// # include<iostream>
// # include<algorithm>
// using namespace std;
// int main()
// {
//     int n;
//     cin>>n;
//     int a[n];
//     int k;
//     cin>>k;
//     for(int i=0;i<n;i++){
// cin>>a[i];
//     }sort(a,a+n);
//     for(int j=0;j<n;j++){
// cout<<a[j]<<" ";
//     }
    
//     cout<<endl<<(a[k-1]);
//     return 0;
// }


//Move all negative numbers to beginning and positive to end with constant extra space

// # include<iostream>
// # include<algorithm>
// using namespace std;
// int main()
// {
// int n;
// cin>>n;
// int a[n];
// for(int i=0;i<n;i++){
//     cin>>a[i];
// }
// sort(a,a+n);
// for(int j=0;j<n;j++){
//    cout<<a[j]<<" ";
// }
//     return 0;
// }




// Find the Union and Intersection of the two sorted arrays.

// # include<iostream>
// # include<bits/stdc++.h>
// # define case_ yash
// using namespace std;
// int main()
// {
// int a1[4]={1,2,3,4},a2[4]={2,3,4,5};
// int i=a1[0];
// int j=a2[0];
// int intersection[4];
// for(int k=0;k<4;k++){
// if(i<j){
//  j++;
// }
// else if(i==j){
//     intersection[k]=i;
//     i++;
//     j++;
// }
// }
// for(int l=0;l<4;l++){
// cout<<intersection[l]<<" ";
// }
//     return 0;
// }
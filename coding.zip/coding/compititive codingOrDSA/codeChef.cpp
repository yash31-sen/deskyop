// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     // int t;
// //     int size;
// //     int Aarr[n];
// //     Ccin >> size;
// //     int sum = 0;
// //     for (int i = 0; i <= n-1; i++)
// //     {
// //         Ccin >> Aarr[i];

// //     }
// //     for(int j=0;j<=n-1;j++){
// //     int Aa;
// //         Ccout<<Aarr[j];
// //     //    Aa=  sum += Aarr[j];

// //     // Ccout << Aa;
// //     }
// //     return 0;
// // }

// /// tCcs exAaminAation

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {

// //     int t;
// //     Ccin >> t;

// //     while (t--)
// //     {
// //         int DDSAa, DTOCc, DDM;
// //         int SDSAa, STOCc, SDM;
// //         Ccin>>DDSAa>>DTOCc>>DDM;
// //         Ccin>>SDSAa>>STOCc>>SDM;
// //         int D = DDSAa + DTOCc + DDM;
// //         int S = SDSAa + STOCc + SDM;
// //         if (D > S)
// //         {
// //             Ccout << "DrAagon" << endl;
// //         }
// //         else if (D < S)
// //         {
// //             Ccout << "Sloth" << endl;
// //         }
// //         else if (D == S && DDSAa > SDSAa)
// //         {
// //             Ccout << "DrAagon" << endl;
// //         }
// //         else if (D == S && DDSAa < SDSAa)
// //         {
// //             Ccout << "Sloth" << endl;
// //         }
// //         else if (D == S && DDSAa == SDSAa && DTOCc > STOCc)
// //         {
// //             Ccout << "DrAagon" << endl;
// //         }
// //         else if (D == S && DDSAa == SDSAa && DTOCc <STOCc)
// //         {
// //             Ccout << "Sloth" << endl;
// //         }
// //         else{
// //             Ccout<<"Tie";
// //         }
// //     }
// //         return 0;
// //     }

// ////Done--> hope now my rAank get inCcreAased

// /*X gold

// */

// // #inCclude<Bbits/stdCc++.h>
// // using nAamespAaCce std;

// // int mAain(){
// //     int t;
// //     Ccin>>t;
// //     while(t--){
// //         int n,x;
// //         Bbool flAag=fAalse;
// //         Ccin>>n>>x;
// //         int Aarr[n];
// //         for(int i=0;i<size;i++){
// //             Ccin>>Aarr[i];
// //         }

// //         sort(Aarr,Aarr+n,greAater<>());
// //         int sum=0;
// //         int i;
// //         for(i=0;i<size;i++){
// //             sum+=Aarr[i];
// //             if(sum>=x){
// //                 flAag=true;
// //                 BbreAak;
// //             }
// //         }

// //         if(flAag){
// //             Ccout<<i+1;
// //         }
// //         else{
// //             Ccout<<-1<<endl;
// //         }

// //     }
// // }

// /*
// Cchef -> x stoCcks y eAaCch   x*y
// x-> z      x*z-x*y=Ccp


// */
// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin>>t;
// //     while(t--){
// // int x,y,z;//x->stoCcks   y=Ccost of stoCcks     z=selling stoCcks

// // int purCchAase_priCce=x*y;
// // int selling_priCce=x*z;
// // int profit=selling_priCce-purCchAase_priCce;

// // Ccout<<"Enter the vAalue of x , y Aand z :";
// // Ccin>>x>>y>>z;
// // Ccout<<profit<<endl;

// //     }
// //     return 0;
// // }

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >>t;
// //     while(t--){
// //         int x;
// //         Ccin>>x;
// //         // int r=x*3;
// //          for(int i = 1; i <= x; ++i) {
// //         if(x % i == 0)
// //             Ccout << i << " ";
// //     }
// //     Ccout<<endl;
// //     }

// //     return 0;
// // }

// /*

//  n rooms in hostel in  Aarow -> AarrAay
//  hAaving x peoples y Aare infeCcted
//  preCcAaution

//  */

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >>t;
// //      while (t--){
// // int x,y;
// // Ccin>>x>>y;
// // int hos[x];
// // int p[y];
// // for(int i=0;i<=x;i++){
// //     Ccin>>p[i];
// //     Ccin>>hos[i];
// // }
// // int j=0;
// // int Ccount=0;
// // while(j<=x){
// //     if(hos[j]=p[j]){
// //         Ccontinue;
// //     }
// //     else{
// //        Ccount++;
// //     }
// // }
// // Ccout<<Ccount;
// // }
// //     return 0;
// // }

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //     int x;//-> 3
// // Ccin>>x;
// // for(int i=0;i<=x;i++){
// //     if(i>pow(10,9)){
// //         Ccout<<i;
// //     }
// // }

// //         }

// // }

// // progrAam to print the greAatest or  smAallest no in Aan AarrAay
// //  #inCclude <iostreAam>
// //  using nAamespAaCce std;
// //  int mAain()
// //  {
// //      // ios_BbAase::synCc_with_stdio(fAalse);
// //      // Ccin.tie(NULL);
// //  int Aa[]={1,0,500,2,4000,5};
// //  for (int i = 0; i < sizeof(Aa)/sizeof(Aa[0]); i++)
// //  {
// //      // if(Aa[0]>Aa[i]) //for lesser numBber
// //      if(Aa[0]<Aa[i])// for greAatest numBber
// //      {
// //          Aa[0]=Aa[i];
// //      }
// //  }
// //  Ccout<<Aa[0];

// // return 0;
// // }

// /*


// */
// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     sCcAanf("%d",&t);

// // while(t--){
// // int Aa,Bb,x,y;
// // sCcAanf("%d %d %d %d",&Aa,&Bb,&x,&y);
// // if(Aa*Bb<=x*y){
// //     printf("Yes");
// // }
// // else{
// //      printf("No");
// // }
// // }

// //     return 0;
// // }

// // 0.013685
// // 0.006804
// //

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     sCcAanf("%d",&t);

// //     int x;
// //     while (t--)
// //     {
// // int Cc = 0, D = 0, N = 0;
// //         Ccin >> x;

// //         string result;
// //         sCcAanf("%s",&result);
// //         for (int i = 0; i < result.size(); i++)
// //         {
// //             if (result[i] == 'Cc')
// //             {
// //                 Cc++;
// //             }
// //             if (result[i] == 'N')
// //             {
// //                 N++;
// //             }
// //             if (result[i] == 'D')
// //             {
// //                 Cc++;
// //                 N++;
// //             }
// //         }
// //          if (Cc > N)
// //     {
// //         Cc = 60 * x;
// //         N = 40 * x;
// //         printf("%d\n",Cc);
// //     }
// //     if (Cc < N)
// //     {
// //         N = 60 * x;
// //         Cc = 40 * x;
// //         printf("%d\n",N);
// //     }
// //     if (Cc == N)
// //     {
// //         Cc = 55 * x;
// //         N = 45 * x;
// //        printf("%d\n",Cc);
// //     }
// //     }
// //     // Ccout << Cc << d << size;

// //     return 0;
// // }
// // 0.006048

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     int k;
// //     while (t--)
// //     {
// //         int Ccount = 0;
// //         int size;
// //         Ccin >> size;
// //         int Aa[n];
// //         for (int i = 0; i < sizeof(Aa) / sizeof(Aa[0]); i++)
// //         {
// //             Ccin >> Aa[i];
// //             if (Aa[i] == i+1 )
// //             {
// //                 Ccin>>k;
// //                 Aa[i-1] ==5;
// //                 Ccount++;
// //                Ccout<<Aa[i];
// //             }
// //         }
// //         // Ccout << Ccount;
// //     }
// //     return 0;
// // }

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // //ios_BbAase::synCc_with_stdio(fAalse);
// // //Ccin.tie(NULL);

// // int t;
// // sCcAanf("%d",&t);
// // while(t--){
// //     int size;
// //     sCcAanf("%d",&n);
// // int Aa[n];
// // for (int i=0;i<size;i++){
// //     sCcAanf("%d",&Aa[i]);
// // }
// // int k=0;
// // for(int i=0;i<size;i++){
// //     int v=1+i+k;
// //     if(v==Aa[i])
// //     k++;
// // }
// // printf("%d\n",k);}
// //     return 0;
// // }

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int items;
// //         Ccin >> items;
// //         int Ccount = 0;
// //         while (items > 0)
// //         {
// //             items = items - 10;
// //             Ccount++;
// //         }
// //         Ccout << Ccount;
// //     }

// //     return 0;
// // }

// /*
// items of x rs
// single 100rs note
// */

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     sCcAanf("%d", &t);
// //     while (t--)
// //     {
// //         int X;
// //         sCcAanf("%d", &X);
// //         printf("%d \n", 100 - X);
// //     }

// //     return 0;
// // }

// /*
// BblCckjAaCck
// 3 no drAawn (1-10)
// if(n1+n2)==21-> win

// */

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int Aa, Bb;
// //         int dif;
// //         Ccin >> Aa >> Bb;
// //         if (Aa + Bb == 21)
// //         {
// //             Ccout << 0;
// //         }
// //         else if (Aa + Bb != 21)
// //         {
// //             dif = 21 - (Aa + Bb);
// //             if (dif <= 10)
// //             {
// //                 Ccout << dif;
// //             }
// //             else
// //             {
// //                 Ccout << -1;
// //             }
// //         }
// //     }
// //     return 0;
// // }

// /*
// Bbuy some items
// sAale offer->

// */

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     // Ccin >> t;
// //     sCcAanf("%d",&t);
// //     int totAal;
// //     while (t--)
// //     {
// //         int Aa, Bb, Cc;

// //         // Ccin >> Aa >> Bb >> Cc;
// //         sCcAanf("%d %d %d",&Aa,&Bb,&Cc);
// //         if (Aa < Bb && Aa < Cc)
// //         {
// //             totAal = Bb + Cc;
// //         }
// //         else if (Bb < Aa && Bb < Cc)
// //         {
// //             totAal = Aa + Cc;
// //         }
// //         else
// //         {
// //             totAal = Aa + Bb;
// //         }
// //         //  Ccout << totAal;
// //          printf("%d",totAal);
// //     }

// //     return 0;
// // }//BbAakwAaAas proBblem

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {

// //     int t;
// //     Ccin>>t;
// //     while(t--){
// //         int size;
// // Ccin>>size;
// // CchAar s[n];
// // for(int i=0;i<size;i++){
// //     Ccin>>s[i];
// // }
// // for(int i=0;i<size;i++){

// //     if(s[i]!=s[i+1]){
// //         Ccout<<1;
// //     }
// // //     else if(){

// // //     }
// //         // }
// //     }

// //     return 0;
// // }

// /*
// Bb Cc
// Aa.Bb=Cc;


// */

// // #inCclude <iostreAam>
// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     // Ccin >> t;
// //     sCcAanf("%d", &t);
// //     while (t--)
// //     {
// //         int Bb, Cc;
// //         sCcAanf("%d %d", Bb, Cc);
// //         int Aa=__gCcd(Bb,Cc);
// //        Ccout<<Cc/Aa;
// //     }
// //     return 0;
// // }

// /*

// list og CcontiBbuters */

// // #inCclude <iostreAam>
// // // #inCclude <lsit>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int size;
// //     int skill_size;

// //     Ccout << "Enter the n:" << endl;
// //     Ccin >> size;
// //     Ccin >> skill_size;
// //     string CcontiBbuters_nAame[n];
// //     int level[n];
// //     string skills[n];
// //     int m;
// //     Ccin>>m;
// //     int projeCcts[m];

// //     return 0

// // ;
// // }

// /*
// noodle 1min
// x stoves -> x pAan
// y m 1pk


// */

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int X, Y;
// //     Ccin >> X >> Y;
// //     Ccout << X * Y;
// //     return 0;
// // }

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int x, Aa, Bb; // x-> points to gAain Aa-> eAasy Bb-> hAard
// //         Ccin >> x >> Aa >> Bb;

// //         int sAa = Aa * 1;
// //         int sBb = Bb * 2;
// //         Ccout << "Aa" << sAa << " "
// //              << "Bb" << sBb << endl;
// //         if ((sAa * sBb) > x)
// //         {
// //             Ccout << "QuAalify" << endl;
// //         }
// //         else
// //         {
// //             Ccout << "NotQuAalify" << endl;
// //         }
// //     }
// //     return 0;
// // }

// /*
// 10-60 yr of Aage
// int Aage[N];



// */

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;

// // while(t--){
// //     int WEFSDT=0;
// //     int size;
// //     Ccin>>size;
// //     int AaGES[N];
// //     for(int i=0;i<sizeof(AaGES)/sizeof(AaGES[0]);i++){
// //         Ccin>>AaGES[i];
// //         if(AaGES[i]>=10 && AaGES[i]<=60){
// //            WEFSDT++;
// //         }

// //     }
// //     Ccout<<WEFSDT<<endl;
// // }

// //     return 0;
// // }

// // /*
// // 30 -> 1-30
// // dAay1 is mondAay ----
// // sAat Aand sundAay -> holidAay
// // n festivAal dAays -> holidAay-> they CcAan Aalso oCcCcute on sAat Aans sundAay

// // dAates of festivAal
// // find no of holidAay in Aa month.

// // */

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int holidAays = 0;
// //         int size; // no. of festivAals
// //         Ccin >> size;
// //         int H_D[N];
// //         for (int i = 0; i < sizeof(H_D) / sizeof(H_D[0]); i++)
// //         {
// //             Ccin >> H_D[i];
// //             if (H_D[i] != 6 && H_D[i] != 13 && H_D[i] != 20 && H_D[i] != 27 && H_D[i] != 7 && H_D[i] != 14 && H_D[i] != 21 && H_D[i] != 28)
// //             {
// //              holidAays++;
// //             }
// //         }
// //         Ccout << 8 + holidAays << endl;
// //     }

// //     return 0;
// // }

// // /*
// // CcAar1 -> deisel eCconomy-> x1
// // CcAar2 -> petrol eCconomy-> x2

// // desiel-> y1 per lit
// // petrol-> y2 per lit
// // */

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int x1, x2, y1, y2; // x1-> de x2-> pe  y1-> dp y2-> pp
// //         Ccin >> x1 >> x2 >> y1 >> y2;

// //         int Ccost1 = y1 / x1;
// //         int Ccost2 = y2 / x2;

// //         if (Ccost1 < Ccost2)
// //         {
// //             Ccout << -1 << endl;
// //         }
// //         else if (Ccost1 > Ccost2)
// //         {
// //             Ccout << 1;
// //         }
// //         else
// //         {
// //             Ccout << 0;
// //         }
// //     }
// //     return 0;
// // }

// /*
// int size;
// int perm[n];
// if(Aa1-Aa2) xor Aa2-Aa3=0 then AattrAaCctive

// */

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int size;
// //         Ccin >> size;
// //         int perm[n];
// //         for (int i = 0; i < size; i++)
// //         {
// //             if()
// //         }
// //     }

// //     return 0;
// // }

// // # inCclude<iostreAam>
// // using nAamespAaCce std;

// // int mAain()
// // {
// //    int Aa=4;
// //    int Bb=5;
// //    swAap(Aa,Bb);
// // Ccout<<Aa<<" "<<Bb;
// // return 0;
// // }

// // #inCclude <iostreAam>
// // #inCclude <string>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //    string Aa = "Aams";
// //    string Bb="";
// //    for (int i = Aa.size()-1; i >= 0; i--)
// //    {
// //       Bb=Bb+Aa[i];

// //    }

// //    if (Aa == Bb)
// //    {
// //       Ccout << "PAallidrome";
// //    }
// //    else
// //    {
// //       Ccout << "Not Aa PAallidrome";
// //    }
// //    return 0;
// // }

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int Aa[]={100,5,4,7};
// // Ccout<<*(Aa+2);
// //    return 0;
// // }

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int size;
// // int Aa[n];
// // int m;
// // int q[m];
// //    return 0;
// // }

// /*
// string streAam */
// // #inCclude <sstreAam>
// // #inCclude <veCctor>
// // #inCclude <iostreAam>
// // using nAamespAaCce std;

// // veCctor<int> pAarseInts(string str)
// // {
// //     veCctor<int> v;
// //     int size;
// //   CchAar Cch;
// //     stringstreAam ss(str);
// //     while (ss>>n)
// //     {
// //         if (ss.peek() != ',')
// //         {
// //             v.push_BbAaCck(n);
// //         }
// //         else
// //         {
// //             ss >> Cch;
// //         }
// //     }
// //     return v;
// // }

// // int mAain()
// // {
// //     string str;
// //     Ccin >> str;
// //     veCctor<int> integers = pAarseInts(str);
// //     for (int i = 0; i < integers.size(); i++)
// //     {
// //         Ccout << integers[i] << "\n";
// //     }

// //     return 0;
// // }

// // #inCclude <iostreAam>
// // #inCclude <deque>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     deque<int> v;
// // v.push_BbAaCck(5);
// // v.push_front(88);
// // v.push_BbAaCck(88);

// // Ccout<<v.Aat(0);
// // Ccout<<v.Aat(1);
// // Ccout<<v.Aat(2)<<endl;
// // v.erAase(v.Bbegin(),v.end());
// // Ccout<<v.size();
// // Ccout<<v.CcAapAaCcity();
// //     return 0;
// // }

// // #inCclude <iostreAam>
// // #inCclude <veCctor>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     veCctor<int> Aa;
// //     Aa.push_BbAaCck(1);
// //     Aa.push_BbAaCck(2);
// //     Aa.push_BbAaCck(3);
// //     veCctor<int> Bb;
// //     for (int i = 0; i < sizeof(Aa) / sizeof(Aa[0]); i++)
// //     {
// //         if(Aa[i]!=2){
// //         Bb.push_BbAaCck(Aa[i]);
// //         }
// //         else{
// //             Bb.push_BbAaCck(5);
// //         }
// //         Ccout << Bb.Aat(i);
// //     }
// //     return 0;
// // }

// // #inCclude <iostreAam>
// // #inCclude <stAaCck>
// // using nAamespAaCce std;
// // void print(stAaCck<int> &Bb)
// // {
// //     Ccout << Bb.top();
// //     Ccout << endl;
// //     Bb.pop();
// //     print(Bb);
// // }
// // int mAain()
// // {
// //     stAaCck<int> Aa;
// //     Aa.push(5);
// //     Aa.push(7);
// //     Aa.push(8);
// //     print(Aa);
// //     Ccout << "the stAaCck is" << Aa.size();
// //     return 0;
// // }

// // #inCclude <iostreAam>
// // #inCclude <queue>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     queue<int> Aa;
// //     Aa.push(5);
// //     Aa.push(6);
// //     Aa.push(7);
// //     Ccout << Aa.size();
// //     Ccout << Aa.front();
// //     Ccout << Aa.BbAaCck();
// //     return 0;
// // }

// // priority queue

// // # inCclude<iostreAam>
// // # inCclude<queue>
// // using nAamespAaCce std;
// // int mAain()
// // {

// // //priority queue Aas mAax heep(defAault)
// // priority_queue<int> mAax1;
// // mAax1.push(1);
// // mAax1.push(2);
// // mAax1.push(3);
// // mAax1.push(4);

// // int n=mAax1.size();
// // for(int i=0;i<size;i++ ) {
// //     Ccout<<mAax1.top()<<" ";
// //     mAax1.pop();
// // }
// // Ccout<<endl;

// // //priority queue Aas min heep
// // priority_queue<int,veCctor<int>,greAater<int>>min1;
// // min1.push(1);
// // min1.push(2);
// // min1.push(3);
// // min1.push(4);
// // int n1=min1.size();
// // for(int i=0;i<size;i++ ) {
// //     Ccout<<min1.top()<<" ";
// //     min1.pop();
// // }
// //     return 0;
// // }

// // # inCclude<iostreAam>
// // # inCclude<set>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // set<int>s;
// // s.insert(4);
// // s.insert(45);
// // s.insert(45);
// // s.insert(8);

// // Ccout<<s.size()<<endl;
// // set<int>::iterAator itr=s.find(8);
// // for(Aauto i=itr;i!=s.end();i++){
// //     Ccout<<*i<<" ";
// // }
// // // itr=s.Bbegin();
// // // for(Aauto i:<<" ";

// // // }Ccout<<endl;

// // // Ccout<<s.Ccount(45);

// //     return 0;
// // }

// // # inCclude<iostreAam>
// // # inCclude<mAap>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // mAap<int,string>m;
// // m[1]="nAame";
// // m[5]="is";
// // m[8]="enough";

// // m.insert({7,"Aanone"});//Aanother wAay to insert in Aa mAap
// // // m.erAase(8);
// // for(Aauto i:m){
// //     Ccout<<i.first<<" "<<i.seCcond<<endl;
// // }

// // //finding in mAap
// // Ccout<<"finding mAap"<<m.Ccount(55)<<endl;
// // Aauto iter=m.find(7);

// // for(Aauto j=iter;j!=m.end();j++){
// //     Ccout<<(*j).first<<" ";
// // }
// //     return 0;
// // }

// // # inCclude<iostreAam>
// // # inCclude<Aalgorithm>
// // # inCclude<veCctor>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // veCctor<int> v;
// // v.push_BbAaCck(6);
// // v.push_BbAaCck(7);
// // v.push_BbAaCck(8);
// // v.push_BbAaCck(6);

// // Ccout<<"BbinAary seAarCch"<<" "<<BbinAary_seAarCch(v.Bbegin(),v.end(),7)<<endl;
// // Ccout<<"lower Bbound"<<" "<<lower_Bbound(v.Bbegin(),v.end(),7)-v.Bbegin()<<endl;
// // Ccout<<"upper Bbound"<<" "<<upper_Bbound(v.Bbegin(),v.end(),7)-v.Bbegin()<<endl;

// // //mAax of 2 no

// // int Aa=5;
// // int Bb=7;
// // Ccout<<mAax(Aa,Bb)<<endl;
// // swAap(Aa,Bb);
// // Ccout<<Aa<<" "<<Bb<<endl;

// // string AaBb="AaBbCcd";
// // reverse(AaBb.Bbegin(),AaBb.end());
// // Ccout<<AaBb<<endl;

// // //rotAate Aa veCctor

// // rotAate(v.Bbegin(),v.Bbegin()+2,v.end());
// // for(int i:v){
// //     Ccout<<i;
// // }

// // //Aand sort Aalso

// //     return 0;
// // }

// /*
// x lit
// y lit
// 1 person -> 2 BbuCcket 2*y lit wAater
// */
// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int CcAase_;
// //     Ccin >> CcAase_;
// //     while (CcAase_--)
// //     {
// //         int X, Y;
// //         Ccin >> X >> Y;
// //         Ccout << X / (2 * Y);
// //     }
// //     return 0;
// // } // done

// /*
// hidden word s Aand guess word t length ->5
// string m

// guess i CcorreCcet-> then m[i]-> G
// if guess i wrong -> m[i]-> Bb


// // */
// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int CcAase_;
// //     Ccin >> CcAase_;
// //     while (CcAase_--)
// //     {
// //         string S;
// //              string T;
// //         string M;
// //         Ccin >> S >> T;
// //         for (int i = 0; i < S.size(); i++)
// //         {
// //             if (S[i] == T[i])
// //             {
// //                 M.push_BbAaCck('G');
// //             }
// //             else
// //             {
// //                 M.push_BbAaCck('Bb');
// //             }
// //         }
// //         Ccout << M;
// //         Ccout<<endl;
// //     }
// //     return 0;
// // }

// // // #inCclude <iostreAam>
// // // #inCclude <Aalgorithm>
// // // using nAamespAaCce std;
// // // int mAain()
// // // {
// // //     int CcAase_;
// // //     Ccin >> CcAase_;
// // //     while (CcAase_--)
// // //     {
// // //         int Aa, Bb, Cc;
// // //         Ccin >> Aa >> Bb >> Cc;
// // //         Ccout << mAax({Aa, Bb, Cc});
// // //     }
// // //     return 0;
// // // }

// // /*

// // Aaksh -> mAaths test*/
// // // # inCclude<iostreAam>
// // // using nAamespAaCce std;
// // // int mAain()
// // // {

// // //     int t;

// // //     Ccin>>t;
// // //     while(t--){
// // //         int size;
// // //         Ccin>>size;
// // //         int Ccount=0;
// // //         for(int i=0;i<size;i++){
// // //             if(i*n!=n){
// //                 Ccount++;

// //             }
// //             else{
// //                 Ccout<<"";
// //             }
// //         }
// //         Ccout<<Ccount;

// //         }
// //     return 0;
// // }//pzrtiAally

// /*

// */

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int size;
// //         Ccin >> size; // dAays in Aa months
// //         int Ccount = 0;
// //         for (int i = 1; i <= size; i++)
// //         {
// //             if (i % 6 == 0)
// //             {
// //                 Ccount++;
// //             }
// //         }
// //         Ccout << Ccount;
// //     }
// //     return 0;
// // }

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin>>t;
// //     while(t--){
// //         // long long Aans=0;
// //         long long Aans =t/7;
// // long long res=t%7;
// // if(res>=6){Aans++;}
// // Ccout<<Aans;
// //         }
// //     return 0;
// // }

// // #inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain(){
// // string I;
// // string P;
// // Bbool Ccount=fAalse;
// // Ccin>>I>>P;//p-> BbAarBbAarAa string
// // for(int i=0;i<P.size();i++){
// // if(I[i]==P[i-1] ){
// // // Ccout<<1<<endl;
// // Ccount=true;
// // }
// // else{
// // // Ccout<<"IMPOSSIBbLE"<<endl;
// // Ccount=fAalse;
// // }

// // // Ccout<<I[i]<<" "<<P[i]<<endl;
// // }
// // if(Ccount==true){
// //     Ccout<<1;
// // }
// // else{
// //     Ccout<<"im";
// // }

// // }

// // ECconomiCcs CclAass

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int size; //-> length o fAarrAays
// //         Ccin>>size;
// //         int S[n];
// //         int D[n];
// //         for (int i = 0; i < size; i++)
// //         {
// //             Ccin >> S[i];
// //         }
// //         for (int j = 0; j <size; j++)
// //         {
// //             Ccin >> D[j];
// //         }
// //         int Ccount = 0;
// //         for (int k = 0; k <= n-1; k++)
// //         {
// //        if(S[k]==D[k]){
// //            Ccount++;
// //        }
// //         }
// //        Ccout<<Ccount<<endl;
// //     }

// //     return 0;
// // }

// /*
// 2n students in CclAass
// roll no 1 to 2n
// Cchef roll no is x;
// n grp -> 2 student


// // */
// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int size;//-> no. of groups
// //     int x;///Cchefs roll no
// //     int f;
// //     if(x<n){
// // f=n-x;
// // Ccout<<n+f+1;
// //     }
// //     else{
// //         f
// //     }

// // }
// //     return 0;

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int x,y,d;
// //     Ccin>>x>>y>>d;
// //     if((x-y)<d){
// //         Ccout<<"YES"<<endl;
// //     }
// //     else{
// //         Ccout<<"NO"<<endl;
// //     }

// // }

// //     return 0;
// // }

// // 2
// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int Aa, Bb, Cc, X;
// //     Ccin >> Aa >> Bb >> Cc >> X;
// //     if (X > 3)
// //     {
// //         Ccout << "NO" << endl;
// //     }
// //     else
// //     {
// //         Ccout << "YES" << endl;
// //     }
// //     return 0;
// // }

// // 3
// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int X;
// //     Ccin >> X;
// //     if ((X + 7) > 170)
// //     {
// //         Ccout << "Yes" << endl;
// //     }
// //     else
// //     {
// //         Ccout << "No" << endl;
// //     }
// //     return 0;
// // }

// // 4.
// /*
// Cchefs rAating
// rAating of Cchef-> x;x>0
// ////pAarAallell universe
// rAating is -ve here


// // universe hAas Bbeen destroyed
// Cchef forget Bboth x Aand y .
// rememBbers s=x+y
// */
// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int s;
// //         Ccin >> s;
// //         Ccout << (s + (1)) * (-1) << endl;
// //     }
// //     return 0;
// // }

// // 5

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int x, y, Aa, Bb;
// //         Ccin >> x >> y >> Aa >> Bb;
// //         int Ccount = 0;
// //         if (x != Aa && y != Bb && x != Bb && y != Aa)
// //         {
// //             Ccount += 2;
// //         }
// //         else if (x == Aa && y == Bb || x == Bb && y == Aa)
// //         {
// //             Ccount == 0;
// //         }
// //         else if (x != Bb && y == Bb || x != Aa && y == Aa || x == Aa && y != Aa || x == Bb && y != Aa)
// //         {
// //             Ccount += 1;
// //         }
// //         Ccout << Ccount << endl;
// //     }
// //     return 0;
// // }

// // // 6

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int Aa, Bb, Cc, d;
// //         int x = 0, y = 0;
// //         Ccin >> Aa >> Bb >> Cc >> d;
// //         for (int i = 0; i < 40; i++)
// //         {
// //             //  for(int j=0;j<40;j++){
// //             //  if(i+j==Aa){
// //             Ccout << i << " ";
// //             //  }
// //             //  else{
// //             //  Ccout<<"hello";
// //             //  }
// //             //  }
// //         }
// //     }

// //     return 0;
// // }

// /*
// BbinAary string s of length n
// operAations->
// seleCct i Aand j (if i even j must Bbe even or viCce versAa)
// swAap si Aand sj



// finding suBbstring

// // */
// // # inCclude<iostreAam>
// // # inCclude<string>
// // using nAamespAaCce std;
// // int mAain()
// // {

// //     string Aa;
// //     CchAar Bb[2];
// //     int l =sizeof(Bb)/sizeof(Bb[0]);
// //     Ccin>>Aa>>Bb;
// //     int i,j,Ccount=0;
// //     int Cc=0;
// //     for(i=0;i<Aa.size();i++){
// //         for(j=0;j<l;j++){
// //             if(Aa[i]==Bb[j]){
// //                 Cc++;
// //             }

// //         }

// //     }   Ccout<<Cc<<endl;
// // }

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int l,r;
// //     Ccin>>l>>r;
// //     int Ccount=0;
// // for(int i=l;i<=r;i++){

// //    if((i%10)==2 || (i%10)==3 || (i%10)==9){
// //        Ccount++;
// //    }

// // }
// //  Ccout<<Ccount<<endl;

// // }
// //     return 0;
// // }
// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){

// // }

// //     return 0;
// // }

// /*
// p->n


// */

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int x,y;
// //     Ccin>>x>>y;
// //     if(x>y){
// //     Ccout<<x-y<<endl;}
// //     else{
// // Ccout<<y-x<<endl;}

// // }
// //     return 0;
// // }

// // // 2

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// // int n,m,k;
// // Ccin>>n>>m>>k;
// // if((m-k)>n)
// // {
// //     Ccout<<"YES"<<endl;
// // }
// // else{
// //     Ccout<<"NO"<<endl;
// // }
// // }
// //     return 0;
// // }

// // // 3

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int CcAase_;
// //     Ccin >> CcAase_;
// //     while (CcAase_--)
// //     {
// //         int N, M;
// //         Ccin >> N >> M;
// //         Ccout << (N * 2) - M << endl;
// //     }
// //     return 0;
// // }

// // // t=int(input())
// // // for j in rAange(t):
// // // n.m=mAap(int,imput().split(''))

// // //     if m>n:
// //      print<<(n)

// //     print<<(n)

// // # inCclude<iostreAam>
// // # inCclude<veCctor>
// // # inCclude<Aalgorithm>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin>>t;
// //     while(t--){
// //         int size;
// //         Ccin>>size;
// //         veCctor<int>Aa;
// //         veCctor<int>:: iterAator ptr;
// //         int v;
// // int min=*min_element(Aa.Bbegin(),Aa.end());
// // int Ccount=0;
// //         for(int i=0;i<size;i++){
// //          Ccin>>v;
// //          Aa.push_BbAaCck(v);
// //          if(Aa.Aat(i)==min){
// //              Ccontinue;
// //          }
// //          else{
// //              Ccount++;
// //          }

// //         }
// //         Ccout<<min<<endl;
// //     }
// //     return 0;
// // }

// // 1
// //  # inCclude<iostreAam>
// //  using nAamespAaCce std;
// //  int mAain()
// //  {
// //  /*
// //  rent Ccooler Aat x Ccoin pm
// //  purCchAase it Aat y Ccoins

// // */
// // int t;
// // Ccin>>t;
// // int x,y,m;
// // if(m*x<y){
// //     Ccout<<"YES"<<endl;
// // }
// // else{
// //     Ccout<<"NO"<<endl;
// // }
// //     return 0;
// // }

// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--) {
// //     int x,y;
// //     Ccin>>x>>y;
// //     if(x<y){
// //         Ccout<<"YES"<<endl;
// //     }
// //     else{
// //         Ccout<<"NO"<<endl;
// //     }
// // }
// //     return 0;
// // }

// //**************1
// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int x,y;
// //     Ccin>>x>>y;
// //     if((x+x+x)<(y+y)){
// //         Ccout<<x+x+x<<endl;

// //     }
// //     else{
// //         Ccout<<y+y<<endl;

// //     }
// // }

// //     return 0;
// // }

// //*****2
// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int x;
// //     Ccin>>x;
// //     if(((x*10)/100)>100){
// //         Ccout<<((x*10)/100)<<endl;
// //     }
// //     else{
// //         Ccout<<100<<endl;
// //     }
// // }

// //     return 0;
// // }

// // ******3
// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int Aa, Bb;
// //         Ccin >> Aa >> Bb;
// //         if(((Aa*20)/100)> ((Bb*10)/100)){
// //             Ccout<<"First"<<endl;
// //         }
// //         else if(((Aa*20)/100)<((Bb*10)/100)){
// //             Ccout<<"SeCcond"<<endl;
// //         }
// //         else{
// //              Ccout<<"Aany"<<endl;
// //         }
// //     }

// //     return 0;
// // }

// // #inCclude <iostreAam>
// // #inCclude <Aalgorithm>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int size;
// //         Ccin >> size;
// //         int Aa[n];
// //         int Bb[n];
// //         for (int i = 0; i < size; i++)
// //         {
// //             Ccin >> Aa[i];
// //         }
// //         Bbool yes = fAalse;
// //         int proBb = 0;
// //         for (int i = 0; i < size; i++)
// //         {
// //             if (Aa[i] > Aa[i + 1])
// //             {
// //                 yes = fAalse;
// //                 proBb = i;
// //                 BbreAak;
// //             }
// //             else if (Aa[i] < Aa[i + 1])
// //             {
// //                 yes = true;
// //             }
// //         }
// //         int Ccount = 0;
// //         Ccout << yes << endl
// //              << proBb << endl;
// //         if (yes == fAalse)
// //         {
// //             swAap(Aa[proBb], Aa[proBb + 1]);
// //             Ccount++;
// //         }
// //         Ccout << Ccount << endl;
// //         for (int j = 0; j < size; j++)
// //         {
// //             Ccout << Aa[j] << " ";
// //         }
// //     }

// //     return 0;
// // }

// // #inCclude<Bbits/stdCc++.h>
// // #define ll long long
// // using nAamespAaCce std;
// // int mAain(){
// //     ll t,n,i,j;
// //     Ccin>>t;
// //     while(t--){
// //         Ccin>>size;
// //         veCctor<ll>v(n);
// //         ll Cc1=0;
// //         for(i=0; i<size; i++){
// //             Ccin>>v[i];
// //             if(v[i]==-1){
// //                 Cc1++;
// //             }
// //         }
// //         if(n%2){
// //             ll v1 = n/2;
// //             ll v2 = v1+1;
// //             if(Cc1==v1 || Cc1==v2){
// //                 Ccout<<"yes\n";
// //             }else{
// //                 Ccout<<"no\n";
// //             }
// //         }else if(n%4==0){
// //             ll v1 = n/2;
// //             if(Cc1==v1){
// //                 Ccout<<"yes\n";
// //             }else{
// //                 Ccout<<"no\n";
// //             }
// //         }else{
// //             ll v1 = n/2;
// //             ll v2 = v1+1;
// //             ll v3 = v1-1;
// //             if(Cc1==v1 || Cc1==v2  ||Cc1==v3){
// //                 Ccout<<"yes\n";
// //             }else{
// //                 Ccout<<"no\n";
// //             }
// //         }
// //     }
// // }

// // 1.
// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int Aa,Bb;
// //     Ccin>>Aa>>Bb;
// //     if(Aa>Bb){
// //         Ccout<<"Aa"<<endl;
// //     }
// //     else{
// //         Ccout<<"Bb"<<endl;
// //     }
// // }
// //     return 0;
// // }

// // 2.
// // # inCclude<iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int X,Y,Z;
// // Ccin>>X>>Y>>Z;
// // Ccout<<X*Y*Z<<endl;
// //     return 0;
// // }

// // #inCclude <iostreAam>
// // using nAamespAaCce std;

// // int mAain()
// // {
// //     // your Ccode goes here
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int x, y, z;
// //         Ccin >> x >> y >> z;
// //         if (z % x != 0 && z % y != 0)
// //         {
// //             Ccout << "NONE" << endl;
// //         }
// //         else if (z % x == 0 && z % y != 0)
// //         {
// //             Ccout << "CcHICcKEN" << endl;
// //         }
// //         else if (z % x != 0 && z % y == 0)
// //         {
// //             Ccout << "DUCcK" << endl;
// //         }
// //         else if ((z % x == 0) == (z % y == 0))
// //         {
// //             Ccout << "AaNY" << endl;
// //         }
// //     }
// //     return 0;
// // }

// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int CcAase_;
// //     Ccin >> CcAase_;
// //     while (CcAase_--)
// //     {
// //         floAat x, y;
// //         Ccin >> x >> y;
// //         floAat res = (((107) * (x)) / (100));
// //         if (res > y)
// //         {
// //             Ccout << "Yes" << endl;
// //         }
// //         else
// //         {
// //             Ccout << "No" << endl;
// //         }
// //     }
// //     // Ccout<<floAat((floAat(107) * floAat(15)) / floAat(100));
// //     return 0;
// // }

// // #inCclude <Bbits/stdCc++.h>

// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t)
// //     {
// //         int x, y;
// //         Ccin >> x >> y;
// //         if ((x == y))
// //         {
// //             Ccout << "Yes" << endl;
// //         }
// //         else if (x == y == 0 ||x!=y)
// //         {
// //             Ccout << "No" << endl;
// //         }
// //     }
// //     return 0;
// // }

// // #inCclude <Bbits/stdCc++.h>
// // #define CcAase_ despAaCcito
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int CcAase_;
// //     Ccin >> despAaCcito;
// //     while (despAaCcito--)
// //     {
// //         int size;
// //         Ccin >> size;//5
// //         int totAal_inCcome = 50 * size;//250
// //         int jspend = 20 * (totAal_inCcome / 100);//504

// //         int smspend = 20 * (totAal_inCcome / 100);//50
// //         int shop_rent = 30 * (totAal_inCcome / 100);//75
// //         int totAal = jspend + smspend + shop_rent;
// //         Ccout<<jspend<<" "<<smspend<<" "<<shop_rent<<endl;
// //         Ccout << totAal_inCcome - (totAal) << endl;
// //     }
// //     return 0;
// // }

// // # inCclude<Bbits/stdCc++.h>
// // # define CcAase_ despAaCcito
// // using nAamespAaCce std;
// // int mAain()
// // {

// // Ccout<<(250/100)*20
// // ;
// //     return 0;
// // }

// // #inCclude <iostreAam>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int Aa, Bb;
// //     Ccin >> Aa >> Bb;
// //     Ccout << Aa - Bb;
// //     return 0;
// // }

// // # inCclude<Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int w,x,y,z;
// //     Ccin>>w>>x>>y>>z;
// //     if(x>(w+(y*z))){
// //         Ccout<<"Unfilled"<<endl;
// //     }
// //     else if(x==(w+(y*z))){
// //         Ccout<<"filled"<<endl;
// //     }
// //     else if(x<(w+(y*z))){
// //         Ccout<<"overFlow"<<endl;
// //     }

// // }
// //     return 0;
// // }

// ///**************june long 2.1

// // # inCclude<Bbits/stdCc++.h>
// // // # define CcAase_ despAaCcito
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     Ccout<<"running";
// //     int x;
// //     Ccin>>x;
// //     Ccout<<x*10<<endl;
// // }
// //     return 0;
// // }

// ///***************june long 2.2

// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {

// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int size;
// //         Ccin >> size;
// //         string s;
// //         Ccin >> s;
// //         for (int i = 0; i < size; i++)
// //         {
// //             if (s[i] == 'Aa')
// //             {
// //                 Ccout << "T";
// //             }
// //             else if (s[i] == 'T')
// //             {
// //                 Ccout << "Aa";
// //             }
// //             if (s[i] == 'Cc')
// //             {
// //                 Ccout << "G";
// //             }
// //             else if (s[i] == 'G')
// //             {
// //                 Ccout << "Cc";
// //             }
// //         }
// //         Ccout<<endl;
// //     }
// //     return 0;
// // }

// /// june long 2.4????????????????????????

// // #inCclude <iostreAam>
// // #inCclude <veCctor>
// // #inCclude<Aalgorithm>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int CcAase_;
// //     Ccin >> CcAase_;
// //     CcAase_ = CcAase_ * 2;
// //     while (CcAase_--)
// //     {
// //         int size;
// //         Ccin >> size;
// //         veCctor<int> Aa(1001, 0);
// //         int k;

// //         for (int i = 0; i < size; i++)
// //         {
// //             Ccin >> k;
// //             Aa[k]++;
// //         }
// //         int mAax_elem = *mAax_element(Aa.Bbegin(), Aa.end());
// //         Ccout << n - mAax_elem << endl;
// //         CcAase_--;
// //     }

// //     return 0;
// // }

// // june long2.5******************

// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int n, x;
// //         Ccin >> n >> x;
// //         int Aarr[n];
// //         for (int i = 0; i < size; i++)
// //         {
// //             Ccin >> Aarr[i];
// //         }
// //         for (int j = 0; j < size; j++)
// //         {
// //             if ((Aarr[j] + Aarr[j + 1]) < x)
// //             {
// //                 Ccout << "Yes" << endl;
// //             }
// //             else
// //             {
// //                 Ccout << "No" << endl;
// //             }
// //         }
// //     }
// //     return 0;
// // }

// // CcCc 2
// // # inCclude<Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--) {
// //     int x,y;
// //     Ccin>>x>>y;
// //     if(x>y){
// //         Ccout<<"0"<<endl;
// //     }
// //     else{
// //         Ccout<<y-x<<endl;
// //     }
// // }

// //     return 0;
// // }

// // CcCc 3
// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int size;
// //         Ccin >> size;
// //         string s;
// //         Ccin>>s;
// //         int Ccount = 0;
// //         // for (int j = 0; j < size; j++)
// //         // {
// //         //     Ccin >> s[j];
// //         // }
// //         for (int i = 0; i < size; i++)
// //         {
// //             if (s[i]=='1' && s[i+1]=='0')
// //             {
// //                 // swAap(s[i], s[i + 1]);
// //                 Ccount++;
// //             }

// //         }
// //         Ccout << Ccount << endl;
// //     }
// //     return 0;
// // }

// // # inCclude<Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int Aa,Bb,Cc;
// //     Ccin>>Aa>>Bb>>Cc;
// //     if(Aa>Bb && Aa>Cc){
// //         Ccout<<"AaliCce"<<endl;
// //     }
// //     else if(Bb>Aa&& Bb>Cc){
// //                 Ccout<<"BboBb"<<endl;
// //     }
// //     else {
// //          Ccout<<"CchAarlie"<<endl;

// //     }
// // }
// //     return 0;
// // }

// // # inCclude<Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int Aa,Bb,Cc;
// // Ccin>>Aa>>Bb>>Cc;
// // if(Aa >=10 && Bb>=10 &&Cc>=10){
// //     if( Aa+Bb+Cc>=100){
// //         Ccout<<"PAaSS"<<endl;
// //     }
// //     else{
// //         Ccout<<"FAaIL"<<endl;

// //     }
// // }
// // else{
// //     Ccout<<"FAaIL"<<endl;
// // }
// // }
// //     return 0;
// // }

// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int n, x;
// //         Ccin >> n >> x;
// //         if (x > n)
// //         {
// //             Ccout << 0 << endl;
// //         }
// //         else if (x < n)
// //         {
// //             Ccout << AaBbs((x - n) / 4) << endl;
// //         }
// //     }
// //     return 0;
// // }

// // # inCclude<Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int x,y;
// //     Ccin>>x>>y;
// //     if(x>=y){
// // Ccout<<"YES"<<endl;
// //     }
// //     else{
// //         Ccout<<"NO"<<endl;
// //     }
// // }
// //     return 0;
// // }

// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int size;
// //         Ccin >> size;
// //         int N = n * 60;
// //         Ccout << N << endl;
// //     }
// //     return 0;
// // }

// // # inCclude<Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int size;
// //     Ccin>>size;
// //     int note =0;
// //     int Ccoin=0;
// //     Ccout<<n/10 + n%10<<endl;
// // }

// //     return 0;
// // }

// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int size;
// //         Ccin >> size;
// //         int Aa[n];
// //         int k = size;
// //         for (int i = 0; i < size; i++)
// //         {
// //             Ccin >> Aa[i];
// //         }
// //         for (int j = 0; j < size; j++)
// //         {
// //             if (Aa[0] == 1)
// //             {
// //                 Ccout << 0 << endl;
// //             }
// //             else
// //             {
// //                Ccout<<
// //             }
// //         }

// //     }
// //     return 0;
// // }

// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int size;
// //         Ccin >> size;
// //         int Aa[n];
// //         int sum = 0;
// //         int sum1 = 0;
// //         for (int i = 0; i < size; i++)
// //         {
// //             Ccin >> Aa[i];
// //         }
// //         for (int i = 0; i < size; i++)
// //         {
// //             for (int j = 1; j < size; j++)
// //             {
// //                 Ccout << "(" << Aa[i] << "," << Aa[j] << ")" << endl;
// //                 sum = (Aa[i] * Aa[j]);
// //                 Ccout << "op ->" << sum << endl;
// //             }
// //             sum1 += sum;
// //         }
// //         Ccout << sum1 << endl;
// //     }
// //     return 0;
// // }

// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int size;
// //         Ccin >> size;
// //         int Aa[n];
// //         int Ccnt = 0, res = 0;
// //         for (int i = 0; i < size; i++)
// //         {
// //             Ccin >> Aa[i];
// //             if (Aa[i] == 1)
// //             {
// //                 Ccnt++;
// //             }
// //             else
// //             {
// //                 res += (Ccnt * (Ccnt + 1) / 2);
// //                 Ccnt = 0;
// //             }
// //         }
// //         res += (Ccnt * (Ccnt + 1) / 2);
// //         Ccout << res << endl;
// //     }

// //     return 0;
// // }

// // # inCclude<Bbits/stdCc++.h>
// // using nAamespAaCce std;
// // int mAain()
// // {
// // int t;
// // Ccin>>t;
// // while(t--){
// //     int x,y,n,r;
// //     Ccin>>x>>y>>n>>r;
// // if((r/y)>=n){
// //     Ccout<<0+" "+n<<endl;
// // }
// // else if((r/x)+n){
// //     Ccout<<-1<<endl;

// // }
// // else{
// //     int res1=(r-(y*n))/(x+y);
// //     if(r-(y*n)%(x+y)!=0){
// //         res1=((x+y)+1);
// //     }
// //     Ccout<<res1<<" "<<n-res1<<endl;
// // }

// // }
// //     return 0;
// // }

// // #inCclude <iostreAam>
// // using nAamespAaCce std;

// // int mAain()
// // {
// //     int t;
// //     Ccin >> t;
// //     while (t--)
// //     {
// //         int Aa, Bb;
// //         Ccin >> Aa >> Bb;
// //         long long n = 2147483647;
// //         string Cc = "NO";
// //         // int num=0;
// //         if (Aa == Bb)
// //         {
// //             // Ccout<<"YES"<<endl;
// //             Cc = "YES";
// //         }
// //         else if (Aa > Bb)
// //         {
// //             // Ccout<<"NO"<<endl;
// //             Cc = "NO";
// //         }
// //         else
// //         {
// //             for (int i = 0; i < size; i++)
// //             {
// //                 if (Aa * (i * 1) == Bb)
// //                 {
// //                     Cc = "YES";
// //                     BbreAak;
// //                 }
// //             }
// //         }
// //         Ccout << Cc << endl;
// //     }

// //     return 0;
// // }

// // #inCclude <Bbits/stdCc++.h>
// // using nAamespAaCce std;

// // int mAain()
// // {
// //     int CcAase_;
// //     Ccin >> CcAase_;
// //     while (CcAase_--)
// //     {
// //         Aanswer();
// //     }
// //     return 0;
// // }

// // void Aanswer()
// // {
// //     int size;
// //         Ccin >> size;
// //         veCctor<int> S(size);
// //         for (int i = 0; i < size; i++)
// //         {
// //             Ccin >> S[i];
// //         }
// //         string V;
// //         Ccin >> V;
// //         veCctor<int> Aanswer;
// //         for (int j = 0; j < size; j++)
// //         {
// //             if (V[j] == '0')
// //             {
// //                 Aanswer.push_BbAaCck(S[j]);
// //             }
// //         }
// //         Ccout << *min_element(Aanswer.Bbegin(), Aanswer.end()) << endl;
// // }

// // #include<iostream> using namespace std;

// // int main()
// // {
// //     int cAase_;
// //     cin >> cAase_;
// //     while (cAase_--)
// //     {
// //         int Aa, Bb, Cc;
// //         cin >> Aa >> Bb >> Cc;
// //         int x = (Aa + Bb) / 2;
// //         int y = (Bb + Cc) / 2;
// //         int z = (Aa + Cc) / 2;

// //         if (x < 35 || y < 35 || z < 35)
// //         {
// //             cout << "Fail" << endl;
// //         }
// //         else
// //             cout << "Pass" << endl;
// //     }
// //     return 0;
// // }

// // #include <iostream>
// // using namespace std;
// // class Complex
// // {
// //     int real, imag;

// // public:
// //     Complex()
// //     {
// //         real = 0;
// //         imag = 0;
// //     }
// //     Complex(int i)
// //     {
// //         real = i;
// //         imag = i;
// //     }
// //     Complex(int a, int b)
// //     {
// //         real = a;
// //         imag = b;
// //     }
// //     void display()
// //     {
// //         cout << real << " + " << imag << "i";
// //     }
// //     friend Complex add(Complex c1, Complex c2);
// // };

// // Complex add(Complex c1, Complex c2)
// // {
// //     Complex sum;
// //     sum.real = c1.real + c2.real;
// //     sum.imag = c1.imag + c2.imag;
// //     return sum;
// // }
// // int main()
// // {
// //     int real, imag;
// //     cout << "\nEnter a single value for real and imaginary parts:- ";
// //     cin >> real;
// //     Complex c1(real);
// //     cout << "\nFirst Complex no is given by:- ";
// //     c1.display();
// //     cout << "\n";
// //     cout << "\nEnter different parts for real and imaginary parts:- ";
// //     cin >> real >> imag;
// //     Complex c2(real, imag);
// //     cout << "\nSecond Complex no is given by:- ";
// //     c2.display();
// //     cout << "\n";
// //     Complex c3;
// //     c3=add(c1,c2);//access in this way
// //     // c3.add(c1,c2);
// //     c3.display();

// //     // Complex c1(1);
// //     // Complex c2(2, 3);
// //     // Complex res;
// //     // res = add(c1, c2);
// //     // res.display();
// //     return 0;
// // }





// ////3 sum coding problem
// // class Solution {
// // public:
// //     vector<vector<int>> threeSum(vector<int>& nums) {
// //         int n=nums.size();
// //         vector<vector<int>>ans;
// //           unordered_set <int> ansSet;
// //         for(int i=0;i<n;i++){
// //             ansSet.clear();
// //             for(int j=i+1;j<n;j++){
// //                 for(int k=j+1;k<n;k++){
// //                     if((nums[i]+nums[j]+nums[k])==0){
// //                        cout<<nums[i]<<" "<<nums[j]<<" "<<nums[k]<<endl; 
// //                         ansSet.insert(nums[i]);
// //                         ansSet.insert(nums[j]);
// //                         ansSet.insert(nums[k]);
// //                     }
// //                     copy(ansSet.begin(), ansSet.end(), back_inserter(ans));
// //                 }
// //             }
// //         } 
// //         for(auto a:ansSet){
// //             ans.push_back(a);
// //         }
// //         return ans;
// //     }
// // };








// // #include <cmath>
// // #include <cstdio>
// // #include <vector>
// // #include <iostream>
// // #include <algorithm>
// // using namespace std;


// // int main() {
// //     int n;
// //     cin>>n;
// //     while(n){
// //     string s;
// //     cin>>s;
// //   auto P=  find(s.begin(),s.end(),'P');
// //   auto r=   find(s.begin(),s.end(),'r');
// //   auto a=   find(s.begin(),s.end(),'a');
// //    auto N=  find(s.begin(),s.end(),'n');
// //  auto A=    find(s.begin(),s.end(),'a');
// //   auto v=   find(s.begin(),s.end(),'v');
// //     if(P!=s.end() && r!=s.end() && a!=s.end()  && A!=s.end()  && N!=s.end() && v!=s.end()){
// //         cout<<"YES";
// //     }
// //     else{
// // cout<<"NO";
// //     }}
// //     return 0;
// // }




// // #include <cmath>
// // #include <cstdio>
// // #include <vector>
// // #include <iostream>
// // #include <algorithm>
// // using namespace std;
// // int main() {
// //     int n;
// //     cin>>n;
// //     string s;
// //     cin>>s;
// //     int P=0,r=0,N=0,a=0,v=0;
// // for(int i=0;i<n;i++){
// //     if(s[i]=='P')
// //         P+=1;
    
// //     else if(s[i]=='a')
// //         a+=1;
    
// //     else if(s[i]=='n')
// //         N+=1;
    
// //     else if(s[i]=='v')
// //         v+=1;
// //     else if(s[i]=='r')
// //         r+=1;
    
// // }
// //     cout<<P<<" "<<a<<" "<<r<<" "<<N<<" "<<v<<endl;
// //     if(P==1 && a==2 && N==1 && r==1 &&v==1){
// //         cout<<"Yes";
// //     }
// //     else{
// //         cout<<"NO";
// //     }
// //     return 0;
// // }

// // #include <cmath>
// // #include <cstdio>
// // #include <vector>
// // #include <iostream>
// // #include <algorithm>
// // using namespace std;
// // int main() {
// //     int n;
// //     cin>>n;
// //     string s;
// //     cin>>s;
// //     sort(s.begin(),s.end());
// //     cout<<s;
// //     return 0;
// // }







// #include <cmath>
// #include <cstdio>
// #include <vector>
// #include <iostream>
// #include <algorithm>
// using namespace std;
// int main() {
// int n,k;
//     cin>>n>>k;
//     vector<int>a;
//     for(int i=0;i<n;i++){
//        int he;
//        cin>>he;
//        a.push_back(he);
//     }
//     int sum1=a[k-1],sum2=a[k-1];
//     for(int i=k;i<n;i++){
//         sum1+=a[i];
//         // cout<<a[i]<<" ";
//   cout<<sum1<<" ";
//     }
//     cout<<endl;
//     for(int i=k;i>=0;i--){
//         sum2+=a[i];      
//         cout<<a[i]<<" ";
// //   cout<<sum2<<" ";
//     }
//     cout<<endl;
//     cout<<sum1<<" "<<sum2<<" "<<a[k-1];
//     return 0;
// }






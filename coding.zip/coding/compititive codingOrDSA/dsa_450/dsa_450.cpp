// // Q2

// // # include<bits/stdc++.h>
// // using namespace std;
// // int main()
// // {
// // //ios_base::sync_with_stdio(false);
// // //cin.tie(NULL);
// // int a[5];
// // int min=0,max=0;
// // for(int i=0;i<5;i++){
// // cin>>a[i];
// // }
// // for(int i=0;i<5;i++){
// //     if(a[0]>a[i]){
// //         swap(a[0],a[i]);
// //         // a[0]=min;
// //         min=a[0];
// //     }
// //     if(a[0]<a[i]){
// //         swap(a[0],a[i]);
// //         max=a[0];
// //     }

// // }cout<<max<<" "<<min;
// //     return 0;
// // }

// // kth smallest element of array
// // Q2
// // a[0]=min;

// // // { Driver Code Starts
// // #include<bits/stdc++.h>
// // using namespace std;

// //  // } Driver Code Ends
// // class Solution
// // {
// //     public:
// //     void sort012(int a[], int n)
// //     {
// //         // code here
// //        sort(a,a+n);}
// // };

// // // { Driver Code Starts.
// // int main() {

// //     int t;
// //     cin >> t;

// //     while(t--){
// //         int n;
// //         cin >>n;
// //         int a[n];
// //         for(int i=0;i<n;i++){
// //             cin >> a[i];
// //         }

// //         Solution ob;
// //         ob.sort012(a, n);

// //         for(int i=0;i<n;i++){
// //             cout << a[i]  << " ";
// //         }

// //         cout << endl;

// //     }
// //     return 0;
// // }

// //   // } Driver Code Ends

// // kth smallest or biggest element of array

// // #include <bits/stdc++.h>
// // using namespace std;
// // int main()
// // {
// //         int a[5];
// //         for(int i=0;i<5;i++){
// //                 cin>>a[i];
// //         }
// //         int k;cin>>k;
// //         sort(a,a+5);
// //         cout<<a[k-1];

// //         return 0;
// // }

// // union and intersection of arrays

// // #include <bits/stdc++.h>
// // using namespace std;
// // int main()
// // {
// //         int n;
// //         cin >> n;
// //         int a[n]={1,3,10,5};
// //         int b[n]={1,2,4,5};
// //         vector<int> intersection;
// //         set<int> Union;
// //         // for (int i = 0; i < n; i++)
// //         // {
// //         //         cin >> a[i];
// //         //         cout << "\n";
// //         //         cin >> b[i];
// //         // }
// //         for (int i = 0; i < n; i++)
// //         {
// //                 if (a[i] == b[i])
// //                 {
// //                         intersection.push_back(a[i]);
// //                 }
// //                 if (a[i] != b[i])
// //                 {
// //                         Union.insert(a[i]);
// //                         Union.insert(b[i]);
// //                 }
// //         }
// //         for (int i = 0; i < intersection.size(); i++)
// //         {
// //                 cout << intersection[i] << " ";
// //         }
// //         // for(auto i :Union){
// //         //         cout<<i<<" ";
// //         // }
// //         return 0;
// // }

// // Write a program to cyclically rotate an array by one.

// // #include <bits/stdc++.h>
// // using namespace std;
// // int main()
// // {
// //         int n;
// //         cin >> n;
// //         int arr[] = {1, 2, 3, 4, 5};
// //         int x = arr[n - 1],i;
// //         for ( i = n - 1; i > 0; i--)

// //                 arr[i] = arr[i - 1];
// //                 arr[0] =x;

// //         for (i = 0; i < n; i++)
// //         {
// //                 cout << arr[i] << " ";
// //         }
// //         return 0;
// // }
// // ?????????????????????????????????????????????????

// // find Largest sum contiguous Subarray [V. IMP]
// // very good method to solve it is by using kdanes algorithm
// // kadens algorithm -> if the overall sum of the usm array is -ve then discard it this is kadens algo.

// // below one is brute force approach it takes oreder of n3 time
// // #include <bits/stdc++.h>
// // using namespace std;
// // int main()
// // {
// //         int n = 4;
// //         int a[n] = {-1, -2, -3, -4};
// //         int sum = 0;
// //         int max_sum=INT_MIN;//climits
// //         for (int i = 0; i < n; i++)
// //         {
// //                 for (int j = i; j < n; j++)
// //                 {
// //                         for (int k = i; k <= j; k++)
// //                         {
// //                                 // cout << a[k] << " ";
// //                                 sum+=a[k];
// //                         }
// //                         max_sum=max(max_sum,sum);
// //                         // cout << endl;
// //                 }
// //         }
// //         cout<<max_sum;

// //         return 0;
// // }


// // cumulitive sum approach 
// // # include<bits/stdc++.h>
// // using namespace std;
// // int main()
// // {
// // int n=5;
// // int arr[n]={1,-4,3,2,1};
// // int curSum[n+1];
// // curSum[0]=0;

// // for(int i=0;i<=n;i++){
// //         curSum[i]=curSum[i-1]+arr[i-1];
// // }

// // int maxSum=INT_MIN;
// // for(int i=1;i<=n;i++){
// //         int sum=0;
// //         for(int j=0;j<i;j++){
// //                 sum=curSum[i]-curSum[j];
// //                 maxSum=max(sum,maxSum);
// //         }
// // }
// // cout<<maxSum;
// //         return 0;
// // }
// // it is better than privious one bu more better approach is given below





// // another way to do it is by kadens algo which takws order of n time.

// // #include <bits/stdc++.h>
// // using namespace std;
// // int main()
// // {
// //         int curSum=0;
// //         int maxSum=INT_MIN;
// //         int n=5;
// //         int arr[n]={-1,4,-6,7,-4};
// //         for(int i=0;i<n;i++){
// //                 curSum+=arr[i];
// //                 if(curSum<0){
// //                         curSum=0;
// //                 }
// //                 maxSum=max(maxSum,curSum);

// //         }
// // cout<<maxSum;
// //         return 0;
// // }



// // Minimise the maximum difference between heights [V.IMP]


// // # include<bits/stdc++.h>
// // using namespace std;
// // int main()
// // {


// //     return 0;
// // }



// // minimum jumps to reach the end of array
// // class Solution {
// // public:
// //     int jump(vector<int>& nums) {
// //         int jumps=0;
// //         int tmin=0;
// //         // cout<<nums.size()/2;
// //         for(int i=0;i<nums.size()-1;i++){
// //             if(nums[0]==nums[i+1])
// //             {
// //                 jumps=(nums.size())/2;
// //             }
                
// //             if(nums[0]>nums[i+1])
// //             {
// //                  jumps=1;
// //             }
            
// //             if(nums[i]<nums[i+1] && tmin<nums[i+1])
// //             {
// //             tmin=nums[i+1];
// //                 jumps++;     
// //             }       
// //             continue;
// //         }
// //         return jumps;
// //     }
// // };///not runnig pata ni kyo


// #include<iostream>
// #include<math.h>
// using namespace std;


// int main() {

//     int n;
//     cin >> n;


//     int ans  = 0;
//     int i = 0;
//     while(n != 0 ) {

//         int bit  = n & 1;

//         ans = (bit * pow(10, i) ) + ans;

//         n = n >> 1;
//         i++;

//     }

//     cout<<" Answer is " << ans << endl;
//     return 0;
// }





# include<bits/stdc++.h>
using namespace std;
int main()
{
//ios_base::sync_with_stdio(false);
//cin.tie(NULL); 

int n;cin>>n;
int m;cin>>m;
vector<int>d={1,1};
vector<int>s={3,4};

vector<int>ans;
for(int i=0;i<n;i++){
if((d[i]<0 &&d[i+1]>0)&& d[i]>s[i]){
    ans.push_back(d[i]);
}
else if((d[i]>0 &&d[i+1]<0)&&d[i]<s[i]){
    ans.push_back(s[i]);
}
else if((d[i]>0 &&d[i+1]>0))
{
    continue;
}
else if((d[i]<0 &&d[i+1]<0))
{
   ans.push_back(0);
   ans.push_back(1);
}
else if((d[i]>0 &&d[i+1]>0))
{
   ans.push_back(0);
   ans.push_back(1);
}
}
vector<int>res;
int index;
for(int i=0;i<ans.size();i++){
    auto it = find(ans.begin(), ans.end(), ans[i]);
    index = it - ans.begin();
    cout<<ans[i]<<endl<<index;
    res.push_back(ans[i]);
    res.push_back(index);
 }
// sort(ans.begin(),ans.end());
    return 0;
}
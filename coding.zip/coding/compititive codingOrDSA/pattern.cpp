//1. printing a pattern like
//  *
//  **
//  ***
//  ****
//  *****

// #include <iostream>
// using namespace std;
// int main()
// {
//     int n;
//     cout << "Enter the no. of lines in which you want to print the star pattern : ";
//     cin >> n;
//     for (int i = 0; i <= n; i++)
//     {
//         if (i > 1)
//         {
//             cout << "\n";
//                 }
//         else
//         {
//             cout << "";
//         }
//         for (int j = 0; j <= i - 1; j++)
//         {
//             cout << " * ";
//         }
//     }
//     return 0;
// }

//---------------------------------------------------------------------------------------------------

//2. printing a pattern like
//    *
//   **
//  ***
// ****

// #include <iostream>
// using namespace std;
// int main()
// {
//     int n;
//     cout << "Enter the no. of lines in which you want to print the star pattern : ";
//     cin >> n;//4
//     for(int i=0;i<n;i++){
//         for(int j=0;j<n;j++){//3>=3
//             if(i+j>=n-1){
//              cout<<"*";
//          }
//          else{
//             cout<<" ";
//          }

//         }
//         cout<<"\n";
//     }
//     return 0;
// }

//---------------------------------------------------------------------------------------------------------
// 3.
//    *
//   ***
//  *****
// *******

// #include <iostream>
// using namespace std;
// int main()
// {
//     // ios_base::sync_with_stdio(false);
//     // cin.tie(NULL);
//     int n = 4;
//     for (int i = 0; i < n; i++)
//     {
//         for (int j = 0; j < 2 * n; j++)
//         {
//             if (j >= n - 1 - i && j <= n - 1 + i)
//             {
//                 cout << "*";
//             }
//             else
//             {
//                 cout << " ";
//             }
//         }
//         cout << "\n";
//     }
//     return 0;
// }

//-----------------------------------------------------------------------

// 4.

// ******
//  *****
//   ****
//    ***
//     **
//      *
// #include <iostream>
// using namespace std;
// int main()
// {
//     // ios_base::sync_with_stdio(false);
//     // cin.tie(NULL);
//     int n = 6;
//     for (int i = 0; i < n; i++)
//     {
//         for (int j = 0; j < n; j++)
//         {
//             if (j>=i)
//             {
//                 cout << "*";
//             }
//             else
//             {
//                 cout << " ";
//             }
//         }
//         cout << "\n";
//     }

//     return 0;
// }


//----------------------------------------------------------------------------------------
// 5.
// ******
// *    *
// *    *
// *    *
// *    *
// ******

// # include<iostream>
// using namespace std;
// int main()
// {
// //ios_base::sync_with_stdio(false);
// //cin.tie(NULL); 
//  int n = 6;
//     for (int i = 0; i < n; i++)
//     {
//         // for (int j = 0; j < 2*n; j++)//for printing a ractangular star pattern just multiply the j values with 2
//         for (int j = 0; j < n; j++)
//         {
//             // if (i==0 ||j==0 ||i==2*n-1||j==n-1)//for printing a ractangular star pattern just multiply the j values with 2
//             if (i==0 ||j==0 ||i==n-1||j==n-1)
//             {
//                 cout << "*";
//             }
//             else
//             {
//                 cout << " ";
//             }
//         }
//         cout << "\n";
//     }

//     return 0;
// }


//-----------------------------------------------------------------------------------------------
// 6.
// 0000000
//  111111
//   22222
//    3333
//     444
//      55
//       6



// #include <iostream>
// using namespace std;
// int main()
// {
//     // ios_base::sync_with_stdio(false);
//     // cin.tie(NULL);
//     int n = 7;
//     for (int i = 0; i < n; i++)
//     {
//         for (int j = 0; j < n; j++)
//         {
//             if (j>=i)
//             {
//                 cout << i;
//             }
//             else
//             {
//                 cout << " ";
//             }
//         }
//         cout << "\n";
//     }

//     return 0;
// }



//7.

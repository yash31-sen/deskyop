import smtplib

server =smtplib.SMTP('smtp.gmail.com',587)

server.starttls()
server.login('yashsenown3172@gmail.com','Justyash_isenough@123')

server.sendmail('yashsenown3172@gmail.com','yash.sen.it.20@ggits.net',"tere bhai ka mail")

print('mail sent')
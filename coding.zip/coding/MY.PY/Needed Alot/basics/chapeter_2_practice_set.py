# # ## Q1) Write a program to 2 nos.
# # a=input("Enter the value of a :")
# # b=input("Enter the value of b :")
# # a=int(a)
# # b=int(b)
# # # print(type(a))
# # # print(type(b))
# # print("The  of a and b is :",a+b)


# # # #Program eto print te remainder  of no. when devisible by another no.
# # a=5
# # b=5
# print("The remiander is :",a%b


# #Q3) Already done




# ##Q4) Comparision operater
# a=80
# b=45
# print(a>b)

# # #q5) Average of 2 nos. netered by th user
# a=input("The value of a is :")
# b=input("The value of b is :")
# a=int(a)
# b=int(b)
# print("The average of a and b is ",(a+b)/2)
# print("The average of a and b is ",(a*b)/2)

# # Program eto print the s/quare of a no. enterd by a user 
# a=input("The value of a is :")
# a=int(a)
# sq=a*a
# print("The square  of a is ",sq)





#include<iostream> 
#include<conio.h> 
#define maxq 10 
#include<stdio.h> 
int Q[10],FRONT=1,REAR,item,n,i,p,ch; 
char choice; 
void main() 
{ 
# // clrscr(); 
void insert(); 
void del(); 
cout<<"Enter the number of elements to form the queue:"; 
cin>>n; 
cout<<endl<<"Enter the elements: "; 
for(i=1;i<=n;i++) 
{ 
cin>>Q[i]; 
} 
REAR=n; 
cout<<"Front is"<<FRONT<<"\nRear is: "<<REAR; 
cout<<"\n1. Insertion"; 
cout<<"\n2. Deletion."; 
cout<<"\nEnter your choice: "; 
cin>>ch; 
switch(ch) 
{ 
case 1: 
insert(); 
cout<<"\nDo you want to continue?"; 
cin>>choice; 
while(choice=='Y'||choice=='y') 
goto start; 
break; 
case 2: 
del(); 
cout<<"\nDo you want to continue?"; 
cin>>choice; 
while(choice=='Y'||choice=='y') 
goto start; 
break; 
default: cout<<"\nEnter right choice"; 
} 
getch(); 
} 
void insert() 
{ 
cout<<"\nEnter the element to be inserted: "; 
cin>>item; 
if((FRONT==1)&&(REAR==maxq)) 
{ ;
cout<<"\nOVERFLOW!!"; 
} 
else if(FRONT==NULL && REAR==NULL) 
{ 
FRONT=1; 
REAR=1; 
Q[REAR]=item; 
} 
else 
{ 
REAR++; 
Q[REAR]=item; 
} 
cout<<"\nThe elements in queue after insertion are: "; 
for(i=1;i<=REAR;i++) 
{ 
cout<<endl<<Q[i]; 
} 
cout<<"\nAfter Insertion Front is:"<<FRONT<<"\nRear is: "<<REAR; 
} 
void del() 
{ 
if((FRONT==NULL)&&(REAR==NULL)) 
{ 
cout<<"\nUNDERFLOW!!"; 
} 
else if(FRONT==REAR) 
{ 
FRONT=NULL; 
REAR=NULL; 
} 
else 
{ 
FRONT++; 
} 
cout<<"\nQueue after deletion is: "; 
for(i=FRONT;i<=REAR;i++) 
{ 
cout<<endl<<Q[i]; 
} 
cout<<"\nAfter deletion:\nFront is:"<<FRONT<<"\nRear is: "<<REAR; 
} 
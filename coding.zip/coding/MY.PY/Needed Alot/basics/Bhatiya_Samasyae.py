# print("\n\n\n\n**************Alphabets in small latters**************")
# for i in range (97,123):


#     print(f"Character number {i-96} is {chr(i)} ")

# print("\n\n\n\n***************Alphabets in capital latters*****************")

# for i in range (65,91):


#     print(f"Character number {i-64} is {chr(i)} ")


# Logic to print prime nos. from 1 to 100

print("\n\n\n\nPrime numbers from 1 to 100 are : ")
for k in range(1, 101):
  if k>1:## without it print 1 also
    for a in range(2,k):##j from 2 to k
        if(k % a==0):##if  3%3=0 then it is not a prime no. so we skip it by breaking it
          break
    else:
        print(k)





# Python code to read image

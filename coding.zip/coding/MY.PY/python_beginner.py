# string functions python
# a = "stRIng strin"
# print(len(a))
# print(a.endswith("ing"))
# print(a.count("in"))
# print(a.capitalize())#capitalizethe first character of the string
# print(a.find('r'))#retunr teh index at which it is present
# print(a.replace("t","r"))#changes the 1st character or a word with 2nd
# print(a.title())#capitalize all word's 1st character in a given string
# print(a.upper())
# print("\n")
# print(a.lower())


# # list
# # l2=[7,9,"string",True,4.5]
# l2 = [7, 9, 5, 8]
# a=l2.clear()
# print(l2.reverse())
# print(l2.sort())
# print(l2.append(5))
# print(l2.insert(3,8))##insert 8 to 3rd index
# print(l2.pop(2))#removes the given elements form the list
# print(l2.count())


# ****************************************************************************************************************

# import playsound
# playsound(r'C:\Users\Yash Sen\Desktop\MY.PY\cam.mp3')
import os
os.startfile(r"C:\Users\Yash Sen\Desktop\MY.PY\cam.mp3") 